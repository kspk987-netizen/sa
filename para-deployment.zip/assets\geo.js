window.PARA = window.PARA || {};

PARA.geo = {
  EARTH_KM: 6371,

  haversine: function (a, b) {
    if (!a || !b) return 0;
    var toRad = function (d) { return d * Math.PI / 180; };
    var dLat = toRad(b.lat - a.lat), dLng = toRad(b.lng - a.lng);
    var s = Math.pow(Math.sin(dLat / 2), 2) +
      Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.pow(Math.sin(dLng / 2), 2);
    return 2 * this.EARTH_KM * Math.asin(Math.min(1, Math.sqrt(s)));
  },

  activeRoute: function () {
    var db = PARA.store.db;
    return db.routes.filter(function (r) { return r.status === "active"; })[0] || db.routes[0] || null;
  },

  stops: function (routeId) {
    return PARA.store.db.stops
      .filter(function (s) { return !routeId || s.routeId === routeId; })
      .sort(function (a, b) { return a.position - b.position; });
  },

  segmentMinutes: function (fromStop, toStop) {
    if (!fromStop || !toStop) return 5;
    if (fromStop.travelToNext != null) return fromStop.travelToNext;
    if (toStop.travelFromPrev != null) return toStop.travelFromPrev;
    return Math.max(2, Math.round(this.haversine(fromStop, toStop) * 4));
  },

  segments: function (routeId) {
    var list = this.stops(routeId), out = [], acc = 0;
    for (var i = 0; i < list.length - 1; i++) {
      var mins = this.segmentMinutes(list[i], list[i + 1]);
      out.push({ from: list[i], to: list[i + 1], minutes: mins, startWeight: acc, endWeight: acc + mins });
      acc += mins;
    }
    return { list: out, totalWeight: acc };
  },

  totalMinutes: function (routeId) {
    var seg = this.segments(routeId);
    if (seg.list.length) return seg.totalWeight;
    var r = PARA.store.db.routes.filter(function (x) { return x.id === routeId; })[0];
    return r && r.estDurationMin ? r.estDurationMin : 45;
  },

  stopFraction: function (stopId) {
    var stop = PARA.store.db.stops.filter(function (s) { return s.id === stopId; })[0];
    if (!stop) return 0;
    var seg = this.segments(stop.routeId);
    if (!seg.list.length) return 0;
    if (stop.position <= 1) return 0;
    if (stop.position >= this.stops(stop.routeId).length) return 1;
    var match = seg.list.filter(function (s) { return s.to.id === stop.id; })[0];
    if (!match) return 0;
    return match.endWeight / seg.totalWeight;
  },

  coordAt: function (routeId, frac) {
    var list = this.stops(routeId);
    if (!list.length) return null;
    if (list.length === 1) return { lat: list[0].lat, lng: list[0].lng };
    var seg = this.segments(routeId);
    if (!seg.list.length) return { lat: list[0].lat, lng: list[0].lng };
    var target = Math.max(0, Math.min(1, frac)) * seg.totalWeight;
    var chosen = seg.list[seg.list.length - 1];
    for (var i = 0; i < seg.list.length; i++) {
      if (target <= seg.list[i].endWeight) { chosen = seg.list[i]; break; }
    }
    var span = chosen.endWeight - chosen.startWeight || 1;
    var t = Math.max(0, Math.min(1, (target - chosen.startWeight) / span));
    var bow = Math.sin(t * Math.PI) * 0.00035;
    return {
      lat: chosen.from.lat + (chosen.to.lat - chosen.from.lat) * t + bow,
      lng: chosen.from.lng + (chosen.to.lng - chosen.from.lng) * t - bow
    };
  },

  nearestStop: function (routeId, coord) {
    var list = this.stops(routeId), best = null, bestD = Infinity;
    list.forEach(function (s) {
      var d = PARA.geo.haversine(coord, s);
      if (d < bestD) { bestD = d; best = s; }
    });
    return best ? { stop: best, km: bestD } : null;
  },

  activeTrips: function () {
    var db = PARA.store.db;
    return db.trips.filter(function (t) { return t.status !== "completed"; });
  },

  tripSpeedFactor: function (trip) {
    if (trip.status === "temporarily_stopped") return 0;
    if (trip.status === "delayed") return 0.35;
    if (trip.status === "vehicle_problem" || trip.status === "road_problem" || trip.status === "emergency") return 0.15;
    return trip.simFactor || 1;
  },

  tripCoord: function (trip) {
    return this.coordAt(trip.routeId, trip.progress || 0);
  },

  etaMinutes: function (trip, stopId) {
    var target = this.stopFraction(stopId);
    var current = trip.progress || 0;
    if (target <= current) return 0;
    var total = this.totalMinutes(trip.routeId);
    var factor = this.tripSpeedFactor(trip) || 1;
    return Math.max(1, Math.round(((target - current) * total) / factor));
  },

  etaClock: function (trip, stopId) {
    return new Date(Date.now() + this.etaMinutes(trip, stopId) * 60000).toISOString();
  },

  gpsFreshness: function (vehicle) {
    if (vehicle.status === "out_of_service") return "unavailable";
    if (!vehicle.lastGpsAt) return vehicle.status === "offline" ? "unavailable" : "unavailable";
    var age = (Date.now() - new Date(vehicle.lastGpsAt).getTime()) / 1000;
    if (age <= 75) return "active";
    if (age <= 210) return "delayed";
    return "unavailable";
  },

  gpsNote: function (vehicle) {
    var f = this.gpsFreshness(vehicle);
    if (f === "active") return "GPS updating normally";
    if (f === "delayed") return "GPS updates are late — vehicle may still be running";
    return "No recent GPS signal — not the same as the trip being stopped";
  },

  refreshStopEtas: function () {
    var db = PARA.store.db;
    var trips = this.activeTrips();
    db.stops.forEach(function (s) {
      var best = null;
      trips.forEach(function (t) {
        if (t.routeId !== s.routeId) return;
        var mins = PARA.geo.etaMinutes(t, s.id);
        if (mins <= 0) return;
        if (!best || mins < best.mins) best = { mins: mins, trip: t };
      });
      s.eta = best ? PARA.geo.etaClock(best.trip, s.id) : null;
      s.etaTripId = best ? best.trip.id : null;
    });
  },

  mapSvg: function (opts) {
    opts = opts || {};
    var routeId = opts.routeId || (this.activeRoute() || {}).id;
    var list = this.stops(routeId);
    if (!list.length) return "<div class='empty'>No stops configured for this route yet.</div>";

    var lats = list.map(function (s) { return s.lat; });
    var lngs = list.map(function (s) { return s.lng; });
    var minLat = Math.min.apply(null, lats), maxLat = Math.max.apply(null, lats);
    var minLng = Math.min.apply(null, lngs), maxLng = Math.max.apply(null, lngs);
    var padLat = Math.max((maxLat - minLat) * 0.22, 0.0016);
    var padLng = Math.max((maxLng - minLng) * 0.22, 0.0016);
    minLat -= padLat; maxLat += padLat; minLng -= padLng; maxLng += padLng;

    var W = 1000, H = 430;
    var px = function (lng) { return 30 + ((lng - minLng) / (maxLng - minLng)) * (W - 60); };
    var py = function (lat) { return H - 30 - ((lat - minLat) / (maxLat - minLat)) * (H - 60); };

    var pts = list.map(function (s) { return px(s.lng).toFixed(1) + "," + py(s.lat).toFixed(1); });
    var out = [];
    out.push("<svg viewBox='0 0 " + W + " " + H + "' xmlns='http://www.w3.org/2000/svg' role='img' aria-label='Route map'>");
    out.push("<rect width='" + W + "' height='" + H + "' fill='#f2f8f3'/>");
    for (var gx = 0; gx < W; gx += 50) out.push("<line x1='" + gx + "' y1='0' x2='" + gx + "' y2='" + H + "' stroke='#e6efe8' stroke-width='1'/>");
    for (var gy = 0; gy < H; gy += 50) out.push("<line x1='0' y1='" + gy + "' x2='" + W + "' y2='" + gy + "' stroke='#e6efe8' stroke-width='1'/>");

    out.push("<polyline points='" + pts.join(" ") + "' fill='none' stroke='#2e7d32' stroke-width='13' stroke-linecap='round' stroke-linejoin='round' opacity='.85'/>");
    out.push("<polyline points='" + pts.join(" ") + "' fill='none' stroke='#ffffff' stroke-width='3.4' stroke-dasharray='14 12' stroke-linecap='round'/>");

    list.forEach(function (s, i) {
      var x = px(s.lng), y = py(s.lat);
      var isEnd = i === 0 || i === list.length - 1;
      out.push("<circle cx='" + x.toFixed(1) + "' cy='" + y.toFixed(1) + "' r='" + (isEnd ? 11 : 8) + "' fill='" + (isEnd ? "#1b5e20" : "#f9a825") + "' stroke='#fff' stroke-width='3'/>");
      var anchor = x > W - 150 ? "end" : "start";
      var dx = anchor === "end" ? -15 : 15;
      out.push("<text x='" + (x + dx).toFixed(1) + "' y='" + (y + 4).toFixed(1) + "' text-anchor='" + anchor + "' font-size='13' font-weight='700' fill='#16211a'>" + PARA.esc(s.name) + "</text>");
      if (s.eta) {
        out.push("<text x='" + (x + dx).toFixed(1) + "' y='" + (y + 19).toFixed(1) + "' text-anchor='" + anchor + "' font-size='11' fill='#5f6b62'>ETA " + PARA.fmt.time(s.eta) + "</text>");
      }
    });

    var db = PARA.store.db;
    this.activeTrips().forEach(function (trip) {
      if (trip.routeId !== routeId) return;
      var c = PARA.geo.tripCoord(trip);
      if (!c) return;
      var x = px(c.lng), y = py(c.lat);
      var veh = db.vehicles.filter(function (v) { return v.id === trip.vehicleId; })[0];
      var color = trip.status === "delayed" ? "#d93025"
        : trip.status === "temporarily_stopped" ? "#f9a825"
        : trip.status === "emergency" ? "#b3261e" : "#14682c";
      out.push("<g transform='translate(" + x.toFixed(1) + "," + y.toFixed(1) + ")'>");
      out.push("<circle r='21' fill='" + color + "' opacity='.16'/>");
      out.push("<circle r='12' fill='" + color + "' stroke='#fff' stroke-width='3'/>");
      out.push("<text y='4.5' text-anchor='middle' font-size='12' fill='#fff' font-weight='700'>" + PARA.esc(veh ? veh.name.charAt(0) : "B") + "</text>");
      out.push("</g>");
      if (veh) {
        out.push("<text x='" + x.toFixed(1) + "' y='" + (y - 24).toFixed(1) + "' text-anchor='middle' font-size='11.5' font-weight='700' fill='#16211a'>" + PARA.esc(veh.name) + "</text>");
      }
    });

    out.push("</svg>");
    return out.join("");
  }
};

PARA.sim = {
  timer: null,
  lastTick: null,

  start: function () {
    if (this.timer) return;
    this.lastTick = Date.now();
    var self = this;
    this.timer = setInterval(function () { self.tick(); }, 4000);
  },

  stop: function () { if (this.timer) { clearInterval(this.timer); this.timer = null; } },

  tick: function () {
    var db = PARA.store.db;
    if (!db) return;
    var now = Date.now();
    var dtMin = Math.max(0, (now - (this.lastTick || now)) / 60000);
    this.lastTick = now;
    if (dtMin <= 0) return;

    var changed = false;
    var alerts = [];

    db.trips.forEach(function (trip) {
      if (trip.status === "completed") return;
      var total = PARA.geo.totalMinutes(trip.routeId) || 45;
      var factor = PARA.geo.tripSpeedFactor(trip);
      if (!trip.simFactor) trip.simFactor = 1;

      if (Math.random() < 0.02) {
        trip.simFactor = Math.random() < 0.6 ? 0.6 + Math.random() * 0.25 : 1 + Math.random() * 0.2;
        if (trip.simFactor < 0.85 && trip.status === "active") {
          trip.status = "delayed";
          trip.delayMin = Math.round(total * (1 - (1 / trip.simFactor)) * 0.6);
          trip.delayReason = PARA.CONST.delayReason[Math.floor(Math.random() * 4)];
          alerts.push(trip);
        } else if (trip.simFactor >= 0.85 && trip.status === "delayed") {
          trip.status = "active";
          trip.delayMin = 0;
        }
      }

      var advance = (dtMin / total) * factor;
      trip.progress = Math.min(1.35, (trip.progress || 0) + advance);
      var coord = PARA.geo.tripCoord(trip);
      if (coord) {
        trip.lastCoord = coord;
        var veh = db.vehicles.filter(function (v) { return v.id === trip.vehicleId; })[0];
        if (veh) {
          veh.lastGpsAt = new Date().toISOString();
          veh.lastCoord = coord;
          veh.speedKph = Math.round(18 + Math.random() * 22);
          db.gps.push({
            id: PARA.store.uid("gps"), vehicleId: veh.id, driverId: trip.driverId, tripId: trip.id,
            lat: coord.lat, lng: coord.lng, at: new Date().toISOString(), speedKph: veh.speedKph, accuracyM: 8 + Math.round(Math.random() * 22)
          });
        }
        db.gps.push({
          id: PARA.store.uid("gps"), vehicleId: trip.vehicleId, driverId: trip.driverId, tripId: trip.id,
          lat: coord.lat, lng: coord.lng, at: new Date().toISOString(), speedKph: null, accuracyM: null
        });
      }

      var mins = (now - new Date(trip.startAt).getTime()) / 60000;
      if (mins > 240 && trip.status !== "emergency") {
        trip.status = "delayed";
        trip.dataQuality = "long_running";
        alerts.push({ longRun: true, trip: trip });
      }

      if (trip.progress >= 1) {
        var list = PARA.geo.stops(trip.routeId);
        trip.progress = 1;
        trip.endAt = new Date().toISOString();
        trip.durationMin = Math.round(mins);
        trip.endLoc = list.length ? list[list.length - 1].name : trip.startLoc;
        trip.status = "completed";
        trip.gpsStatus = "stopped";
        var v2 = db.vehicles.filter(function (v) { return v.id === trip.vehicleId; })[0];
        if (v2) v2.status = "available";
        changed = true;
      }
    });

    if (db.gps.length > 600) db.gps.splice(0, db.gps.length - 600);

    db.vehicles.forEach(function (v) {
      var fresh = PARA.geo.gpsFreshness(v);
      if (v.gpsStatus !== fresh) { v.gpsStatus = fresh; changed = true; }
      if (v.status === "on_trip" || v.status === "active" || v.status === "delayed") {
        var trip = db.trips.filter(function (t) { return t.vehicleId === v.id && t.status !== "completed"; })[0];
        if (!trip && (v.status === "on_trip" || v.status === "active" || v.status === "delayed")) {
          v.status = "available";
          changed = true;
        } else if (trip) {
          var want = trip.status === "delayed" ? "delayed" : trip.status === "emergency" ? "emergency"
            : trip.status === "temporarily_stopped" ? "temporarily_stopped" : "on_trip";
          if (v.status !== want) { v.status = want; changed = true; }
        }
      }
    });

    PARA.geo.refreshStopEtas();
    if (changed || alerts.length) PARA.store.save();
    if (alerts.length && typeof PARA.onSimAlert === "function") PARA.onSimAlert(alerts);
  }
};
