window.PARA = window.PARA || {};

/*
 * PARA Assistant - a small chat widget that answers questions about this
 * website. Retrieval-augmented generation: the widget picks the most
 * relevant notes from PARA.KB, then posts the question + notes to
 * /api/assistant, which talks to the NVIDIA NIM model server-side.
 */
(function (P) {
  "use strict";

  if (P.assistant && P.assistant.__mounted) return;

  var API = "/api/assistant";
  var HISTORY_KEY = "para_assistant_chat";
  var SEEN_KEY = "para_assistant_seen";
  var MAX_STORED = 24;
  var TIMEOUT_MS = 45000;

  var SUGGESTIONS = [
    "What can I do as a passenger?",
    "How does the trip planner work?",
    "Which stops are on the route?",
    "How do the demo accounts work?",
    "What can the admin see in analytics?"
  ];

  var state = {
    open: false,
    busy: false,
    messages: [],
    seen: false
  };

  /* ---------- helpers ---------- */

  function $(id) { return document.getElementById(id); }

  function loadHistory() {
    try {
      var raw = sessionStorage.getItem(HISTORY_KEY);
      var list = raw ? JSON.parse(raw) : [];
      if (!Array.isArray(list)) return [];
      return list.filter(function (m) {
        return m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string";
      }).slice(-MAX_STORED);
    } catch (e) { return []; }
  }

  function saveHistory() {
    try {
      sessionStorage.setItem(HISTORY_KEY, JSON.stringify(state.messages.slice(-MAX_STORED)));
    } catch (e) { }
  }

  function seenBefore() {
    try { return localStorage.getItem(SEEN_KEY) === "1"; } catch (e) { return false; }
  }

  function markSeen() {
    try { localStorage.setItem(SEEN_KEY, "1"); } catch (e) { }
  }

  function md(text) {
    var esc = P.esc(text);
    esc = esc.replace(/`([^`\n]+)`/g, "<code>$1</code>");
    esc = esc.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, function (m, label, url) {
      if (!/^(https?:|#\/|#|mailto:)/.test(url)) return m;
      var ext = url.charAt(0) === "#" ? "" : " target='_blank' rel='noopener'";
      return "<a href='" + url + "'" + ext + ">" + label + "</a>";
    });
    esc = esc.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>");

    var lines = esc.split("\n");
    var out = [];
    var list = null;
    var para = [];

    function flushPara() {
      if (para.length) {
        out.push("<p>" + para.join("<br>") + "</p>");
        para = [];
      }
    }
    function closeList() {
      if (list) { out.push("</" + list + ">"); list = null; }
    }

    lines.forEach(function (line) {
      var trimmed = line.trim();
      var bullet = trimmed.match(/^(?:-|\u2022|\*)\s+(.*)$/);
      var numbered = trimmed.match(/^\d+[.)]\s+(.*)$/);
      if (!trimmed) { flushPara(); closeList(); return; }
      if (bullet || numbered) {
        flushPara();
        var want = bullet ? "ul" : "ol";
        if (list !== want) { closeList(); out.push("<" + want + ">"); list = want; }
        out.push("<li>" + (bullet ? bullet[1] : numbered[1]) + "</li>");
        return;
      }
      if (list) closeList();
      para.push(trimmed);
    });
    flushPara();
    closeList();
    return out.join("");
  }

  function timeLabel() {
    return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }

  /* ---------- message rendering ---------- */

  function renderMessages() {
    var box = $("as-msgs");
    if (!box) return;
    var html = "";

    if (!state.messages.length) {
      html +=
        "<div class='as-msg as-from-bot as-intro'>" +
          "<div class='as-bubble'>" +
            "<p><strong>Hi, I'm the PARA assistant.</strong> I answer questions about this website: the route and stops, planning a trip, accounts and alerts, the driver and administrator tools, analytics and how the demo works.</p>" +
            "<p>Answers come from a knowledge base of the site's own notes, with sources listed under each reply.</p>" +
          "</div>" +
          "<div class='as-sugg'>" + SUGGESTIONS.map(function (s) {
            return "<button type='button' class='as-chip' data-q=\"" + P.esc(s) + "\">" + P.esc(s) + "</button>";
          }).join("") + "</div>" +
        "</div>";
    }

    state.messages.forEach(function (m, i) {
      var from = m.role === "user" ? "as-from-user" : "as-from-bot";
      if (m.error) {
        html +=
          "<div class='as-msg " + from + "'>" +
            "<div class='as-bubble as-error'>" + md(m.content) +
              "<button type='button' class='btn ghost sm as-retry' data-retry='" + i + "'>Try again</button>" +
            "</div></div>";
        return;
      }
      html +=
        "<div class='as-msg " + from + "'>" +
          "<div class='as-bubble" + (m.role === "user" ? " as-user-bubble" : "") + "'>" +
            md(m.content) +
          "</div>" +
          (m.role === "assistant" && m.sources && m.sources.length
            ? "<div class='as-sources'><span>Sources</span>" + m.sources.map(function (s) {
                return "<span class='as-source'>" + P.esc(s) + "</span>";
              }).join("") + "</div>"
            : "") +
          "<div class='as-time'>" + P.esc(m.at || "") + "</div>" +
        "</div>";
    });

    if (state.busy) {
      html +=
        "<div class='as-msg as-from-bot' id='as-typing'>" +
          "<div class='as-bubble as-typing'><i></i><i></i><i></i></div>" +
          "<div class='as-time'>searching the site notes…</div>" +
        "</div>";
    }

    box.innerHTML = html;
    var scroll = $("as-scroll");
    if (scroll) scroll.scrollTop = scroll.scrollHeight;

    box.querySelectorAll("[data-q]").forEach(function (btn) {
      btn.addEventListener("click", function () { ask(btn.getAttribute("data-q")); });
    });
    box.querySelectorAll("[data-retry]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var idx = parseInt(btn.getAttribute("data-retry"), 10);
        var question = state.messages[idx - 1];
        state.messages.splice(idx, 1);
        saveHistory();
        renderMessages();
        if (question && question.role === "user") ask(question.content, true);
      });
    });
  }

  /* ---------- asking the model ---------- */

  function conversation() {
    return state.messages
      .filter(function (m) { return !m.error; })
      .slice(-8)
      .map(function (m) { return { role: m.role, content: m.content }; });
  }

  function ask(text, silent) {
    text = String(text == null ? "" : text).trim();
    if (!text || state.busy) return Promise.resolve(null);

    if (!silent) {
      state.messages.push({ role: "user", content: text, at: timeLabel() });
      saveHistory();
    }
    state.busy = true;
    renderMessages();
    setBusyUI(true);

    var docs;
    try {
      docs = P.kbRetrieve(text, 4, P.kbPageDoc(location.hash));
    } catch (e) {
      docs = [];
    }

    var msgs = conversation();
    var payload = {
      messages: msgs,
      context: docs.map(function (d) { return { id: d.id, title: d.title, text: d.text }; }),
      page: location.hash || "#/"
    };

    function callDirectNvidia() {
      var noteTexts = docs.map(function (d) { return "## " + d.title + "\n" + d.text; }).join("\n\n");
      var sys = "You are the PARA Assistant, the built-in helper of the PARA website (Passenger Alert and Routing Assistant), a community transportation demo with one bus route, a trip planner, passenger/driver/administrator accounts, alerts and analytics. Answer questions about the PARA website using the retrieved site notes as your source of truth. Keep answers friendly, concrete and short (2-5 sentences or a short bullet list). Never invent features not in the notes.\n\n<notes>\n" + noteTexts + "\n</notes>";

      var body = {
        model: "openai/gpt-oss-20b",
        messages: [{ role: "system", content: sys }].concat(msgs),
        temperature: 0.35,
        max_tokens: 1000
      };

      return fetch("https://integrate.api.nvidia.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer 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"
        },
        body: JSON.stringify(body)
      }).then(function (r) {
        if (!r.ok) throw new Error("NVIDIA HTTP " + r.status);
        return r.json();
      }).then(function (data) {
        var reply = (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || "";
        if (!reply.trim()) throw new Error("Empty reply");
        return {
          reply: reply.trim(),
          sources: docs.map(function (d) { return d.title; })
        };
      });
    }

    function kbFallback() {
      if (!docs || !docs.length) {
        return {
          reply: "I couldn't reach the AI service right now. You can explore the route, stops, and trip planner directly using the navigation menu above.",
          sources: []
        };
      }
      var mainDoc = docs[0];
      var clean = mainDoc.text.split("\n\n").slice(0, 3).join("\n\n");
      return {
        reply: "**" + mainDoc.title + "**\n\n" + clean,
        sources: docs.map(function (d) { return d.title; })
      };
    }

    function tryFetchServer() {
      if (location.protocol === "file:") {
        return callDirectNvidia().catch(function () { return kbFallback(); });
      }

      var ctrl = typeof AbortController !== "undefined" ? new AbortController() : null;
      var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, 15000) : null;

      return fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: ctrl ? ctrl.signal : undefined
      }).then(function (res) {
        if (timer) clearTimeout(timer);
        return res.text().then(function (raw) {
          var data = null;
          try { data = JSON.parse(raw); } catch (e) { }
          if (!res.ok || !data || !data.reply || typeof data.reply !== "string") {
            // Serverless endpoint not hosted or returned HTML: fall back to direct NVIDIA API
            return callDirectNvidia().catch(function () { return kbFallback(); });
          }
          return data;
        });
      }).catch(function () {
        if (timer) clearTimeout(timer);
        return callDirectNvidia().catch(function () { return kbFallback(); });
      });
    }

    return tryFetchServer().then(function (data) {
      state.busy = false;
      setBusyUI(false);
      var sources = (data.sources && data.sources.length)
        ? data.sources
        : docs.map(function (d) { return d.title; });
      state.messages.push({
        role: "assistant",
        content: data.reply.trim(),
        sources: sources,
        at: timeLabel()
      });
      saveHistory();
      renderMessages();
      return data;
    });
  }

  function setBusyUI(busy) {
    var input = $("as-input"), send = $("as-send");
    if (input) input.disabled = busy;
    if (send) send.disabled = busy;
  }

  /* ---------- panel open/close ---------- */

  function open() {
    if (state.open) return;
    state.open = true;
    var panel = $("as-panel"), fab = $("as-fab");
    if (!panel || !fab) return;
    panel.hidden = false;
    fab.setAttribute("aria-expanded", "true");
    fab.classList.add("as-open");
    root().classList.add("as-visible");
    if (!state.seen) { state.seen = true; markSeen(); fab.classList.remove("as-pulse"); }
    var input = $("as-input");
    if (input) setTimeout(function () { input.focus(); }, 60);
    var scroll = $("as-scroll");
    if (scroll) scroll.scrollTop = scroll.scrollHeight;
  }

  function close() {
    if (!state.open) return;
    state.open = false;
    var panel = $("as-panel"), fab = $("as-fab");
    if (panel) panel.hidden = true;
    if (fab) { fab.setAttribute("aria-expanded", "false"); fab.classList.remove("as-open"); }
    root().classList.remove("as-visible");
  }

  function toggle() { state.open ? close() : open(); }

  function clear() {
    state.messages = [];
    saveHistory();
    renderMessages();
  }

  function root() { return $("assistant-root"); }

  /* ---------- mount ---------- */

  function mount() {
    if ($("assistant-root")) return;

    state.messages = loadHistory();
    state.seen = seenBefore();
    state.busy = false;

    var wrap = document.createElement("div");
    wrap.id = "assistant-root";
    wrap.innerHTML =
      "<button type='button' id='as-fab' aria-label='Open the PARA assistant' aria-expanded='false'" + (state.seen ? "" : " class='as-pulse'") + ">" +
        "<svg viewBox='0 0 24 24' width='26' height='26' aria-hidden='true'><path fill='currentColor' d='M12 3C7 3 3 6.6 3 11c0 2 .8 3.8 2.2 5.2-.3 1.2-.9 2.4-1.9 3.3-.2.2-.1.6.2.6 2 .2 3.7-.3 4.9-1 1.1.4 2.3.6 3.6.6 5 0 9-3.6 9-8s-4-8-9-8zm-4 9.3c-.7 0-1.3-.6-1.3-1.3S7.3 9.7 8 9.7s1.3.6 1.3 1.3-.6 1.3-1.3 1.3zm4 0c-.7 0-1.3-.6-1.3-1.3s.6-1.3 1.3-1.3 1.3.6 1.3 1.3-.6 1.3-1.3 1.3zm4 0c-.7 0-1.3-.6-1.3-1.3s.6-1.3 1.3-1.3 1.3.6 1.3 1.3-.6 1.3-1.3 1.3z'/></svg>" +
        "<span class='as-dot' aria-hidden='true'></span>" +
      "</button>" +
      "<section id='as-panel' role='dialog' aria-label='PARA assistant' hidden>" +
        "<header class='as-head'>" +
          "<div class='as-id'>" +
            "<span class='as-avatar' aria-hidden='true'>" + P.logo(30) + "</span>" +
            "<div><div class='as-title'>PARA Assistant</div><div class='as-sub'>Answers from this site's notes</div></div>" +
          "</div>" +
          "<div class='as-head-actions'>" +
            "<button type='button' id='as-clear' class='as-icon' title='Clear conversation' aria-label='Clear conversation'>" +
              "<svg viewBox='0 0 24 24' width='17' height='17' aria-hidden='true'><path fill='currentColor' d='M9 3h6l1 2h4v2H4V5h4l1-2zM6 9h12l-1 11a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L6 9zm4 2v9h1v-9h-1zm3 0v9h1v-9h-1z'/></svg>" +
            "</button>" +
            "<button type='button' id='as-close' class='as-icon' title='Close chat' aria-label='Close chat'>" +
              "<svg viewBox='0 0 24 24' width='18' height='18' aria-hidden='true'><path fill='currentColor' d='M6.4 5L5 6.4 10.6 12 5 17.6 6.4 19 12 13.4 17.6 19 19 17.6 13.4 12 19 6.4 17.6 5 12 10.6z'/></svg>" +
            "</button>" +
          "</div>" +
        "</header>" +
        "<div id='as-scroll'><div id='as-msgs' aria-live='polite'></div></div>" +
        "<form id='as-form' autocomplete='off'>" +
          "<textarea id='as-input' rows='1' placeholder='Ask about PARA…' aria-label='Type your question' maxlength='1200'></textarea>" +
          "<button type='submit' id='as-send' aria-label='Send question'>" +
            "<svg viewBox='0 0 24 24' width='19' height='19' aria-hidden='true'><path fill='currentColor' d='M3 20l18-8L3 4v6l12 2-12 2z'/></svg>" +
          "</button>" +
        "</form>" +
        "<div class='as-foot'>Retrieval-augmented answers from NVIDIA NIM · AI can make mistakes</div>" +
      "</section>";

    document.body.appendChild(wrap);

    $("as-fab").addEventListener("click", toggle);
    $("as-close").addEventListener("click", close);
    $("as-clear").addEventListener("click", clear);

    $("as-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var input = $("as-input");
      var value = input ? input.value : "";
      if (!value.trim()) return;
      input.value = "";
      autoGrow(input);
      ask(value);
    });

    var input = $("as-input");
    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        $("as-form").dispatchEvent(new Event("submit", { cancelable: true }));
      }
    });
    input.addEventListener("input", function () { autoGrow(input); });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && state.open) close();
    });

    renderMessages();

    if (/(^|[?&])assistant=open(&|$)/.test(location.search)) open();
  }

  function autoGrow(area) {
    if (!area) return;
    area.style.height = "auto";
    area.style.height = Math.min(area.scrollHeight, 132) + "px";
  }

  P.assistant = {
    __mounted: true,
    open: open,
    close: close,
    toggle: toggle,
    ask: ask,
    clear: clear,
    isOpen: function () { return state.open; },
    history: function () { return state.messages.slice(); },
    kbRetrieve: function (q) { return P.kbRetrieve(q, 4, P.kbPageDoc(location.hash)); }
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mount);
  } else {
    mount();
  }
})(PARA);
