window.PARA = window.PARA || {};

(function (P) {
  "use strict";

  var ROUTES = {
    "": { view: "home" },
    "#/": { view: "home" },
    "#/route": { view: "route" },
    "#/planner": { view: "planner" },
    "#/login": { view: "login" },
    "#/signup": { view: "signup" },
    "#/account": { view: "account", any: true },
    "#/admin": { view: "admin", role: "admin" },
    "#/admin/drivers": { view: "admin-drivers", role: "admin" },
    "#/admin/vehicles": { view: "admin-vehicles", role: "admin" },
    "#/admin/route": { view: "admin-route", role: "admin" },
    "#/admin/announcements": { view: "admin-announcements", role: "admin" },
    "#/admin/incidents": { view: "admin-incidents", role: "admin" },
    "#/admin/analytics": { view: "admin-analytics", role: "admin" },
    "#/admin/service": { view: "admin-service", role: "admin" },
    "#/admin/logs": { view: "admin-logs", role: "admin" },
    "#/admin/data": { view: "admin-data", role: "admin" },
    "#/driver": { view: "driver", role: "driver" },
    "#/driver/trips": { view: "driver-trips", role: "driver" },
    "#/driver/reports": { view: "driver-reports", role: "driver" },
    "#/passenger": { view: "passenger", role: "passenger" },
    "#/passenger/request-new": { view: "passenger-request-new", role: "passenger" },
    "#/passenger/requests": { view: "passenger-requests", role: "passenger" },
    "#/passenger/reports": { view: "passenger-reports", role: "passenger" },
    "#/passenger/alerts": { view: "passenger-alerts", role: "passenger" }
  };

  var LIVE_VIEWS = { home: 1, route: 1, passenger: 1, driver: 1, admin: 1 };

  function navLinks(u) {
    var here = location.hash || "#/";
    var link = function (href, label) {
      return "<a href='" + href + "'" + (here === href ? " class='on'" : "") + ">" + PARA.esc(label) + "</a>";
    };
    var out = link("#/", "Home") + link("#/route", "Route & stops") + link("#/planner", "Plan trip");
    if (!u) return out;
    if (u.role === "admin") {
      out += link("#/admin", "Overview") + link("#/admin/drivers", "Drivers") + link("#/admin/vehicles", "Vehicles") +
        link("#/admin/route", "Route plan") + link("#/admin/announcements", "Announcements") +
        link("#/admin/incidents", "Incidents") + link("#/admin/analytics", "Analytics") +
        link("#/admin/service", "Service status") + link("#/admin/logs", "Logs") + link("#/admin/data", "Data");
    } else if (u.role === "driver") {
      out += link("#/driver", "My day") + link("#/driver/trips", "Trip history") + link("#/driver/reports", "Report a problem");
    } else if (u.role === "passenger") {
      out += link("#/passenger", "Home") + link("#/passenger/request-new", "Request a ride") +
        link("#/passenger/requests", "My requests") + link("#/passenger/alerts", "Alerts") + link("#/passenger/reports", "Report a problem");
    }
    return out;
  }

  function shell(u) {
    var unread = 0;
    if (u) {
      unread = PARA.store.db.notifications.filter(function (n) { return n.to === u.id && !n.read; }).length;
    }
    return "" +
      "<header class='topbar" + (u ? " has-user" : "") + "'><div class='topbar-inner'>" +
        "<a class='brand' href='#/'>" + PARA.logo(42) +
          "<span class='brand-text'><span class='brand-name'>PARA</span><span class='brand-sub'>Passenger Alert and Routing Assistant</span></span>" +
        "</a>" +
        "<nav class='nav' aria-label='Main navigation'>" + navLinks(u) + "</nav>" +
        "<div class='topbar-right'>" +
          (u
            ? "<div class='who'><b>" + PARA.esc(u.fullName) + "</b><span>" + PARA.esc(u.role) + "</span></div>" +
              (u.role === "passenger" && unread ? "<a class='btn white sm' href='#/passenger/alerts'>" + unread + " alert" + (unread === 1 ? "" : "s") + "</a>" : "") +
              "<a class='btn outline sm' href='#/account'>Account</a>" +
              "<button class='btn white sm' id='logout'>Sign out</button>"
            : "<a class='btn white sm' href='#/login'>Sign in</a>") +
        "</div>" +
      "</div></header>";
  }

  P.render = function () {
    var app = document.getElementById("app");
    if (!app) return;
    if (!P.store.db) P.store.load();
    P.geo.refreshStopEtas();

    var u = P.auth.user();
    var hash = location.hash || "#/";
    var route = ROUTES[hash];

    if (!route) {
      hash = u ? (u.role === "admin" ? "#/admin" : u.role === "driver" ? "#/driver" : "#/passenger") : "#/";
      location.hash = hash;
      route = ROUTES[hash] || ROUTES["#/"];
    }

    if (route.role && (!u || u.role !== route.role)) {
      P.ui.toast("That area is only available to " + route.role + " accounts", "bad");
      hash = u ? (u.role === "admin" ? "#/admin" : u.role === "driver" ? "#/driver" : "#/passenger") : "#/login";
      location.hash = hash;
      route = ROUTES[hash] || ROUTES["#/login"] || ROUTES["#/"];
    }
    if (route.any && !u) {
      hash = "#/login";
      location.hash = hash;
      route = ROUTES[hash] || ROUTES["#/"];
    }

    app.innerHTML = shell(u) + "<main class='main'><div id='view'></div></main>" +
      "<footer class='footer'>PARA · Passenger Alert and Routing Assistant · Community Transportation Intelligence and Assistance<br>" +
      "<span style='font-size:12px'>All data shown in this installation is stored locally in your browser. Arrival times are estimates, not guarantees.</span></footer>";

    var view = document.getElementById("view");
    var fn = P.views[route.view];
    if (typeof fn !== "function") {
      view.innerHTML = "<div class='card'><div class='empty'>This page is not available.</div></div>";
      return;
    }
    fn(view);

    var logout = document.getElementById("logout");
    if (logout) {
      logout.addEventListener("click", function () {
        P.auth.logout();
        P.store.save();
        P.ui.toast("Signed out");
        location.hash = "#/";
        P.render();
      });
    }

    document.title = "PARA — Passenger Alert and Routing Assistant";
  };

  P.onSimAlert = function (alerts) {
    var db = P.store.db;
    var u = P.auth.user();
    alerts.forEach(function (a) {
      if (a.longRun) {
        P.log.broadcast({ type: "delay", title: "A trip has been running unusually long", body: "One vehicle has been on the road for more than four hours. The administrator has been notified by the data-quality flag.", priority: "normal" });
        if (u && u.role === "admin") P.ui.toast("Data flag: a trip has been active for over 4 hours", "bad");
        return;
      }
      var veh = db.vehicles.filter(function (v) { return v.id === a.vehicleId; })[0];
      P.log.broadcast({
        type: "delay",
        title: "Delays on the main route",
        body: (veh ? veh.name + " is" : "A vehicle is") + " running about " + (a.delayMin || 0) + " minutes late" +
          (a.delayReason ? " (" + P.CONST.delayLabel[a.delayReason] + ")" : "") + ". Consider leaving a little earlier.",
        priority: (a.delayMin || 0) > 15 ? "high" : "normal"
      });
      if (u && u.role === "admin") P.ui.toast("Delay detected: " + (veh ? veh.name : "vehicle") + " +" + (a.delayMin || 0) + " min");
    });
  };

  P.boot = function () {
    P.store.load();
    P.geo.refreshStopEtas();
    P.sim.start();

    window.addEventListener("hashchange", function () { P.render(); });
    P.render();

    var tick = setInterval(function () {
      if (document.hidden) return;
      var hash = location.hash || "#/";
      var route = ROUTES[hash];
      if (!route || !LIVE_VIEWS[route.view]) return;
      var active = document.activeElement;
      if (active && /^(INPUT|SELECT|TEXTAREA)$/.test(active.tagName)) return;
      P.render();
    }, 10000);
    window.addEventListener("beforeunload", function () { P.store.save(); });
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () { P.boot(); });
  } else {
    P.boot();
  }
})(PARA);
