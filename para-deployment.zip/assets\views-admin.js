window.PARA = window.PARA || {};
PARA.views = PARA.views || {};

(function (V) {
  "use strict";

  function kpi(label, value, kind, note) {
    return "<div class='kpi" + (kind ? " " + kind : "") + "'><div class='v'>" + PARA.esc(String(value)) + "</div>" +
      "<div class='l'>" + PARA.esc(label) + "</div>" +
      (note ? "<div class='l' style='font-size:11.5px;opacity:.8'>" + PARA.esc(note) + "</div>" : "") + "</div>";
  }

  function hourlyChart(buckets, key, label) {
    var max = Math.max.apply(null, buckets.map(function (b) { return b[key] || 0; }).concat([1]));
    return "<div class='card'><div class='card-head'><h3>" + PARA.esc(label) + "</h3>" +
      "<span class='card-note'>Peak " + max + " · bars show recorded counts per hour</span></div>" +
      "<div class='bars'>" + buckets.map(function (b) {
        var h = Math.max(3, Math.round(((b[key] || 0) / max) * 150));
        var peak = (b[key] || 0) === max && max > 0;
        return "<div class='bar-col' title='" + b.hour + ":00 — " + (b[key] || 0) + "'>" +
          "<div class='bar-val'>" + (b[key] || 0) + "</div>" +
          "<div class='bar" + (peak ? " peak" : "") + "' style='height:" + h + "px'></div>" +
          "<div class='bar-lab'>" + (b.hour % 3 === 0 ? (b.hour < 10 ? "0" : "") + b.hour : "") + "</div>" +
        "</div>";
      }).join("") + "</div></div>";
  }

  V.admin = function (root) {
    if (!PARA.auth.requireRole("admin")) { location.hash = "#/"; return; }
    var db = PARA.store.db;
    var r = PARA.analytics.range("week");
    var t = PARA.analytics.tripStats(r);
    var f = PARA.analytics.fleet();
    var d = PARA.analytics.drivers();
    var w = PARA.analytics.waitStats(r);
    var u = PARA.analytics.unmet(r);
    var trips = PARA.geo.activeTrips();
    var openIncidents = db.incidents.filter(function (i) { return i.status !== "resolved" && i.status !== "dismissed"; });
    var openReports = db.reports.filter(function (x) { return x.status === "open" || x.status === "investigating"; });
    var flags = PARA.analytics.dataQuality(r);
    var today = PARA.analytics.dailySummary();

    root.innerHTML =
      "<div class='tabs-row'><div><h1 class='title'>Operations overview</h1>" +
        "<div class='sub'>Live picture of the service for " + PARA.esc(r.label.toLowerCase()) + ".</div></div>" +
        "<div class='pill-row'>" +
          "<a class='btn ghost' href='#/admin/analytics'>Full analytics</a>" +
          "<a class='btn' href='#/admin/service'>Update service status</a>" +
        "</div></div>" +

      "<div class='grid g4' style='margin-bottom:18px'>" +
        kpi("Trips recorded", t.count) +
        kpi("Passengers transported", t.passengers) +
        kpi("Active vehicles now", f.onTrip, f.onTrip === 0 ? "warn" : "") +
        kpi("Open incidents", openIncidents.length, openIncidents.length ? "bad" : "") +
        kpi("Average wait", w.avg != null ? PARA.fmt.mins(w.avg) : "no data") +
        kpi("Average trip", t.avgDuration != null ? PARA.fmt.mins(t.avgDuration) : "—") +
        kpi("Delayed trips", t.delayedTrips + " (" + t.delayRate + "%)", t.delayRate > 30 ? "warn" : "") +
        kpi("Requests not fulfilled", u.unmet, u.unmet ? "warn" : "", u.total ? u.servedRate + "% of " + u.total + " fulfilled" : "") +
      "</div>" +

      "<div class='card pad-0'><div class='table-wrap'><table class='t'>" +
        "<thead><tr><th>Vehicle</th><th>Driver</th><th>Status</th><th>GPS</th><th>Current stop area</th><th class='num'>Passengers</th><th class='num'>Delay</th><th>Action</th></tr></thead><tbody>" +
        (db.vehicles.length ? db.vehicles.map(function (v) {
          var trip = trips.filter(function (x) { return x.vehicleId === v.id; })[0];
          var drv = db.drivers.filter(function (x) { return x.id === v.driverId; })[0];
          var near = trip ? PARA.geo.nearestStop(trip.routeId, PARA.geo.tripCoord(trip)) : null;
          return "<tr><td><strong>" + PARA.esc(v.name) + "</strong><div class='stop-meta'>" + PARA.esc(v.code) + " · " + v.capacity + " seats</div></td>" +
            "<td>" + PARA.esc(drv ? drv.fullName : "—") + "</td>" +
            "<td>" + PARA.tag(v.status, PARA.CONST.vehicleLabel[v.status]) + "</td>" +
            "<td>" + PARA.tag(PARA.geo.gpsFreshness(v), PARA.geo.gpsFreshness(v)) + "</td>" +
            "<td>" + (near ? PARA.esc(near.stop.name) : "—") + "</td>" +
            "<td class='num'>" + (trip ? trip.passengers || 0 : "—") + "</td>" +
            "<td class='num'>" + (trip && trip.delayMin ? "<span class='tag t-amber'>+" + trip.delayMin + "m</span>" : "—") + "</td>" +
            "<td>" + (trip ? "<a class='btn ghost sm' href='#/admin/incidents'>Follow</a>" : "<a class='btn ghost sm' href='#/admin/vehicles'>Manage</a>") + "</td></tr>";
        }).join("") : "<tr><td colspan='8'><div class='empty'>No vehicles registered yet.</div></td></tr>") +
      "</tbody></table></div></div>" +

      "<div class='grid g2'>" +
        "<div class='card'><div class='card-head'><h3>Today at a glance</h3></div>" +
          "<ul class='stop-list'>" +
            "<li><div class='stop-num'>T</div><div><strong>" + today.trips + " trips</strong><div class='stop-meta'>" + today.passengers + " passengers recorded</div></div></li>" +
            "<li><div class='stop-num'>R</div><div><strong>" + today.requests + " passenger requests</strong><div class='stop-meta'>for today's travel</div></div></li>" +
            "<li><div class='stop-num'>W</div><div><strong>" + (today.avgWait != null ? PARA.fmt.mins(today.avgWait) : "No wait samples") + "</strong><div class='stop-meta'>average recorded wait today</div></div></li>" +
            "<li><div class='stop-num'>S</div><div><strong>" + PARA.esc(PARA.CONST.serviceLabel[db.serviceStatus]) + "</strong><div class='stop-meta'>current published status</div></div></li>" +
          "</ul>" +
        "</div>" +
        "<div class='card'><div class='card-head'><h3>Needs attention</h3></div>" +
          (openIncidents.length + openReports.length + flags.length === 0
            ? "<div class='empty'>Nothing outstanding. </div>"
            : "<ul class='stop-list'>" +
              openIncidents.map(function (i) {
                return "<li><div class='stop-num'>!</div><div><strong>Incident " + PARA.esc(i.code) + "</strong><div class='stop-meta'>" + PARA.esc(i.category) + " · " + PARA.esc(i.location || "location not given") + " · " + PARA.esc(PARA.fmt.ago(i.at)) + "</div></div></li>";
              }).join("") +
              openReports.map(function (x) {
                return "<li><div class='stop-num'>?</div><div><strong>" + PARA.esc(PARA.titleize(x.type)) + "</strong><div class='stop-meta'>reported by " + PARA.esc(x.reporterType) + " · " + PARA.esc(x.location || "location not given") + " · " + PARA.esc(PARA.fmt.ago(x.at)) + "</div></div></li>";
              }).join("") +
              flags.slice(0, 4).map(function (f2) {
                return "<li><div class='stop-num'>⚙</div><div><strong>" + PARA.esc(f2.kind) + "</strong><div class='stop-meta'>" + PARA.esc(f2.subject) + " — " + PARA.esc(f2.detail) + "</div></div></li>";
              }).join("") +
            "</ul>") +
        "</div>" +
      "</div>" +

      "<div class='card'><div class='card-head'><h3>Driver and fleet status</h3><span class='card-note'>" +
        d.active + " active of " + d.total + " registered · " + f.inService + " of " + f.total + " vehicles in service</span></div>" +
        (d.unassigned ? "<div class='alert warn'>" + d.unassigned + " active driver(s) have no vehicle assigned.</div>" : "") +
        (f.gpsIssues.length ? "<div class='alert info'>" + f.gpsIssues.length + " vehicle(s) are not sending normal GPS updates. This does not by itself mean the trip has stopped.</div>" : "") +
        "<div class='pill-row'>" +
          "<a class='btn ghost sm' href='#/admin/drivers'>Manage drivers</a>" +
          "<a class='btn ghost sm' href='#/admin/vehicles'>Manage vehicles</a>" +
          "<a class='btn ghost sm' href='#/admin/route'>Manage route &amp; stops</a>" +
          "<a class='btn ghost sm' href='#/admin/announcements'>Announcements</a>" +
          "<a class='btn ghost sm' href='#/admin/incidents'>Incidents &amp; reports (" + (openIncidents.length + openReports.length) + ")</a>" +
          "<a class='btn ghost sm' href='#/admin/logs'>Activity log</a>" +
        "</div>" +
      "</div>";
  };

  V["admin-drivers"] = function (root) {
    if (!PARA.auth.requireRole("admin")) { location.hash = "#/"; return; }
    var db = PARA.store.db;

    function render() {
      var drivers = db.drivers.slice().sort(function (a, b) { return a.code.localeCompare(b.code); });
      root.innerHTML =
        "<div class='tabs-row'><div><h1 class='title'>Driver registration</h1>" +
          "<div class='sub'>Only an administrator can create a driver account. Drivers cannot register themselves.</div></div>" +
          "<button class='btn' id='add-driver'>Register driver</button></div>" +
        "<div class='card pad-0'><div class='table-wrap'><table class='t'>" +
          "<thead><tr><th>Driver ID</th><th>Name</th><th>Username</th><th>Contact</th><th>License</th><th>Status</th><th>Activation</th><th>Assigned vehicle</th><th>Registered</th><th>Actions</th></tr></thead><tbody>" +
          (drivers.length ? drivers.map(function (d) {
            var u = db.users.filter(function (x) { return x.id === d.userId; })[0];
            var v = db.vehicles.filter(function (x) { return x.id === d.vehicleId; })[0];
            return "<tr>" +
              "<td><strong>" + PARA.esc(d.code) + "</strong></td>" +
              "<td>" + PARA.esc(d.fullName) + "</td>" +
              "<td>" + PARA.esc(u ? u.username : "—") + (u && !u.active ? " <span class='tag t-red'>disabled</span>" : "") + "</td>" +
              "<td>" + PARA.esc(d.contact || "—") + "</td>" +
              "<td>" + PARA.esc(d.license || "—") + "</td>" +
              "<td>" + PARA.tag(d.status, PARA.titleize(d.status)) + "</td>" +
              "<td>" + PARA.tag(d.activation, PARA.titleize(d.activation)) + "</td>" +
              "<td>" + (v ? PARA.esc(v.name) + " <span class='card-note'>(" + PARA.esc(v.code) + ")</span>" : "<span class='tag t-amber'>unassigned</span>") + "</td>" +
              "<td class='card-note'>" + PARA.esc(PARA.fmt.date(d.registeredAt)) + "</td>" +
              "<td><div class='pill-row'>" +
                (d.status === "active"
                  ? "<button class='btn ghost sm' data-suspend='" + d.id + "'>Deactivate</button>"
                  : "<button class='btn sm' data-activate='" + d.id + "'>Reactivate</button>") +
                "<button class='btn ghost sm' data-assign='" + d.id + "'>Assign vehicle</button>" +
                "<button class='btn ghost sm' data-activity='" + d.id + "'>Activity</button>" +
              "</div></td></tr>";
          }).join("") : "<tr><td colspan='10'><div class='empty'>No drivers registered yet. Use “Register driver” to create the first account.</div></td></tr>") +
        "</tbody></table></div></div>";

      root.querySelector("#add-driver").addEventListener("click", function () {
        PARA.ui.modal({
          title: "Register a driver",
          body:
            PARA.ui.field("Full name", "<input class='in' name='fullName' required>") +
            "<div class='row2'>" +
              PARA.ui.field("Driver ID", "<input class='in' name='code' placeholder='DRV-004' required>") +
              PARA.ui.field("Contact number", "<input class='in' name='contact'>") +
            "</div>" +
            "<div class='row2'>" +
              PARA.ui.field("Login username", "<input class='in' name='username' required>") +
              PARA.ui.field("Temporary password", "<input class='in' name='password' type='text' value='driver123' required>") +
            "</div>" +
            PARA.ui.field("License number", "<input class='in' name='license'>") +
            PARA.ui.field("Assign vehicle (optional)", "<select class='in' name='vehicleId'><option value=''>Assign later</option>" +
              db.vehicles.map(function (v) { return "<option value='" + v.id + "'>" + PARA.esc(v.code + " — " + v.name) + "</option>"; }).join("") + "</select>") +
            "<div class='alert info'>The account is created in a pending state. Activate it below to let the driver sign in.</div>",
          onOk: function (box) {
            var f = new FormData(box.querySelector("form") || box);
            var get = function (n) { var el = box.querySelector("[name='" + n + "']"); return el ? el.value : ""; };
            if (db.users.some(function (x) { return x.username.toLowerCase() === get("username").toLowerCase(); })) {
              PARA.ui.toast("That username is already taken", "bad"); return false;
            }
            if (db.drivers.some(function (x) { return x.code.toLowerCase() === get("code").toLowerCase(); })) {
              PARA.ui.toast("That driver ID already exists", "bad"); return false;
            }
            var uid = PARA.store.uid("usr");
            db.users.push({
              id: uid, username: get("username"), password: get("password") || "driver123", role: "driver",
              fullName: get("fullName"), email: null, phone: get("contact"), active: true, activated: false,
              mustChangePassword: true, createdAt: new Date().toISOString(), lastLoginAt: null
            });
            var drv = {
              id: PARA.store.uid("drv"), userId: uid, code: get("code"), fullName: get("fullName"),
              contact: get("contact"), license: get("license"), status: "inactive", activation: "pending",
              vehicleId: get("vehicleId") || null, registeredAt: new Date().toISOString()
            };
            db.drivers.push(drv);
            var veh = db.vehicles.filter(function (v) { return v.id === drv.vehicleId; })[0];
            if (veh) veh.driverId = drv.id;
            PARa_record("register_driver", "driver", drv.id, "Registered " + drv.code + " " + drv.fullName);
            PARA.store.save();
            PARA.ui.toast("Driver registered. Activate the account to allow sign-in.", "good");
            render();
          }
        });
      });

      root.querySelectorAll("[data-activate]").forEach(function (b) {
        b.addEventListener("click", function () {
          var d = db.drivers.filter(function (x) { return x.id === b.getAttribute("data-activate"); })[0];
          var u = db.users.filter(function (x) { return x.id === d.userId; })[0];
          d.status = "active"; d.activation = "activated";
          if (u) { u.active = true; u.activated = true; }
          PARa_record("activate_driver", "driver", d.id, "Activated " + d.code);
          PARA.store.save();
          PARA.ui.toast(d.fullName + " activated", "good");
          render();
        });
      });

      root.querySelectorAll("[data-suspend]").forEach(function (b) {
        b.addEventListener("click", function () {
          var id = b.getAttribute("data-suspend");
          var d = db.drivers.filter(function (x) { return x.id === id; })[0];
          PARA.ui.confirm("Deactivate driver", "Deactivate " + d.fullName + "? They will not be able to sign in and any running trip stays on record.", function () {
            var u = db.users.filter(function (x) { return x.id === d.userId; })[0];
            d.status = "suspended"; d.activation = "deactivated";
            if (u) { u.active = false; u.activated = false; }
            PARa_record("deactivate_driver", "driver", d.id, "Deactivated " + d.code);
            PARA.store.save();
            PARA.ui.toast(d.fullName + " deactivated");
            render();
          }, "Deactivate");
        });
      });

      root.querySelectorAll("[data-assign]").forEach(function (b) {
        b.addEventListener("click", function () {
          var d = db.drivers.filter(function (x) { return x.id === b.getAttribute("data-assign"); })[0];
          PARA.ui.modal({
            title: "Assign vehicle to " + d.fullName,
            body: PARA.ui.field("Vehicle", "<select class='in' id='assign-sel'><option value=''>No vehicle</option>" +
              db.vehicles.map(function (v) {
                var taken = db.drivers.filter(function (x) { return x.vehicleId === v.id && x.id !== d.id; })[0];
                return "<option value='" + v.id + "'" + (d.vehicleId === v.id ? " selected" : "") + ">" +
                  PARA.esc(v.code + " — " + v.name) + (taken ? " (assigned to " + PARA.esc(taken.fullName) + ")" : "") + "</option>";
              }).join("") + "</select>"),
            onOk: function (box) {
              var val = box.querySelector("#assign-sel").value;
              db.drivers.forEach(function (x) { if (x.vehicleId && (!val || x.id !== d.id) && db.vehicles.some(function (v) { return v.id === x.vehicleId; })) { var v0 = db.vehicles.filter(function (v) { return v.id === x.vehicleId; })[0]; if (v0 && v0.driverId === x.id) v0.driverId = null; } });
              d.vehicleId = val || null;
              if (val) { var v = db.vehicles.filter(function (x) { return x.id === val; })[0]; if (v) v.driverId = d.id; }
              PARa_record("assign_vehicle", "driver", d.id, "Vehicle assignment updated for " + d.code);
              PARA.store.save();
              PARA.ui.toast("Vehicle assignment updated", "good");
              render();
            }
          });
        });
      });

      root.querySelectorAll("[data-activity]").forEach(function (b) {
        b.addEventListener("click", function () {
          var d = db.drivers.filter(function (x) { return x.id === b.getAttribute("data-activity"); })[0];
          var trips = db.trips.filter(function (t) { return t.driverId === d.id; }).sort(function (a, b2) { return new Date(b2.startAt) - new Date(a.startAt); });
          var total = trips.reduce(function (a, t) { return a + (t.passengers || 0); }, 0);
          PARA.ui.modal({
            wide: true,
            title: "Driver activity — " + d.fullName,
            footer: false,
            body:
              "<div class='grid g3' style='margin-bottom:16px'>" +
                kpi("Trips", trips.length) +
                kpi("Passengers", total) +
                kpi("Avg trip", PARA.fmt.mins(PARA.analytics.avg(trips.map(function (t) { return t.durationMin; })))) +
              "</div>" +
              (trips.length ? "<div class='table-wrap'><table class='t'><thead><tr><th>Trip</th><th>Started</th><th>Ended</th><th class='num'>Pax</th><th class='num'>Duration</th><th>Status</th></tr></thead><tbody>" +
                trips.map(function (t) {
                  return "<tr><td>" + PARA.esc(t.code) + "</td><td>" + PARA.esc(PARA.fmt.dateTime(t.startAt)) + "</td>" +
                    "<td>" + (t.endAt ? PARA.esc(PARA.fmt.dateTime(t.endAt)) : "—") + "</td>" +
                    "<td class='num'>" + (t.passengers || 0) + "</td><td class='num'>" + PARA.esc(PARA.fmt.mins(t.durationMin)) + "</td>" +
                    "<td>" + PARA.tag(t.status, PARA.CONST.tripLabel[t.status]) + "</td></tr>";
                }).join("") + "</tbody></table></div>" : "<div class='empty'>This driver has not completed any trips yet.</div>")
          });
        });
      });
    }
    render();
  };

  V["admin-vehicles"] = function (root) {
    if (!PARA.auth.requireRole("admin")) { location.hash = "#/"; return; }
    var db = PARA.store.db;

    function render() {
      root.innerHTML =
        "<div class='tabs-row'><div><h1 class='title'>Vehicle management</h1>" +
          "<div class='sub'>Fleet records, assignment, and operating status.</div></div>" +
          "<button class='btn' id='add-veh'>Add vehicle</button></div>" +
        "<div class='card pad-0'><div class='table-wrap'><table class='t'>" +
          "<thead><tr><th>Vehicle</th><th>Type</th><th class='num'>Capacity</th><th>Plate</th><th>Status</th><th>GPS</th><th>Assigned driver</th><th>Last GPS</th><th>Actions</th></tr></thead><tbody>" +
          (db.vehicles.length ? db.vehicles.map(function (v) {
            var d = db.drivers.filter(function (x) { return x.id === v.driverId; })[0];
            return "<tr>" +
              "<td><strong>" + PARA.esc(v.name) + "</strong><div class='stop-meta'>" + PARA.esc(v.code) + (v.make ? " · " + PARA.esc([v.make, v.model, v.year].filter(Boolean).join(" ")) : "") + "</div></td>" +
              "<td>" + PARA.esc(v.type || "—") + "</td><td class='num'>" + (v.capacity || "—") + "</td>" +
              "<td>" + PARA.esc(v.plate || "—") + "</td>" +
              "<td>" + PARA.tag(v.status, PARA.CONST.vehicleLabel[v.status]) + "</td>" +
              "<td>" + PARA.tag(PARA.geo.gpsFreshness(v), PARA.geo.gpsFreshness(v)) + "</td>" +
              "<td>" + (d ? PARA.esc(d.fullName) : "<span class='tag t-amber'>unassigned</span>") + "</td>" +
              "<td class='card-note'>" + PARA.esc(PARA.fmt.ago(v.lastGpsAt)) + "</td>" +
              "<td><div class='pill-row'>" +
                "<button class='btn ghost sm' data-edit='" + v.id + "'>Edit</button>" +
                (v.status === "out_of_service"
                  ? "<button class='btn sm' data-in='" + v.id + "'>Return to service</button>"
                  : "<button class='btn ghost sm' data-out='" + v.id + "'>Take out of service</button>") +
              "</div></td></tr>";
          }).join("") : "<tr><td colspan='9'><div class='empty'>No vehicles yet.</div></td></tr>") +
        "</tbody></table></div></div>" +
        "<div class='card'><div class='card-head'><h3>Vehicle status meanings</h3></div>" +
          "<div class='pill-row'>" + PARA.CONST.vehicleStatus.map(function (s) { return PARA.tag(s, PARA.CONST.vehicleLabel[s]); }).join("") + "</div>" +
          "<p class='hint' style='margin-top:10px'>GPS status is reported separately from operating status. A missing GPS signal is flagged as a data-quality issue, not treated as proof that the vehicle stopped.</p>" +
        "</div>";

      function form(v) {
        v = v || {};
        return PARA.ui.field("Vehicle code", "<input class='in' name='code' value='" + PARA.esc(v.code || "") + "'" + (v.id ? " readonly" : " required") + ">") +
          PARA.ui.field("Vehicle name", "<input class='in' name='name' value='" + PARA.esc(v.name || "") + "' required>") +
          "<div class='row3'>" +
            PARA.ui.field("Type", "<input class='in' name='type' value='" + PARA.esc(v.type || "") + "' placeholder='Mini Bus'>") +
            PARA.ui.field("Passenger capacity", "<input class='in' type='number' name='capacity' value='" + (v.capacity || "") + "'>") +
            PARA.ui.field("Plate number", "<input class='in' name='plate' value='" + PARA.esc(v.plate || "") + "'>") +
          "</div>" +
          "<div class='row3'>" +
            PARA.ui.field("Make", "<input class='in' name='make' value='" + PARA.esc(v.make || "") + "'>") +
            PARA.ui.field("Model", "<input class='in' name='model' value='" + PARA.esc(v.model || "") + "'>") +
            PARA.ui.field("Year", "<input class='in' type='number' name='year' value='" + (v.year || "") + "'>") +
          "</div>";
      }

      root.querySelector("#add-veh").addEventListener("click", function () {
        PARA.ui.modal({
          title: "Add vehicle", body: form(null),
          onOk: function (box) {
            var g = function (n) { var el = box.querySelector("[name='" + n + "']"); return el ? el.value.trim() : ""; };
            if (db.vehicles.some(function (x) { return x.code.toLowerCase() === g("code").toLowerCase(); })) { PARA.ui.toast("Vehicle code already exists", "bad"); return false; }
            var veh = {
              id: PARA.store.uid("veh"), code: g("code"), name: g("name"), type: g("type"),
              capacity: g("capacity") ? Number(g("capacity")) : null, plate: g("plate"),
              make: g("make"), model: g("model"), year: g("year") ? Number(g("year")) : null,
              status: "available", gpsStatus: "unavailable", driverId: null,
              lastService: new Date().toISOString().slice(0, 10), notes: "", createdAt: new Date().toISOString()
            };
            db.vehicles.push(veh);
            PARa_record("add_vehicle", "vehicle", veh.id, "Added " + veh.code + " " + veh.name);
            PARA.store.save();
            PARA.ui.toast("Vehicle added", "good");
            render();
          }
        });
      });

      root.querySelectorAll("[data-edit]").forEach(function (b) {
        b.addEventListener("click", function () {
          var v = db.vehicles.filter(function (x) { return x.id === b.getAttribute("data-edit"); })[0];
          PARA.ui.modal({
            title: "Edit " + v.name,
            body: form(v) +
              "<div class='row2'>" +
                PARA.ui.field("Operating status", "<select class='in' name='status'>" + PARA.ui.options(PARA.CONST.vehicleStatus, v.status, function (s) { return PARA.CONST.vehicleLabel[s]; }) + "</select>") +
                PARA.ui.field("Notes", "<input class='in' name='notes' value='" + PARA.esc(v.notes || "") + "'>") +
              "</div>",
            onOk: function (box) {
              var g = function (n) { var el = box.querySelector("[name='" + n + "']"); return el ? el.value.trim() : ""; };
              v.name = g("name"); v.type = g("type"); v.capacity = g("capacity") ? Number(g("capacity")) : null;
              v.plate = g("plate"); v.make = g("make"); v.model = g("model");
              v.year = g("year") ? Number(g("year")) : null; v.status = g("status"); v.notes = g("notes");
              PARa_record("update_vehicle", "vehicle", v.id, "Updated " + v.code);
              PARA.store.save();
              PARA.ui.toast("Vehicle updated", "good");
              render();
            }
          });
        });
      });

      root.querySelectorAll("[data-out]").forEach(function (b) {
        b.addEventListener("click", function () {
          var v = db.vehicles.filter(function (x) { return x.id === b.getAttribute("data-out"); })[0];
          v.status = "out_of_service";
          PARa_record("deactivate_vehicle", "vehicle", v.id, "Took " + v.code + " out of service");
          PARA.store.save();
          PARA.ui.toast(v.name + " taken out of service");
          render();
        });
      });

      root.querySelectorAll("[data-in]").forEach(function (b) {
        b.addEventListener("click", function () {
          var v = db.vehicles.filter(function (x) { return x.id === b.getAttribute("data-in"); })[0];
          v.status = "available";
          PARa_record("activate_vehicle", "vehicle", v.id, "Returned " + v.code + " to service");
          PARA.store.save();
          PARA.ui.toast(v.name + " returned to service", "good");
          render();
        });
      });
    }
    render();
  };

  V["admin-route"] = function (root) {
    if (!PARA.auth.requireRole("admin")) { location.hash = "#/"; return; }
    var db = PARA.store.db;
    var route = db.routes[0];

    function render() {
      var stops = PARA.geo.stops(route.id);
      var demand = PARA.analytics.demandByStop(PARA.analytics.range("month"));
      var byId = {};
      demand.forEach(function (d) { byId[d.stop.id] = d; });

      root.innerHTML =
        "<h1 class='title'>Route &amp; stops</h1>" +
        "<div class='sub'>Stops are stored as structured records so the system can calculate progress, arrival estimates, demand and delay patterns.</div>" +
        "<div class='card'><div class='card-head'><h3>" + PARA.esc(route.name) + " (" + PARA.esc(route.code) + ")</h3>" +
          "<button class='btn ghost sm' id='edit-route'>Edit route details</button></div>" +
          "<div class='grid g4'>" +
            "<div><div class='card-note'>Start point</div><strong>" + PARA.esc(route.startPoint) + "</strong></div>" +
            "<div><div class='card-note'>End point</div><strong>" + PARA.esc(route.endPoint) + "</strong></div>" +
            "<div><div class='card-note'>Service hours</div><strong>" + PARA.esc(route.operatingHours.start) + "–" + PARA.esc(route.operatingHours.end) + "</strong></div>" +
            "<div><div class='card-note'>Stops / distance</div><strong>" + stops.length + " · " + PARA.esc(route.distanceKm) + " km</strong></div>" +
          "</div>" +
          (route.description ? "<p class='hint' style='margin-top:12px'>" + PARA.esc(route.description) + "</p>" : "") +
        "</div>" +
        "<div class='card pad-0'>" +
          "<div class='card-head' style='padding:16px 18px 0'><h3>Stops in order</h3>" +
            "<div class='pill-row'><button class='btn sm' id='add-stop'>Add stop</button>" +
            "<span class='card-note'>Use ↑ ↓ to change the running order</span></div></div>" +
          "<div class='table-wrap'><table class='t'>" +
          "<thead><tr><th>Order</th><th>Stop</th><th>Location</th><th class='num'>Lat</th><th class='num'>Lng</th>" +
          "<th class='num'>From prev</th><th class='num'>To next</th><th class='num'>30d demand</th><th class='num'>Avg wait</th><th>Flags</th><th>Actions</th></tr></thead><tbody>" +
          stops.map(function (s, i) {
            var d = byId[s.id] || {};
            var flags = [];
            if (s.shelter) flags.push("Shelter");
            if (s.seating) flags.push("Seating");
            if (s.accessible) flags.push("Accessible");
            return "<tr>" +
              "<td><strong>" + s.position + "</strong></td>" +
              "<td><strong>" + PARA.esc(s.name) + "</strong><div class='stop-meta'>" + PARA.esc(s.code) + "</div></td>" +
              "<td>" + PARA.esc(s.location || "—") + "</td>" +
              "<td class='num'>" + (s.lat != null ? s.lat.toFixed(4) : "—") + "</td>" +
              "<td class='num'>" + (s.lng != null ? s.lng.toFixed(4) : "—") + "</td>" +
              "<td class='num'>" + (s.travelFromPrev == null ? "—" : s.travelFromPrev) + "</td>" +
              "<td class='num'>" + (s.travelToNext == null ? "—" : s.travelToNext) + "</td>" +
              "<td class='num'>" + (d.requests != null ? d.requests : 0) + "</td>" +
              "<td class='num'>" + (d.avgWait != null ? PARA.fmt.mins(d.avgWait) : "—") + "</td>" +
              "<td class='card-note'>" + (flags.length ? PARA.esc(flags.join(" · ")) : "—") + "</td>" +
              "<td><div class='pill-row'>" +
                "<button class='btn ghost sm' data-up='" + s.id + "'" + (i === 0 ? " disabled" : "") + ">↑</button>" +
                "<button class='btn ghost sm' data-down='" + s.id + "'" + (i === stops.length - 1 ? " disabled" : "") + ">↓</button>" +
                "<button class='btn ghost sm' data-editstop='" + s.id + "'>Edit</button>" +
                "<button class='btn ghost sm' data-del='" + s.id + "'>Delete</button>" +
              "</div></td></tr>";
          }).join("") +
        "</tbody></table></div></div>";

      root.querySelector("#edit-route").addEventListener("click", function () {
        PARA.ui.modal({
          title: "Edit route",
          body:
            PARA.ui.field("Route name", "<input class='in' name='name' value='" + PARA.esc(route.name) + "'>") +
            "<div class='row2'>" +
              PARA.ui.field("Starting point", "<input class='in' name='startPoint' value='" + PARA.esc(route.startPoint) + "'>") +
              PARA.ui.field("Ending point", "<input class='in' name='endPoint' value='" + PARA.esc(route.endPoint) + "'>") +
            "</div>" +
            "<div class='row2'>" +
              PARA.ui.field("First trip", "<input class='in' type='time' name='start' value='" + PARA.esc(route.operatingHours.start) + "'>") +
              PARA.ui.field("Last trip", "<input class='in' type='time' name='end' value='" + PARA.esc(route.operatingHours.end) + "'>") +
            "</div>" +
            "<div class='row2'>" +
              PARA.ui.field("Distance (km)", "<input class='in' type='number' step='0.1' name='distanceKm' value='" + route.distanceKm + "'>") +
              PARA.ui.field("Route status", "<select class='in' name='status'>" + PARA.ui.options(["active", "limited", "suspended", "inactive"], route.status) + "</select>") +
            "</div>" +
            PARA.ui.field("Description", "<textarea class='in' name='description'>" + PARA.esc(route.description || "") + "</textarea>"),
          onOk: function (box) {
            var g = function (n) { var el = box.querySelector("[name='" + n + "']"); return el ? el.value.trim() : ""; };
            route.name = g("name"); route.startPoint = g("startPoint"); route.endPoint = g("endPoint");
            route.operatingHours.start = g("start"); route.operatingHours.end = g("end");
            route.distanceKm = Number(g("distanceKm")) || route.distanceKm;
            route.status = g("status"); route.description = g("description");
            route.estDurationMin = Math.round(PARA.geo.totalMinutes(route.id) || route.estDurationMin);
            PARa_record("update_route", "route", route.id, "Updated route details");
            PARA.store.save();
            PARA.ui.toast("Route updated", "good");
            render();
          }
        });
      });

      function stopForm(s) {
        s = s || {};
        return PARA.ui.field("Stop name", "<input class='in' name='name' value='" + PARA.esc(s.name || "") + "' required>") +
          "<div class='row2'>" +
            PARA.ui.field("Stop code", "<input class='in' name='code' value='" + PARA.esc(s.code || "") + "' placeholder='STP-009' required>") +
            PARA.ui.field("Position in route", "<input class='in' type='number' name='position' value='" + (s.position || stops.length + 1) + "' min='1'>") +
          "</div>" +
          PARA.ui.field("Location description", "<input class='in' name='location' value='" + PARA.esc(s.location || "") + "'>") +
          "<div class='row2'>" +
            PARA.ui.field("Latitude", "<input class='in' type='number' step='any' name='lat' value='" + (s.lat != null ? s.lat : "") + "'>") +
            PARA.ui.field("Longitude", "<input class='in' type='number' step='any' name='lng' value='" + (s.lng != null ? s.lng : "") + "'>") +
          "</div>" +
          "<div class='row2'>" +
            PARA.ui.field("Minutes from previous stop", "<input class='in' type='number' name='fromPrev' value='" + (s.travelFromPrev != null ? s.travelFromPrev : "") + "'>") +
            PARA.ui.field("Minutes to next stop", "<input class='in' type='number' name='toNext' value='" + (s.travelToNext != null ? s.travelToNext : "") + "'>") +
          "</div>" +
          "<div class='row3'>" +
            "<label class='chk'><input type='checkbox' name='shelter'" + (s.shelter ? " checked" : "") + "><span>Shelter</span></label>" +
            "<label class='chk'><input type='checkbox' name='seating'" + (s.seating ? " checked" : "") + "><span>Seating</span></label>" +
            "<label class='chk'><input type='checkbox' name='accessible'" + (s.accessible !== false ? " checked" : "") + "><span>Accessible</span></label>" +
          "</div>" +
          PARA.ui.field("Notes", "<textarea class='in' name='notes'>" + PARA.esc(s.notes || "") + "</textarea>");
      }

      root.querySelector("#add-stop").addEventListener("click", function () {
        PARA.ui.modal({
          title: "Add stop", body: stopForm(null),
          onOk: function (box) {
            var g = function (n) { var el = box.querySelector("[name='" + n + "']"); return el ? el.value.trim() : ""; };
            var ck = function (n) { var el = box.querySelector("[name='" + n + "']"); return !!(el && el.checked); };
            if (db.stops.some(function (x) { return x.code.toLowerCase() === g("code").toLowerCase(); })) { PARA.ui.toast("Stop code already exists", "bad"); return false; }
            var last = stops[stops.length - 1];
            var st = {
              id: PARA.store.uid("stp"), code: g("code"), name: g("name"), location: g("location"),
              lat: g("lat") ? Number(g("lat")) : (last ? last.lat - 0.002 : 0),
              lng: g("lng") ? Number(g("lng")) : (last ? last.lng - 0.002 : 0),
              routeId: route.id, position: g("position") ? Number(g("position")) : stops.length + 1,
              travelFromPrev: g("fromPrev") ? Number(g("fromPrev")) : 5,
              travelToNext: g("toNext") ? Number(g("toNext")) : 5,
              demand: 0, avgWaitMin: null, shelter: ck("shelter"), seating: ck("seating"),
              accessible: ck("accessible"), notes: g("notes"), eta: null, updatedAt: new Date().toISOString()
            };
            db.stops.push(st);
            if (st.position > stops.length) {
              db.stops.forEach(function (x) { if (x.routeId === route.id && x.position > st.position) x.position++; });
            }
            PARa_record("add_stop", "stop", st.id, "Added " + st.code + " " + st.name);
            PARA.store.save();
            PARA.ui.toast("Stop added", "good");
            render();
          }
        });
      });

      root.querySelectorAll("[data-editstop]").forEach(function (b) {
        b.addEventListener("click", function () {
          var s = db.stops.filter(function (x) { return x.id === b.getAttribute("data-editstop"); })[0];
          PARA.ui.modal({
            title: "Edit " + s.name, body: stopForm(s),
            onOk: function (box) {
              var g = function (n) { var el = box.querySelector("[name='" + n + "']"); return el ? el.value.trim() : ""; };
              var ck = function (n) { var el = box.querySelector("[name='" + n + "']"); return !!(el && el.checked); };
              s.name = g("name"); s.code = g("code"); s.location = g("location");
              s.lat = g("lat") ? Number(g("lat")) : s.lat;
              s.lng = g("lng") ? Number(g("lng")) : s.lng;
              s.travelFromPrev = g("fromPrev") ? Number(g("fromPrev")) : null;
              s.travelToNext = g("toNext") ? Number(g("toNext")) : null;
              s.shelter = ck("shelter"); s.seating = ck("seating"); s.accessible = ck("accessible");
              s.notes = g("notes");
              if (g("position") && Number(g("position")) !== s.position) {
                var target = Math.max(1, Number(g("position")));
                var ordered = PARA.geo.stops(route.id);
                var moved = ordered.splice(ordered.findIndex(function (x) { return x.id === s.id; }), 1)[0];
                ordered.splice(Math.min(target - 1, ordered.length), 0, moved);
                ordered.forEach(function (x, i) { x.position = i + 1; });
              }
              PARa_record("update_stop", "stop", s.id, "Updated " + s.code);
              PARA.store.save();
              PARA.ui.toast("Stop updated", "good");
              render();
            }
          });
        });
      });

      function move(id, dir) {
        var ordered = PARA.geo.stops(route.id);
        var i = ordered.findIndex(function (x) { return x.id === id; });
        var j = i + dir;
        if (i < 0 || j < 0 || j >= ordered.length) return;
        var tmp = ordered[i]; ordered[i] = ordered[j]; ordered[j] = tmp;
        ordered.forEach(function (x, k) { x.position = k + 1; });
        PARA.store.save();
        render();
      }
      root.querySelectorAll("[data-up]").forEach(function (b) { b.addEventListener("click", function () { move(b.getAttribute("data-up"), -1); }); });
      root.querySelectorAll("[data-down]").forEach(function (b) { b.addEventListener("click", function () { move(b.getAttribute("data-down"), 1); }); });

      root.querySelectorAll("[data-del]").forEach(function (b) {
        b.addEventListener("click", function () {
          var s = db.stops.filter(function (x) { return x.id === b.getAttribute("data-del"); })[0];
          var used = db.requests.filter(function (q) { return q.originId === s.id || q.destId === s.id; }).length;
          PARA.ui.confirm("Delete stop", "Remove " + s.name + " from the route?" + (used ? " It is referenced by " + used + " passenger request(s); those records stay but the stop will no longer be selectable." : ""), function () {
            db.stops = db.stops.filter(function (x) { return x.id !== s.id; });
            PARA.geo.stops(route.id).forEach(function (x, i) { x.position = i + 1; });
            PARa_record("delete_stop", "stop", s.id, "Deleted " + s.code);
            PARA.store.save();
            PARA.ui.toast("Stop deleted");
            render();
          }, "Delete");
        });
      });
    }
    render();
  };

  V["admin-announcements"] = function (root) {
    if (!PARA.auth.requireRole("admin")) { location.hash = "#/"; return; }
    var db = PARA.store.db;

    function render() {
      root.innerHTML =
        "<div class='tabs-row'><div><h1 class='title'>Announcements</h1>" +
          "<div class='sub'>Official notices shown to the public and to drivers.</div></div>" +
          "<button class='btn' id='new-ann'>New announcement</button></div>" +
        "<div class='card pad-0'><div class='table-wrap'><table class='t'>" +
          "<thead><tr><th>Title</th><th>Priority</th><th>Window</th><th>Status</th><th>Posted</th><th>Actions</th></tr></thead><tbody>" +
          (db.announcements.length ? db.announcements.map(function (a) {
            return "<tr><td><strong>" + PARA.esc(a.title) + "</strong><div class='stop-meta'>" + PARA.esc(a.description) + "</div></td>" +
              "<td>" + PARA.tag(a.priority, PARA.titleize(a.priority)) + "</td>" +
              "<td class='card-note'>" + (a.startAt ? PARA.esc(PARA.fmt.dateTime(a.startAt)) : "—") + "<br>" + (a.endAt ? "until " + PARA.esc(PARA.fmt.dateTime(a.endAt)) : "no end") + "</td>" +
              "<td>" + PARA.tag(a.status, PARA.titleize(a.status)) + "</td>" +
              "<td class='card-note'>" + PARA.esc(PARA.fmt.ago(a.createdAt)) + "</td>" +
              "<td><div class='pill-row'>" +
                (a.status !== "published" ? "<button class='btn sm' data-pub='" + a.id + "'>Publish</button>" : "<button class='btn ghost sm' data-exp='" + a.id + "'>End now</button>") +
                "<button class='btn ghost sm' data-alert='" + a.id + "'>Send as alert</button>" +
                "<button class='btn ghost sm' data-del='" + a.id + "'>Delete</button>" +
              "</div></td></tr>";
          }).join("") : "<tr><td colspan='6'><div class='empty'>No announcements yet.</div></td></tr>") +
        "</tbody></table></div></div>";

      root.querySelector("#new-ann").addEventListener("click", function () {
        PARA.ui.modal({
          title: "New announcement",
          body:
            PARA.ui.field("Title", "<input class='in' name='title' required>") +
            PARA.ui.field("Message", "<textarea class='in' name='description' required></textarea>") +
            "<div class='row3'>" +
              PARA.ui.field("Priority", "<select class='in' name='priority'>" + PARA.ui.options(["low", "normal", "high", "critical"], "normal") + "</select>") +
              PARA.ui.field("Starts", "<input class='in' type='datetime-local' name='startAt'>") +
              PARA.ui.field("Ends", "<input class='in' type='datetime-local' name='endAt'>") +
            "</div>" +
            "<div class='alert info'>Publishing also creates an in-app alert for passengers who have that alert type enabled.</div>",
          onOk: function (box) {
            var g = function (n) { var el = box.querySelector("[name='" + n + "']"); return el ? el.value.trim() : ""; };
            var a = {
              id: PARA.store.uid("ann"), title: g("title"), description: g("description"),
              priority: g("priority") || "normal",
              startAt: g("startAt") ? new Date(g("startAt")).toISOString() : new Date().toISOString(),
              endAt: g("endAt") ? new Date(g("endAt")).toISOString() : null,
              status: "published", createdBy: (PARA.auth.user() || {}).fullName || "Admin", createdAt: new Date().toISOString()
            };
            db.announcements.unshift(a);
            if (a.priority === "high" || a.priority === "critical") {
              PARA.log.broadcast({ type: a.priority === "critical" ? "service_interruption" : "announcement", title: a.title, body: a.description, priority: a.priority });
            }
            PARa_record("create_announcement", "announcement", a.id, "Published: " + a.title);
            PARA.store.save();
            PARA.ui.toast("Announcement published", "good");
            render();
          }
        });
      });

      root.querySelectorAll("[data-pub]").forEach(function (b) {
        b.addEventListener("click", function () {
          var a = db.announcements.filter(function (x) { return x.id === b.getAttribute("data-pub"); })[0];
          a.status = "published"; a.startAt = new Date().toISOString();
          PARa_record("publish_announcement", "announcement", a.id, "Published: " + a.title);
          PARA.store.save(); render();
        });
      });
      root.querySelectorAll("[data-exp]").forEach(function (b) {
        b.addEventListener("click", function () {
          var a = db.announcements.filter(function (x) { return x.id === b.getAttribute("data-exp"); })[0];
          a.status = "expired"; a.endAt = new Date().toISOString();
          PARa_record("end_announcement", "announcement", a.id, "Ended: " + a.title);
          PARA.store.save(); render();
        });
      });
      root.querySelectorAll("[data-alert]").forEach(function (b) {
        b.addEventListener("click", function () {
          var a = db.announcements.filter(function (x) { return x.id === b.getAttribute("data-alert"); })[0];
          PARA.log.broadcast({ type: "announcement", title: a.title, body: a.description, priority: a.priority });
          PARa_record("send_alert", "announcement", a.id, "Alert sent: " + a.title);
          PARA.store.save();
          PARA.ui.toast("Alert sent to subscribed passengers", "good");
        });
      });
      root.querySelectorAll("[data-del]").forEach(function (b) {
        b.addEventListener("click", function () {
          var a = db.announcements.filter(function (x) { return x.id === b.getAttribute("data-del"); })[0];
          PARA.ui.confirm("Delete announcement", "Delete “" + a.title + "”?", function () {
            db.announcements = db.announcements.filter(function (x) { return x.id !== a.id; });
            PARa_record("delete_announcement", "announcement", a.id, "Deleted: " + a.title);
            PARA.store.save(); render();
          }, "Delete");
        });
      });
    }
    render();
  };

  V["admin-incidents"] = function (root) {
    if (!PARA.auth.requireRole("admin")) { location.hash = "#/"; return; }
    var db = PARA.store.db;
    var tab = "incidents";

    function render() {
      var who = function (id, type) {
        var u = db.users.filter(function (x) { return x.id === id; })[0];
        return u ? u.fullName : (type || "unknown");
      };
      root.innerHTML =
        "<h1 class='title'>Incidents &amp; reports</h1>" +
        "<div class='sub'>Everything reported by drivers and passengers, with review status and resolution notes.</div>" +
        "<div class='tabs'>" +
          "<div class='tab" + (tab === "incidents" ? " on" : "") + "' data-tab='incidents'>Incidents (" + db.incidents.length + ")</div>" +
          "<div class='tab" + (tab === "reports" ? " on" : "") + "' data-tab='reports'>Passenger &amp; driver reports (" + db.reports.length + ")</div>" +
        "</div>" +
        (tab === "incidents"
          ? "<div class='card pad-0'><div class='table-wrap'><table class='t'>" +
            "<thead><tr><th>ID</th><th>Reported by</th><th>When</th><th>Category</th><th>Location</th><th>Description</th><th>Status</th><th>Resolution</th></tr></thead><tbody>" +
            (db.incidents.length ? db.incidents.map(function (i) {
              return "<tr><td><strong>" + PARA.esc(i.code) + "</strong></td>" +
                "<td>" + PARA.esc(who(i.reporterId, i.reporterType)) + "<div class='stop-meta'>" + PARA.esc(i.reporterType) + "</div></td>" +
                "<td class='card-note'>" + PARA.esc(PARA.fmt.dateTime(i.at)) + "</td>" +
                "<td>" + PARA.esc(PARA.titleize(i.category)) + "</td>" +
                "<td>" + PARA.esc(i.location || "—") + "</td>" +
                "<td class='card-note' style='max-width:260px'>" + PARA.esc(i.description || "") + "</td>" +
                "<td>" + PARA.tag(i.status, PARA.titleize(i.status)) + "</td>" +
                "<td class='card-note' style='max-width:200px'>" + PARA.esc(i.resolution || "—") + "</td>" +
                "<td><button class='btn ghost sm' data-inc='" + i.id + "'>Review</button></td></tr>";
            }).join("") : "<tr><td colspan='8'><div class='empty'>No incidents reported.</div></td></tr>") +
            "</tbody></table></div></div>"
          : "<div class='card pad-0'><div class='table-wrap'><table class='t'>" +
            "<thead><tr><th>ID</th><th>From</th><th>Type</th><th>When</th><th>Location</th><th>Description</th><th>Status</th><th>Actions</th></tr></thead><tbody>" +
            (db.reports.length ? db.reports.map(function (x) {
              return "<tr><td><strong>" + PARA.esc(x.code) + "</strong></td>" +
                "<td><span class='tag " + (x.reporterType === "driver" ? "t-blue" : "t-grey") + "'>" + PARA.esc(x.reporterType) + "</span></td>" +
                "<td>" + PARA.esc(PARA.titleize(x.type)) + "</td>" +
                "<td class='card-note'>" + PARA.esc(PARA.fmt.dateTime(x.at)) + "</td>" +
                "<td>" + PARA.esc(x.location || "—") + "</td>" +
                "<td class='card-note' style='max-width:300px'>" + PARA.esc(x.description || "") + "</td>" +
                "<td>" + PARA.tag(x.status, PARA.titleize(x.status)) + "</td>" +
                "<td><button class='btn ghost sm' data-rep='" + x.id + "'>Review</button></td></tr>";
            }).join("") : "<tr><td colspan='8'><div class='empty'>No reports submitted.</div></td></tr>") +
            "</tbody></table></div></div>");

      root.querySelectorAll("[data-tab]").forEach(function (t) {
        t.addEventListener("click", function () { tab = t.getAttribute("data-tab"); render(); });
      });

      root.querySelectorAll("[data-inc]").forEach(function (b) {
        b.addEventListener("click", function () {
          var i = db.incidents.filter(function (x) { return x.id === b.getAttribute("data-inc"); })[0];
          PARA.ui.modal({
            title: "Incident " + i.code,
            body:
              "<div class='grid g2' style='margin-bottom:14px'>" +
                "<div><div class='card-note'>Reported by</div><strong>" + PARA.esc(who(i.reporterId, i.reporterType)) + "</strong></div>" +
                "<div><div class='card-note'>When</div><strong>" + PARA.esc(PARA.fmt.dateTime(i.at)) + "</strong></div>" +
                "<div><div class='card-note'>Category</div><strong>" + PARA.esc(PARA.titleize(i.category)) + "</strong></div>" +
                "<div><div class='card-note'>Location</div><strong>" + PARA.esc(i.location || "—") + "</strong></div>" +
              "</div>" +
              "<p style='font-size:14px;margin-bottom:14px'>" + PARA.esc(i.description || "") + "</p>" +
              PARA.ui.field("Status", "<select class='in' id='inc-st'>" + PARA.ui.options(PARA.CONST.incidentStatus, i.status) + "</select>") +
              PARA.ui.field("Resolution / action taken", "<textarea class='in' id='inc-res'>" + PARA.esc(i.resolution || "") + "</textarea>"),
            onOk: function (box) {
              i.status = box.querySelector("#inc-st").value;
              i.resolution = box.querySelector("#inc-res").value;
              PARa_record("update_incident", "incident", i.id, i.code + " → " + i.status);
              PARA.store.save();
              PARA.ui.toast("Incident updated", "good");
              render();
            }
          });
        });
      });

      root.querySelectorAll("[data-rep]").forEach(function (b) {
        b.addEventListener("click", function () {
          var x = db.reports.filter(function (y) { return y.id === b.getAttribute("data-rep"); })[0];
          PARA.ui.modal({
            title: "Report " + x.code,
            body:
              "<div class='grid g2' style='margin-bottom:14px'>" +
                "<div><div class='card-note'>From</div><strong>" + PARA.esc(x.reporterType) + "</strong></div>" +
                "<div><div class='card-note'>When</div><strong>" + PARA.esc(PARA.fmt.dateTime(x.at)) + "</strong></div>" +
                "<div><div class='card-note'>Type</div><strong>" + PARA.esc(PARA.titleize(x.type)) + "</strong></div>" +
                "<div><div class='card-note'>Location</div><strong>" + PARA.esc(x.location || "—") + "</strong></div>" +
              "</div>" +
              "<p style='font-size:14px;margin-bottom:14px'>" + PARA.esc(x.description || "") + "</p>" +
              PARA.ui.field("Status", "<select class='in' id='rep-st'>" + PARA.ui.options(PARA.CONST.reportStatus, x.status) + "</select>") +
              "<div class='alert info'>Repeated reports of the same type and location are counted in the analytics as recurring transportation problems.</div>",
            onOk: function (box) {
              x.status = box.querySelector("#rep-st").value;
              PARa_record("update_report", "report", x.id, x.code + " → " + x.status);
              PARA.store.save();
              PARA.ui.toast("Report updated", "good");
              render();
            }
          });
        });
      });
    }
    render();
  };

  V["admin-service"] = function (root) {
    if (!PARA.auth.requireRole("admin")) { location.hash = "#/"; return; }
    var db = PARA.store.db;
    root.innerHTML =
      "<h1 class='title'>Service status</h1>" +
      "<div class='sub'>The published status is what the public and passengers see. Drivers can report conditions that may require a status change.</div>" +
      "<div class='card' style='max-width:640px'>" +
        "<div class='card-head'><h3>Current status</h3>" + PARA.tag(db.serviceStatus, PARA.CONST.serviceLabel[db.serviceStatus]) + "</div>" +
        "<form id='svc-form'>" +
          PARA.ui.field("Status", "<select class='in' name='status'>" + PARA.ui.options(PARA.CONST.serviceStatus, db.serviceStatus, function (s) { return PARA.CONST.serviceLabel[s]; }) + "</select>") +
          PARA.ui.field("Short public note", "<input class='in' name='note' value='" + PARA.esc(db.serviceNote || "") + "' placeholder='e.g. Afternoon trips delayed near Hospital Corner'>") +
          "<button class='btn' type='submit'>Publish status</button>" +
        "</form>" +
        "<div class='card-head' style='margin-top:22px'><h3>What each status means</h3></div>" +
        "<ul class='stop-list'>" +
          "<li><div class='stop-num'>1</div><div><strong>Operating Normally</strong><div class='stop-meta'>Buses are running the published schedule.</div></div></li>" +
          "<li><div class='stop-num'>2</div><div><strong>Delayed</strong><div class='stop-meta'>Trips are running but later than usual.</div></div></li>" +
          "<li><div class='stop-num'>3</div><div><strong>Limited Service</strong><div class='stop-meta'>Only part of the route or a reduced number of trips.</div></div></li>" +
          "<li><div class='stop-num'>4</div><div><strong>Temporarily Suspended</strong><div class='stop-meta'>No trips are running. New requests are paused.</div></div></li>" +
          "<li><div class='stop-num'>5</div><div><strong>Service Resumed</strong><div class='stop-meta'>Trips restarted after a suspension or emergency.</div></div></li>" +
          "<li><div class='stop-num'>6</div><div><strong>Emergency</strong><div class='stop-meta'>Safety-critical situation. Requires immediate passenger alerts.</div></div></li>" +
        "</ul>" +
      "</div>";
    root.querySelector("#svc-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var f = new FormData(e.target);
      var prev = db.serviceStatus;
      db.serviceStatus = f.get("status");
      db.serviceNote = f.get("note") || "";
      db.serviceUpdatedAt = new Date().toISOString();
      var map = {
        delayed: "delay", limited_service: "delay", suspended: "suspension",
        resumed: "service_resumed", emergency: "service_interruption", operating_normally: null
      };
      var type = map[db.serviceStatus];
      if (type) {
        PARA.log.broadcast({
          type: type,
          title: "Service status: " + PARA.CONST.serviceLabel[db.serviceStatus],
          body: db.serviceNote || PARA.CONST.serviceLabel[db.serviceStatus],
          priority: db.serviceStatus === "emergency" ? "critical" : db.serviceStatus === "suspended" ? "high" : "normal"
        });
      }
      PARa_record("update_service_status", "service", null, PARA.CONST.serviceLabel[prev] + " → " + PARA.CONST.serviceLabel[db.serviceStatus]);
      PARA.store.save();
      PARA.ui.toast("Service status published", "good");
      PARA.render();
    });
  };

  V["admin-analytics"] = function (root) {
    if (!PARA.auth.requireRole("admin")) { location.hash = "#/"; return; }
    var rangeId = sessionStorage.getItem("para_range") || "week";

    function render() {
      var r = PARA.analytics.range(rangeId);
      var t = PARA.analytics.tripStats(r);
      var w = PARA.analytics.waitStats(r);
      var tr = PARA.analytics.travelStats(r);
      var d = PARA.analytics.delayStats(r);
      var c = PARA.analytics.capacity(r);
      var u = PARA.analytics.unmet(r);
      var peak = PARA.analytics.peak(r);
      var stops = PARA.analytics.demandByStop(r);
      var sens = PARA.analytics.demandBySensitivity(r);
      var flags = PARA.analytics.dataQuality(r);
      var patterns = PARA.analytics.patterns(r);
      var corr = PARA.analytics.correlations(r);
      var trend = PARA.analytics.trend(8);

      root.innerHTML =
        "<div class='tabs-row'><div><h1 class='title'>Community transportation intelligence</h1>" +
          "<div class='sub'>Calculated from recorded requests, trips, waiting times and GPS positions — not from assumptions.</div></div>" +
          "<div class='pill-row'>" +
            PARA.analytics.RANGES.map(function (x) {
              return "<button class='btn " + (x.id === rangeId ? "" : "ghost") + " sm' data-range='" + x.id + "'>" + PARA.esc(x.label) + "</button>";
            }).join("") +
            "<button class='btn ghost sm' id='export-all'>Export CSV</button>" +
            "<button class='btn sm' id='build-report'>Generate report</button>" +
          "</div></div>" +

        "<div class='grid g4' style='margin-bottom:18px'>" +
          kpi("Total trips", t.count) +
          kpi("Passengers transported", t.passengers) +
          kpi("Passenger requests", c.totalRequests) +
          kpi("Fulfilment rate", u.servedRate + "%", u.servedRate < 70 ? "warn" : "", u.served + " of " + u.total + " requests served") +
          kpi("Average waiting time", w.avg != null ? PARA.fmt.mins(w.avg) : "no samples", w.avg > 15 ? "warn" : "", w.count + " samples") +
          kpi("Median wait", w.median != null ? PARA.fmt.mins(w.median) : "—") +
          kpi("Longest recorded wait", w.max != null ? PARA.fmt.mins(w.max) : "—", w.max > 25 ? "warn" : "") +
          kpi("Average travel time", tr.avg != null ? PARA.fmt.mins(tr.avg) : "—", tr.avg > 8 ? "warn" : "", tr.count + " segment records") +
          kpi("Delays recorded", d.count, d.count ? "warn" : "", d.avgDelay != null ? "avg " + PARA.fmt.mins(d.avgDelay) : "") +
          kpi("Busiest hour", peak.busiest && peak.busiest.requests ? (peak.busiest.hour < 10 ? "0" : "") + peak.busiest.hour + ":00" : "no data", "") +
          kpi("Average passengers/trip", t.avgPax != null ? Math.round(t.avgPax) : "—") +
          kpi("Capacity utilisation", c.avgUtilization != null ? Math.round(c.avgUtilization) + "%" : "not measurable", c.avgUtilization > 90 ? "warn" : "", "against seats offered") +
        "</div>" +

        "<div class='grid g2'>" +
          hourlyChart(PARA.analytics.demandByHour(r), "requests", "Passenger demand by hour") +
          hourlyChart(PARA.analytics.demandByHour(r), "passengers", "Passengers transported by trip start hour") +
        "</div>" +

        "<div class='card'><div class='card-head'><h3>Peak and low demand detection</h3>" +
          "<span class='card-note'>based on " + r.label.toLowerCase() + "</span></div>" +
          "<div class='grid g4'>" +
            kpi("Morning (05–10)", peak.morning) +
            kpi("Midday (10–15)", peak.midday) +
            kpi("Evening (15–21)", peak.evening) +
            kpi("School-hour cluster", peak.schoolPeak, peak.schoolPeak > 4 ? "warn" : "", "07:00 and 15:00–17:00") +
          "</div>" +
          "<div class='alert info' style='margin-top:14px'>Busiest recorded hour: <strong>" +
            (peak.busiest && peak.busiest.requests ? (peak.busiest.hour < 10 ? "0" : "") + peak.busiest.hour + ":00–" + ((peak.busiest.hour + 1) < 10 ? "0" : "") + (peak.busiest.hour + 1) + ":00 with " + peak.busiest.requests + " requests" : "not enough data") +
          "</strong>. Quietest recorded hour: <strong>" +
            (peak.quietest ? (peak.quietest.hour < 10 ? "0" : "") + peak.quietest.hour + ":00 with " + peak.quietest.requests + " requests" : "n/a") + "</strong>.</div>" +
        "</div>" +

        "<div class='card pad-0'><div class='card-head' style='padding:16px 18px 0'><h3>Demand, waiting and fulfilment by stop</h3></div>" +
          "<div class='table-wrap'><table class='t'><thead><tr><th>Stop</th><th class='num'>Requests</th><th class='num'>As origin</th><th class='num'>As destination</th>" +
          "<th class='num'>Avg wait</th><th class='num'>Longest wait</th><th class='num'>Wait samples</th><th class='num'>Destination fulfilled</th></tr></thead><tbody>" +
          stops.map(function (s) {
            return "<tr><td><strong>" + PARA.esc(s.stop.name) + "</strong><div class='stop-meta'>" + PARA.esc(s.stop.code) + "</div></td>" +
              "<td class='num'>" + s.requests + "</td><td class='num'>" + s.asOrigin + "</td><td class='num'>" + s.asDest + "</td>" +
              "<td class='num'>" + (s.avgWait != null ? PARA.fmt.mins(s.avgWait) : "—") + "</td>" +
              "<td class='num'>" + (s.maxWait != null ? PARA.fmt.mins(s.maxWait) : "—") + "</td>" +
              "<td class='num'>" + s.waitSamples + "</td>" +
              "<td class='num'>" + (s.fulfilled != null ? s.fulfilled + "%" : "—") + "</td></tr>";
          }).join("") + "</tbody></table></div></div>" +

        "<div class='grid g2'>" +
          "<div class='card pad-0'><div class='card-head' style='padding:16px 18px 0'><h3>Demand vs available capacity by hour</h3></div>" +
            "<div class='table-wrap'><table class='t'><thead><tr><th>Hour</th><th class='num'>Requests</th><th class='num'>Seats offered</th><th class='num'>Utilisation</th><th>Pressure</th></tr></thead><tbody>" +
            c.rows.map(function (row) {
              if (!row.requests && !row.capacity) return "";
              var color = row.pressure === "over" ? "over" : row.pressure === "high" ? "hot" : "";
              return "<tr><td>" + (row.hour < 10 ? "0" : "") + row.hour + ":00</td>" +
                "<td class='num'>" + row.requests + "</td><td class='num'>" + (row.capacity || "—") + "</td>" +
                "<td class='num' style='min-width:110px'><div class='meter'><i class='" + color + "' style='width:" + Math.min(100, row.utilization || 0) + "%'></i></div>" +
                  "<span class='stop-meta'>" + (row.utilization != null ? row.utilization + "%" : "no trips") + "</span></td>" +
                "<td>" + (row.capacity ? PARA.tag(row.pressure, PARA.titleize(row.pressure) + " pressure") : "<span class='card-note'>no service</span>") + "</td></tr>";
            }).join("") + "</tbody></table></div>" +
            "<div style='padding:14px 18px'>" +
              "<div class='alert warn'>Where requests exceed the seats offered in the same hour, PARA records this as <strong>capacity pressure</strong>, not as a conclusion that the service is inadequate. Other passengers may have travelled outside the recorded hours or used other means.</div>" +
              "<div class='card-note'>Fleet capacity currently in service: " + c.fleetCapacity + " seats.</div>" +
            "</div>" +
          "</div>" +
          "<div class='card'><div class='card-head'><h3>Demand by time-sensitivity</h3><span class='card-note'>50 requests are not equal — urgency matters</span></div>" +
            sens.map(function (s) {
              return "<div style='margin-bottom:12px'><div style='display:flex;justify-content:space-between;font-size:13.5px'><strong>" + PARA.esc(s.label) + "</strong>" +
                "<span>" + s.count + " request" + (s.count === 1 ? "" : "s") + " · " + (s.count ? Math.round((s.served / s.count) * 100) : 0) + "% served</span></div>" +
                "<div class='meter' style='margin-top:5px'><i style='width:" + (s.count ? Math.round((s.count / Math.max(1, c.totalRequests)) * 100) : 0) + "%'></i></div></div>";
            }).join("") +
            "<div class='card-head' style='margin-top:20px'><h3>Requests that were not fulfilled</h3></div>" +
            (u.byStatus.length
              ? "<ul class='stop-list'>" + u.byStatus.map(function (s) {
                  return "<li><div class='stop-num'>" + s.count + "</div><div><strong>" + PARA.esc(PARA.CONST.requestLabel[s.status] || s.status) + "</strong>" +
                    "<div class='stop-meta'>" + (s.status === "used_other" ? "Passenger travelled another way — not a service failure." : s.status === "capacity_unavailable" ? "Vehicle was full at the time." : s.status === "missed_vehicle" ? "Vehicle left before the passenger boarded." : s.status === "service_unavailable" ? "No service was running at that time." : "Recorded outcome.") + "</div></div></li>";
                }).join("") + "</ul>"
              : "<div class='empty'>Every recorded request was served.</div>") +
            (u.mustNotServed ? "<div class='alert err'>" + u.mustNotServed + " request(s) marked <strong>Must Arrive By</strong> were not served. These deserve review first.</div>" : "") +
          "</div>" +
        "</div>" +

        "<div class='grid g2'>" +
          "<div class='card pad-0'><div class='card-head' style='padding:16px 18px 0'><h3>Travel time between stops</h3></div>" +
            "<div class='table-wrap'><table class='t'><thead><tr><th>Segment</th><th class='num'>Runs</th><th class='num'>Avg</th><th class='num'>Fastest</th><th class='num'>Slowest</th></tr></thead><tbody>" +
            (tr.segments.length ? tr.segments.map(function (s) {
              return "<tr><td>" + PARA.esc(s.fromName) + " → " + PARA.esc(s.toName) + "</td>" +
                "<td class='num'>" + s.count + "</td><td class='num'>" + PARA.esc(PARA.fmt.mins(s.avg)) + "</td>" +
                "<td class='num'>" + PARA.esc(PARA.fmt.mins(s.min)) + "</td><td class='num'>" + PARA.esc(PARA.fmt.mins(s.max)) + "</td></tr>";
            }).join("") : "<tr><td colspan='5'><div class='empty'>No completed segment records yet.</div></td></tr>") +
            "</tbody></table></div></div>" +
          "<div class='card'><div class='card-head'><h3>Delay analysis</h3></div>" +
            "<div class='grid g3' style='margin-bottom:14px'>" +
              kpi("Delay events", d.count) + kpi("Average delay", d.avgDelay != null ? PARA.fmt.mins(d.avgDelay) : "—") + kpi("Longest delay", d.maxDelay != null ? PARA.fmt.mins(d.maxDelay) : "—") +
            "</div>" +
            "<div class='card-note' style='margin-bottom:6px'>Reasons given</div>" +
            (d.reasons.length ? "<ul class='stop-list'>" + d.reasons.map(function (r) {
              return "<li><div class='stop-num'>" + r.count + "</div><div><strong>" + PARA.esc(PARA.CONST.delayLabel[r.reason] || r.reason) + "</strong></div></li>";
            }).join("") + "</ul>" : "<div class='empty'>No delay reasons recorded.</div>") +
            (d.hotspots.length ? "<div class='card-note' style='margin:14px 0 6px'>Where delays are recorded most often</div>" +
              "<ul class='stop-list'>" + d.hotspots.map(function (h) {
                return "<li><div class='stop-num'>" + h.count + "</div><div><strong>" + PARA.esc(h.stopName) + "</strong></div></li>";
              }).join("") + "</ul>" : "") +
            "<div class='alert info' style='margin-top:12px'>These are vehicle-level observations along the route. PARA does not claim to measure all community traffic.</div>" +
          "</div>" +
        "</div>" +

        "<div class='card'><div class='card-head'><h3>Waiting times</h3><span class='card-note'>from request time to actual vehicle arrival</span></div>" +
          "<div class='grid g4' style='margin-bottom:14px'>" +
            kpi("Average", w.avg != null ? PARA.fmt.mins(w.avg) : "—") +
            kpi("Median", w.median != null ? PARA.fmt.mins(w.median) : "—") +
            kpi("Maximum", w.max != null ? PARA.fmt.mins(w.max) : "—") +
            kpi("Minimum", w.min != null ? PARA.fmt.mins(w.min) : "—") +
          "</div>" +
          hourlyChart(w.byHour, "avg", "Average waiting time by hour") +
        "</div>" +

        "<div class='grid g2'>" +
          "<div class='card'><div class='card-head'><h3>Detected patterns</h3></div>" +
            (patterns.length ? "<ul class='stop-list'>" + patterns.map(function (p) {
              return "<li><div class='stop-num'>" + p.requests + "</div><div><strong>" + PARA.esc(p.label) + "</strong>" +
                "<div class='stop-meta'>" + p.requests + " requests · " + p.passengers + " passengers carried · " + p.trips + " trips</div>" +
                "<div class='stop-meta'>" + PARA.esc(p.note) + "</div></div></li>";
            }).join("") + "</ul>" : "<div class='empty'>Not enough recorded data to detect patterns yet.</div>") +
          "</div>" +
          "<div class='card'><div class='card-head'><h3>Relationships between measures</h3></div>" +
            (corr.length ? corr.map(function (c) {
              return "<div style='padding:10px 0;border-bottom:1px solid #dfe6e0'>" +
                "<strong style='font-size:13.5px'>" + PARA.esc(c.a) + (c.r != null ? " <span class='tag " + (c.r > 0.3 ? "t-amber" : "t-blue") + "'>r = " + c.r + "</span>" : "") + "</strong>" +
                "<div class='stop-meta'>" + PARA.esc(c.reading) + "</div></div>";
            }).join("") : "<div class='empty'>Not enough overlapping data to compare measures yet.</div>") +
          "</div>" +
        "</div>" +

        "<div class='card pad-0'><div class='card-head' style='padding:16px 18px 0'><h3>Weekly trend (8 weeks)</h3></div>" +
          "<div class='table-wrap'><table class='t'><thead><tr><th>Week</th><th class='num'>Trips</th><th class='num'>Passengers</th><th class='num'>Requests</th>" +
          "<th class='num'>Avg wait</th><th class='num'>Avg trip</th><th class='num'>Delays</th></tr></thead><tbody>" +
          trend.map(function (x) {
            return "<tr><td>" + PARA.esc(x.label) + "</td><td class='num'>" + x.trips + "</td><td class='num'>" + x.passengers + "</td>" +
              "<td class='num'>" + x.requests + "</td><td class='num'>" + (x.avgWait != null ? PARA.fmt.mins(x.avgWait) : "—") + "</td>" +
              "<td class='num'>" + (x.avgDuration != null ? PARA.fmt.mins(x.avgDuration) : "—") + "</td><td class='num'>" + x.delays + "</td></tr>";
          }).join("") + "</tbody></table></div></div>" +

        "<div class='card'><div class='card-head'><h3>Data quality</h3><span class='card-note'>" + flags.length + " item(s) flagged — these are not treated as verified facts</span></div>" +
          (flags.length ? "<ul class='stop-list'>" + flags.map(function (f) {
            return "<li><div class='stop-num'>" + (f.severity === "high" ? "!" : f.severity === "medium" ? "?" : "i") + "</div><div>" +
              "<strong>" + PARA.esc(f.kind) + " — " + PARA.esc(f.subject) + "</strong><div class='stop-meta'>" + PARA.esc(f.detail) + "</div></div></li>";
          }).join("") + "</ul>" : "<div class='alert ok'>No data-quality problems detected in this period.</div>") +
        "</div>";

      root.querySelectorAll("[data-range]").forEach(function (b) {
        b.addEventListener("click", function () {
          rangeId = b.getAttribute("data-range");
          sessionStorage.setItem("para_range", rangeId);
          render();
        });
      });

      root.querySelector("#export-all").addEventListener("click", exportAll);
      root.querySelector("#build-report").addEventListener("click", buildReport);
    }

    function exportAll() {
      var db = PARA.store.db;
      var stopName = function (id) { var s = db.stops.filter(function (x) { return x.id === id; })[0]; return s ? s.name : ""; };
      var driverName = function (id) { var d = db.drivers.filter(function (x) { return x.id === id; })[0]; return d ? d.fullName : ""; };
      var vehicleName = function (id) { var v = db.vehicles.filter(function (x) { return x.id === id; })[0]; return v ? v.name : ""; };

      PARA.ui.modal({
        title: "Export data",
        body: "<div class='alert info'>Each dataset is exported as its own CSV file.</div>" +
          "<div class='pill-row' style='margin-top:10px'>" +
            ["Trips", "Vehicles", "Drivers", "Stops", "Passenger requests", "Passenger counts", "Waiting times", "Travel times", "Delays", "Incidents", "Reports", "GPS positions", "Demand summary"].map(function (k) {
              return "<button class='btn ghost sm' data-exp='" + PARA.esc(k) + "'>" + PARA.esc(k) + "</button>";
            }).join("") + "</div>",
        footer: false,
        onMount: function (box) {
          box.querySelectorAll("[data-exp]").forEach(function (b) {
            b.addEventListener("click", function () {
              var kind = b.getAttribute("data-exp");
              if (kind === "Trips") {
                PARA.analytics.exportCsv("para_trips.csv", ["Trip", "Driver", "Vehicle", "Started", "Ended", "Duration (min)", "Passengers", "Capacity", "Delay (min)", "Delay reason", "Status"],
                  db.trips.map(function (t) { return [t.code, driverName(t.driverId), vehicleName(t.vehicleId), t.startAt, t.endAt || "", t.durationMin || "", t.passengers, t.capacityAtTime || "", t.delayMin || "", t.delayReason || "", t.status]; }));
              } else if (kind === "Vehicles") {
                PARA.analytics.exportCsv("para_vehicles.csv", ["Code", "Name", "Type", "Capacity", "Plate", "Status", "GPS status", "Driver", "Last GPS"],
                  db.vehicles.map(function (v) { return [v.code, v.name, v.type, v.capacity, v.plate, v.status, PARA.geo.gpsFreshness(v), driverName(v.driverId), v.lastGpsAt || ""]; }));
              } else if (kind === "Drivers") {
                PARA.analytics.exportCsv("para_drivers.csv", ["Driver ID", "Name", "Contact", "License", "Status", "Activation", "Vehicle", "Registered"],
                  db.drivers.map(function (d) { return [d.code, d.fullName, d.contact, d.license, d.status, d.activation, vehicleName(d.vehicleId), d.registeredAt]; }));
              } else if (kind === "Stops") {
                PARA.analytics.exportCsv("para_stops.csv", ["Code", "Name", "Location", "Latitude", "Longitude", "Position", "From prev (min)", "To next (min)"],
                  db.stops.map(function (s) { return [s.code, s.name, s.location, s.lat, s.lng, s.position, s.travelFromPrev, s.travelToNext]; }));
              } else if (kind === "Passenger requests") {
                PARA.analytics.exportCsv("para_passenger_requests.csv", ["Request", "Date", "Desired time", "Sensitivity", "Origin", "Destination", "Status", "Created"],
                  db.requests.map(function (q) { return [q.code, q.date, q.desiredTime, q.sensitivity, stopName(q.originId), stopName(q.destId), q.status, q.createdAt]; }));
              } else if (kind === "Passenger counts") {
                PARA.analytics.exportCsv("para_passenger_counts.csv", ["Trip", "Vehicle", "Passengers", "Capacity", "Utilisation %", "Recorded"],
                  db.trips.filter(function (t) { return t.status === "completed"; }).map(function (t) {
                    return [t.code, vehicleName(t.vehicleId), t.passengers, t.capacityAtTime, t.capacityAtTime ? Math.round((t.passengers / t.capacityAtTime) * 100) : "", t.endAt];
                  }));
              } else if (kind === "Waiting times") {
                PARA.analytics.exportCsv("para_waiting_times.csv", ["Stop", "Requested at", "Expected", "Arrived", "Wait (min)"],
                  db.waitingTimes.map(function (w) { return [stopName(w.stopId), w.requestedAt, w.expectedAt, w.arrivedAt, w.waitMin]; }));
              } else if (kind === "Travel times") {
                PARA.analytics.exportCsv("para_travel_times.csv", ["From", "To", "Started", "Ended", "Minutes"],
                  db.travelTimes.map(function (t) { return [stopName(t.fromStopId), stopName(t.toStopId), t.startedAt, t.endedAt, t.minutes]; }));
              } else if (kind === "Delays") {
                PARA.analytics.exportCsv("para_delays.csv", ["Vehicle", "Driver", "Normal (min)", "Actual (min)", "Delay (min)", "Reason", "Detected", "Resolved", "Stop"],
                  db.delays.map(function (d) { return [vehicleName(d.vehicleId), driverName(d.driverId), d.normalMin, d.actualMin, d.delayMin, d.reason, d.detectedAt, d.resolvedAt || "", stopName(d.stopId)]; }));
              } else if (kind === "Incidents") {
                PARA.analytics.exportCsv("para_incidents.csv", ["ID", "When", "Reporter", "Type", "Category", "Location", "Description", "Status", "Resolution"],
                  db.incidents.map(function (i) { return [i.code, i.at, i.reporterType, i.reporterType, i.category, i.location, i.description, i.status, i.resolution]; }));
              } else if (kind === "Reports") {
                PARA.analytics.exportCsv("para_reports.csv", ["ID", "When", "From", "Type", "Location", "Description", "Status"],
                  db.reports.map(function (x) { return [x.code, x.at, x.reporterType, x.type, x.location, x.description, x.status]; }));
              } else if (kind === "GPS positions") {
                PARA.analytics.exportCsv("para_gps.csv", ["Vehicle", "Trip", "Latitude", "Longitude", "Speed kph", "Accuracy m", "Recorded"],
                  db.gps.slice(-2000).map(function (g) { return [vehicleName(g.vehicleId), g.tripId, g.lat, g.lng, g.speedKph || "", g.accuracyM || "", g.at]; }));
              } else if (kind === "Demand summary") {
                var r = PARA.analytics.range(rangeId);
                PARA.analytics.exportCsv("para_demand_by_hour.csv", ["Hour", "Requests", "Must arrive by", "Served", "Trips", "Passengers", "Seats offered", "Utilisation %"],
                  PARA.analytics.demandByHour(r).map(function (b) {
                    var cap = PARA.analytics.capacity(r).rows.filter(function (x) { return x.hour === b.hour; })[0];
                    return [(b.hour < 10 ? "0" : "") + b.hour + ":00", b.requests, b.must, b.served, b.trips, b.passengers, cap ? cap.capacity : 0, cap && cap.utilization != null ? cap.utilization : ""];
                  }));
              }
              PARA.ui.toast(kind + " exported", "good");
            });
          });
        }
      });
    }

    function buildReport() {
      var db = PARA.store.db;
      var r = PARA.analytics.range(rangeId);
      var t = PARA.analytics.tripStats(r), w = PARA.analytics.waitStats(r);
      var tr = PARA.analytics.travelStats(r), d = PARA.analytics.delayStats(r);
      var c = PARA.analytics.capacity(r), u = PARA.analytics.unmet(r);
      var peak = PARA.analytics.peak(r), today = PARA.analytics.dailySummary();
      var flags = PARA.analytics.dataQuality(r);

      var row = function (label, value) { return "<tr><td style='padding:6px 0'><strong>" + PARA.esc(label) + "</strong></td><td style='padding:6px 0;text-align:right'>" + value + "</td></tr>"; };

      PARA.ui.modal({
        wide: true,
        title: "Community transportation report — " + r.label,
        footer: false,
        body:
          "<div class='alert info'><strong>How to read this report.</strong> <em>Recorded facts</em> are values entered by drivers or passengers. " +
          "<em>Calculated statistics</em> are computed from those records. <em>System estimates</em> are projections such as ETAs. " +
          "<em>User-reported</em> items come from passenger or driver reports and are not independently verified.</div>" +
          "<h3 style='margin:18px 0 8px;font-size:15px'>1. Service activity (recorded facts)</h3>" +
          "<table class='t' style='border:1px solid #dfe6e0;border-radius:8px'>" +
            row("Trips recorded", t.count) +
            row("Passengers recorded as transported", t.passengers) +
            row("Trips completed", t.completed) +
            row("Passenger requests received", c.totalRequests) +
            row("Trips today", today.trips + " (" + today.passengers + " passengers)") +
          "</table>" +
          "<h3 style='margin:18px 0 8px;font-size:15px'>2. Demand (calculated from recorded requests)</h3>" +
          "<table class='t' style='border:1px solid #dfe6e0;border-radius:8px'>" +
            row("Busiest recorded hour", peak.busiest && peak.busiest.requests ? (peak.busiest.hour < 10 ? "0" : "") + peak.busiest.hour + ":00 (" + peak.busiest.requests + " requests)" : "not enough data") +
            row("Quietest recorded hour", peak.quietest ? (peak.quietest.hour < 10 ? "0" : "") + peak.quietest.hour + ":00 (" + peak.quietest.requests + " requests)" : "n/a") +
            row("Morning / midday / evening", peak.morning + " / " + peak.midday + " / " + peak.evening) +
            row("Requests marked Must Arrive By", u.total ? Math.round((PARA.analytics.demandBySensitivity(r).filter(function (s) { return s.key === "must_arrive_by"; })[0].count / u.total) * 100) + "% of requests" : "n/a") +
          "</table>" +
          "<h3 style='margin:18px 0 8px;font-size:15px'>3. Waiting and travel times (calculated)</h3>" +
          "<table class='t' style='border:1px solid #dfe6e0;border-radius:8px'>" +
            row("Average waiting time", w.avg != null ? PARA.fmt.mins(w.avg) + " (" + w.count + " samples)" : "no samples") +
            row("Median / maximum wait", (w.median != null ? PARA.fmt.mins(w.median) : "—") + " / " + (w.max != null ? PARA.fmt.mins(w.max) : "—")) +
            row("Average travel time per segment", tr.avg != null ? PARA.fmt.mins(tr.avg) : "—") +
            row("Slowest segment", tr.segments.length ? tr.segments[0].fromName + " → " + tr.segments[0].toName + " (" + PARA.fmt.mins(tr.segments[0].avg) + ")" : "—") +
            row("Average whole-trip duration", t.avgDuration != null ? PARA.fmt.mins(t.avgDuration) : "—") +
          "</table>" +
          "<h3 style='margin:18px 0 8px;font-size:15px'>4. Capacity (calculated, with caveats)</h3>" +
          "<table class='t' style='border:1px solid #dfe6e0;border-radius:8px'>" +
            row("Seats offered in period", c.totalCapacity) +
            row("Average hourly utilisation", c.avgUtilization != null ? Math.round(c.avgUtilization) + "%" : "not measurable") +
            row("Hours under capacity pressure", c.pressureHours.length ? c.pressureHours.map(function (p) { return (p.hour < 10 ? "0" : "") + p.hour + ":00"; }).join(", ") : "none") +
            row("Requests not fulfilled", u.unmet + " of " + u.total + " (" + u.servedRate + "% fulfilled)") +
            row("Must-Arrive-By requests not served", u.mustNotServed) +
          "</table>" +
          "<div class='alert warn' style='margin-top:10px'>Where observed demand exceeds recorded capacity, this indicates <strong>potential capacity shortages</strong>. It does not by itself prove the service is inadequate: some passengers may travel outside recorded hours, share seats, or use other means.</div>" +
          "<h3 style='margin:18px 0 8px;font-size:15px'>5. Delays and incidents (recorded + user-reported)</h3>" +
          "<table class='t' style='border:1px solid #dfe6e0;border-radius:8px'>" +
            row("Trips with recorded delay", t.delayedTrips + " (" + t.delayRate + "%)") +
            row("Average / longest delay", (d.avgDelay != null ? PARA.fmt.mins(d.avgDelay) : "—") + " / " + (d.maxDelay != null ? PARA.fmt.mins(d.maxDelay) : "—")) +
            row("Most common delay reason", d.reasons.length ? PARA.CONST.delayLabel[d.reasons[0].reason] + " (" + d.reasons[0].count + ")" : "none recorded") +
            row("Where delays occur most", d.hotspots.length ? d.hotspots[0].stopName + " (" + d.hotspots[0].count + ")" : "not recorded") +
            row("Open incidents", db.incidents.filter(function (i) { return i.status !== "resolved" && i.status !== "dismissed"; }).length) +
            row("Open reports", db.reports.filter(function (x) { return x.status === "open" || x.status === "investigating"; }).length) +
          "</table>" +
          "<h3 style='margin:18px 0 8px;font-size:15px'>6. Confidence and data quality</h3>" +
          (flags.length
            ? "<ul class='stop-list'>" + flags.slice(0, 8).map(function (f) {
                return "<li><div class='stop-num'>!</div><div><strong>" + PARA.esc(f.kind) + "</strong><div class='stop-meta'>" + PARA.esc(f.subject) + " — " + PARA.esc(f.detail) + "</div></div></li>";
              }).join("") + "</ul>"
            : "<div class='alert ok'>No data-quality flags in this period.</div>") +
          "<h3 style='margin:18px 0 8px;font-size:15px'>7. Suggested areas for improvement</h3>" +
          "<ul class='stop-list'>" +
            (c.pressureHours.length ? "<li><div class='stop-num'>1</div><div><strong>Review capacity at " + c.pressureHours.map(function (p) { return (p.hour < 10 ? "0" : "") + p.hour + ":00"; }).join(", ") + "</strong><div class='stop-meta'>Observed requests exceeded seats offered in these hours.</div></div></li>" : "") +
            (w.avg > 15 ? "<li><div class='stop-num'>2</div><div><strong>Reduce peak waiting</strong><div class='stop-meta'>Average recorded wait of " + PARA.fmt.mins(w.avg) + " suggests adding a trip or re-timing arrivals in the busiest hours.</div></div></li>" : "") +
            (d.hotspots.length ? "<li><div class='stop-num'>3</div><div><strong>Investigate " + PARA.esc(d.hotspots[0].stopName) + "</strong><div class='stop-meta'>Most frequently recorded delay location. Confirm with a site visit before concluding a road cause.</div></div></li>" : "") +
            (u.mustNotServed ? "<li><div class='stop-num'>4</div><div><strong>Protect strict-urgency trips</strong><div class='stop-meta'>" + u.mustNotServed + " Must-Arrive-By request(s) were not served in this period.</div></div></li>" : "") +
            "<li><div class='stop-num'>✓</div><div><strong>Continue recording</strong><div class='stop-meta'>Patterns above become more reliable as more trips, requests and arrival times are recorded.</div></div></li>" +
          "</ul>" +
          "<div class='card-note' style='margin-top:16px'>Generated " + PARA.esc(PARA.fmt.dateTime(new Date().toISOString())) + " · window: " + PARA.esc(r.label) + "</div>",
        onMount: function (box, close) {
          var foot = document.createElement("div");
          foot.className = "modal-foot";
          foot.innerHTML = "<button class='btn ghost' data-close>Close</button><button class='btn' id='dl-report'>Download as text</button>";
          box.appendChild(foot);
          foot.querySelector("#dl-report").addEventListener("click", function () {
            var text = box.innerText;
            var blob = new Blob([text], { type: "text/plain;charset=utf-8" });
            var a = document.createElement("a");
            a.href = URL.createObjectURL(blob);
            a.download = "para_report_" + r.id + ".txt";
            a.click();
            setTimeout(function () { URL.revokeObjectURL(a.href); }, 800);
          });
        }
      });
    }

    render();
  };

  V["admin-logs"] = function (root) {
    if (!PARA.auth.requireRole("admin")) { location.hash = "#/"; return; }
    var db = PARA.store.db;
    var filter = "";
    function render() {
      var rows = db.activity.filter(function (a) {
        return !filter || (a.action + " " + a.entity + " " + (a.byName || "") + " " + (a.detail || "")).toLowerCase().indexOf(filter.toLowerCase()) >= 0;
      }).slice(0, 200);
      root.innerHTML =
        "<h1 class='title'>Activity log</h1>" +
        "<div class='sub'>Administrative and operational actions, kept for accountability and troubleshooting.</div>" +
        "<div class='card'><input class='in' id='log-search' placeholder='Filter by action, person or detail' value='" + PARA.esc(filter) + "'></div>" +
        "<div class='card pad-0'><div class='table-wrap'><table class='t'>" +
          "<thead><tr><th>When</th><th>Action</th><th>Entity</th><th>Performed by</th><th>Role</th><th>Detail</th></tr></thead><tbody>" +
          (rows.length ? rows.map(function (a) {
            return "<tr><td class='card-note'>" + PARA.esc(PARA.fmt.dateTime(a.at)) + "</td>" +
              "<td><span class='tag " + PARA.tagClass(a.action) + "'>" + PARA.esc(PARA.titleize(a.action)) + "</span></td>" +
              "<td>" + PARA.esc(a.entity || "—") + "</td>" +
              "<td>" + PARA.esc(a.byName || "—") + "</td>" +
              "<td class='card-note' style='text-transform:capitalize'>" + PARA.esc(a.role || "—") + "</td>" +
              "<td class='card-note'>" + PARA.esc(a.detail || "") + "</td></tr>";
          }).join("") : "<tr><td colspan='6'><div class='empty'>No log entries match.</div></td></tr>") +
        "</tbody></table></div></div>";
      var s = root.querySelector("#log-search");
      s.addEventListener("input", function () {
        filter = s.value;
        var pos = s.selectionStart;
        render();
        var again = root.querySelector("#log-search");
        again.focus();
        again.setSelectionRange(pos, pos);
      });
    }
    render();
  };

  V["admin-data"] = function (root) {
    if (!PARA.auth.requireRole("admin")) { location.hash = "#/"; return; }
    var db = PARA.store.db;
    root.innerHTML =
      "<h1 class='title'>Data &amp; settings</h1>" +
      "<div class='sub'>Storage, privacy and maintenance for this installation.</div>" +
      "<div class='grid g2'>" +
        "<div class='card'><div class='card-head'><h3>Stored records</h3></div>" +
          "<ul class='stop-list'>" +
            ["Users: " + db.users.length, "Drivers: " + db.drivers.length, "Passengers: " + db.passengers.length,
             "Vehicles: " + db.vehicles.length, "Stops: " + db.stops.length, "Trips: " + db.trips.length,
             "Passenger requests: " + db.requests.length, "Waiting-time samples: " + db.waitingTimes.length,
             "Travel-time samples: " + db.travelTimes.length, "Delay records: " + db.delays.length,
             "GPS points: " + db.gps.length, "Incidents: " + db.incidents.length, "Reports: " + db.reports.length,
             "Activity log: " + db.activity.length].map(function (t) {
              var p = t.split(": ");
              return "<li><div class='stop-num'>" + p[1] + "</div><div><strong>" + PARA.esc(p[0]) + "</strong></div></li>";
            }).join("") + "</ul>" +
        "</div>" +
        "<div class='card'><div class='card-head'><h3>Privacy posture</h3></div>" +
          "<ul class='stop-list'>" +
            "<li><div class='stop-num'>1</div><div><strong>Anonymised analytics</strong><div class='stop-meta'>Demand statistics are counted from requests, not from named identities.</div></div></li>" +
            "<li><div class='stop-num'>2</div><div><strong>Stop-level, not address-level</strong><div class='stop-meta'>Passenger records store a preferred stop, never a home address.</div></div></li>" +
            "<li><div class='stop-num'>3</div><div><strong>Role separation</strong><div class='stop-meta'>Drivers can only see their own trips; only administrators register driver accounts.</div></div></li>" +
            "<li><div class='stop-num'>4</div><div><strong>Local storage</strong><div class='stop-meta'>This demo keeps all data in this browser only. Nothing is transmitted.</div></div></li>" +
          "</ul>" +
          "<div class='card-head' style='margin-top:20px'><h3>Maintenance</h3></div>" +
          "<div class='pill-row'>" +
            "<button class='btn ghost sm' id='trim-gps'>Trim GPS history (keep last 300)</button>" +
            "<button class='btn ghost sm' id='export-db'>Export full backup (JSON)</button>" +
            "<button class='btn danger sm' id='reset-db'>Reset to demo data</button>" +
          "</div>" +
        "</div>" +
      "</div>";

    root.querySelector("#trim-gps").addEventListener("click", function () {
      if (db.gps.length <= 300) { PARA.ui.toast("GPS history is already short"); return; }
      db.gps = db.gps.slice(-300);
      PARA.store.save();
      PARA.ui.toast("GPS history trimmed to 300 points", "good");
      PARA.render();
    });
    root.querySelector("#export-db").addEventListener("click", function () {
      var blob = new Blob([JSON.stringify(db, null, 2)], { type: "application/json" });
      var a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "para_backup_" + new Date().toISOString().slice(0, 10) + ".json";
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 800);
      PARA.ui.toast("Backup downloaded", "good");
    });
    root.querySelector("#reset-db").addEventListener("click", function () {
      PARA.ui.confirm("Reset all data", "This replaces everything with the original demo data set. This cannot be undone.", function () {
        PARA.store.reset();
        PARA.ui.toast("Demo data restored", "good");
        location.hash = "#/";
        PARA.render();
      }, "Reset everything");
    });
  };

})(PARA.views);
