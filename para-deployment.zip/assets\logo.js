window.PARA = window.PARA || {};

PARA.LOGO_SVG = [
  "<svg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg' role='img' aria-label='PARA logo'>",
  "<defs>",
  "<linearGradient id='paraG' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#4caf50'/><stop offset='1' stop-color='#1b5e20'/></linearGradient>",
  "<linearGradient id='paraG2' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#8bc34a'/><stop offset='1' stop-color='#43a047'/></linearGradient>",
  "</defs>",
  "<circle cx='100' cy='100' r='94' fill='#ffffff'/>",
  "<path d='M100 14a86 86 0 0 1 84 66' fill='none' stroke='url(#paraG2)' stroke-width='13' stroke-linecap='round'/>",
  "<path d='M100 186a86 86 0 0 1-84-66' fill='none' stroke='url(#paraG)' stroke-width='13' stroke-linecap='round'/>",
  "<path d='M40 150c22-16 44-22 62-22 24 0 42 8 58 22' fill='none' stroke='#2e7d32' stroke-width='9' stroke-linecap='round'/>",
  "<path d='M52 146h96' stroke='#ffffff' stroke-width='3.4' stroke-dasharray='13 11' stroke-linecap='round'/>",
  "<rect x='62' y='74' width='76' height='50' rx='12' fill='url(#paraG)'/>",
  "<rect x='71' y='82' width='26' height='20' rx='4' fill='#ffffff' opacity='.34'/>",
  "<rect x='103' y='82' width='26' height='20' rx='4' fill='#ffffff' opacity='.34'/>",
  "<rect x='62' y='108' width='76' height='7' rx='3.5' fill='#ffffff' opacity='.22'/>",
  "<circle cx='79' cy='128' r='9' fill='#1b3a24'/><circle cx='79' cy='128' r='4' fill='#8bc34a'/>",
  "<circle cx='121' cy='128' r='9' fill='#1b3a24'/><circle cx='121' cy='128' r='4' fill='#8bc34a'/>",
  "<path d='M150 44a13 13 0 1 1 0 26 13 13 0 0 1 0-26z' fill='#fdd835' opacity='.9'/>",
  "<path d='M158 88h9v34h-9z' fill='#66bb6a' opacity='.75'/>",
  "<path d='M170 96h9v26h-9z' fill='#43a047' opacity='.7'/>",
  "<path d='M182 102h8v20h-8z' fill='#2e7d32' opacity='.6'/>",
  "<path d='M44 34c0-11 9-20 20-20s20 9 20 20c0 15-20 33-20 33S44 49 44 34z' fill='url(#paraG)'/>",
  "<circle cx='64' cy='34' r='8' fill='#ffffff'/>",
  "</svg>"
].join('');

PARA.logo = function (size) {
  var s = size || 42;
  return "<span style='display:inline-block;width:" + s + "px;height:" + s + "px;vertical-align:middle'>" + PARA.LOGO_SVG + "</span>";
};
