window.PARA = window.PARA || {};
PARA.views = PARA.views || {};

(function (V) {
  "use strict";

  function me() {
    var u = PARA.auth.user();
    if (!u || u.role !== "passenger") return null;
    var found = PARA.store.db.passengers.filter(function (p) { return p.userId === u.id; })[0];
    if (found) return found;
    found = {
      id: PARA.store.uid("pas"), userId: u.id, fullName: u.fullName || "Passenger",
      contact: u.phone || null, sms: !!u.phone, homeStopId: null,
      prefs: { serviceInterruption: true, majorDelay: true, announcements: true, vehicleArrival: false },
      createdAt: new Date().toISOString()
    };
    PARA.store.db.passengers.push(found);
    PARA.store.save();
    PARa_record("repair_passenger_profile", "passenger", found.id, "Passenger profile missing for account " + u.username + "; recreated from account details");
    return found;
  }

  function alertsCard() {
    var u = PARA.auth.user();
    var p = me();
    var list = PARA.store.db.notifications.filter(function (n) { return n.to === u.id; });
    if (!list.length) return "";
    var unread = list.filter(function (n) { return !n.read; }).length;
    return "<div class='card'><div class='card-head'><h3>Your alerts</h3>" +
      "<div class='pill-row'>" +
        "<span class='card-note'>" + unread + " unread of " + list.length + "</span>" +
        (unread ? "<button class='btn ghost sm' id='read-all'>Mark all as read</button>" : "") +
        (p && p.sms ? "<span class='tag t-blue'>SMS alerts on</span>" : "<span class='tag t-grey'>SMS alerts off</span>") +
      "</div></div>" +
      list.slice(0, 6).map(function (n) {
        var ic = { delay: "⏱", service_interruption: "⚠️", service_resumed: "✅", suspension: "🛑", vehicle_approaching: "🚌", announcement: "📢", system: "🔔" }[n.type] || "🔔";
        return "<div class='notif" + (n.read ? "" : " unread") + "'><div class='ic'>" + ic + "</div><div style='flex:1'>" +
          "<div class='t'>" + PARA.esc(n.title) + " " + PARA.tag(n.priority, PARA.titleize(n.priority)) + "</div>" +
          "<div class='m'>" + PARA.esc(n.body) + "</div>" +
          "<div class='m' style='margin-top:4px'>" + PARA.esc(PARA.fmt.ago(n.at)) + "</div></div></div>";
      }).join("") + "</div>";
  }

  function requestForm(db, prefill) {
    var route = PARA.geo.activeRoute();
    var stops = PARA.geo.stops(route && route.id);
    var p = me();
    var opts = stops.map(function (s) { return "<option value='" + s.id + "'>" + s.position + ". " + PARA.esc(s.name) + "</option>"; }).join("");
    var today = new Date();
    return "<form id='req-form'>" +
      "<div class='row2'>" +
        PARA.ui.field("Date of travel", "<input class='in' type='date' name='date' value='" + today.toISOString().slice(0, 10) + "' required>") +
        PARA.ui.field("Time you need to arrive", "<input class='in' type='time' name='time' required>") +
      "</div>" +
      "<div class='row2'>" +
        PARA.ui.field("Boarding stop", "<select class='in' name='origin' required><option value=''>Select a stop</option>" + opts + "</select>") +
        PARA.ui.field("Destination stop", "<select class='in' name='dest' required><option value=''>Select a stop</option>" + opts + "</select>") +
      "</div>" +
      PARA.ui.field("How strict is your arrival time?", "<select class='in' name='sensitivity'>" +
        PARA.ui.options(PARA.CONST.sensitivity, "must_arrive_by", function (v) { return PARA.CONST.sensitivityLabel[v]; }) + "</select>",
        "This matters: 50 requests are not the same level of urgency, and the strict ones are reviewed first.") +
      PARA.ui.field("Anything the driver should know? (optional)", "<textarea class='in' name='note' placeholder='e.g. travelling with a child and a wheelchair'></textarea>") +
      "<div id='req-err'></div>" +
      "<button class='btn' type='submit'>Submit transportation request</button>" +
    "</form>";
  }

  function wireRequestForm(root, afterSave) {
    var db = PARA.store.db;
    var form = root.querySelector("#req-form");
    if (!form) return;
    if (sessionStorage.getItem("para_prefill")) {
      try {
        var pf = JSON.parse(sessionStorage.getItem("para_prefill"));
        sessionStorage.removeItem("para_prefill");
        if (pf.originId) form.querySelector("[name='origin']").value = pf.originId;
        if (pf.destId) form.querySelector("[name='dest']").value = pf.destId;
        if (pf.time) form.querySelector("[name='time']").value = pf.time;
      } catch (e) { }
    }
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var p = me();
      if (!p) { location.hash = "#/login"; return; }
      var f = new FormData(form);
      var origin = f.get("origin"), dest = f.get("dest");
      if (origin === dest) {
        root.querySelector("#req-err").innerHTML = "<div class='alert err'>Boarding stop and destination must be different.</div>";
        return;
      }
      var desired = f.get("date") + "T" + f.get("time") + ":00";
      var plan = PARA.analytics.planTrip(origin, dest, desired, f.get("sensitivity"));
      var req = {
        id: PARA.store.uid("req"), code: "REQ-" + Math.random().toString(36).slice(2, 7).toUpperCase(),
        passengerId: p.id, date: f.get("date"), desiredTime: desired, sensitivity: f.get("sensitivity"),
        originId: origin, destId: dest, tripId: null, status: "submitted",
        note: f.get("note") || "", createdAt: new Date().toISOString(), resolvedAt: null,
        suggestedLeave: plan.ok ? plan.recommendedLeave.toISOString() : null
      };
      db.requests.unshift(req);
      PARa_record("submit_passenger_request", "request", req.id, req.code + " " + PARA.CONST.sensitivityLabel[req.sensitivity]);
      PARA.store.save();
      PARA.ui.toast("Request " + req.code + " submitted", "good");
      if (afterSave) afterSave();
      else PARA.render();
    });
  }

  V.passenger = function (root) {
    if (!PARA.auth.requireRole("passenger")) { location.hash = "#/"; return; }
    var db = PARA.store.db;
    var p = me();
    var u = PARA.auth.user();
    var stops = PARA.geo.stops(PARA.geo.activeRoute().id);
    var upcoming = stops.filter(function (s) { return s.eta; }).slice(0, 5);
    var myReqs = db.requests.filter(function (q) { return q.passengerId === p.id; });
    var active = myReqs.filter(function (q) { return q.status === "submitted" || q.status === "assigned"; });
    var served = myReqs.filter(function (q) { return q.status === "served"; });
    var stopName = function (id) { var s = db.stops.filter(function (x) { return x.id === id; })[0]; return s ? s.name : "—"; };

    root.innerHTML =
      "<h1 class='title'>Hello, " + PARA.esc(p.fullName.split(" ")[0]) + "</h1>" +
      "<div class='sub'>Here is what you need to know before travelling.</div>" +
      "<div class='status-hero'>" +
        "<span class='status-dot " + (db.serviceStatus === "operating_normally" || db.serviceStatus === "resumed" ? "dot-green" : db.serviceStatus === "suspended" || db.serviceStatus === "emergency" ? "dot-red" : "dot-amber") + "'></span>" +
        "<div style='flex:1;min-width:200px'><div class='lbl'>" + PARA.esc(PARA.CONST.serviceLabel[db.serviceStatus]) + "</div>" +
        "<div class='meta'>" + (db.serviceNote ? PARA.esc(db.serviceNote) + " · " : "") + PARA.esc(PARA.geo.activeTrips().length) + " vehicle(s) running now</div></div>" +
        "<a class='btn' href='#/passenger/request-new'>Request a ride</a>" +
      "</div>" +
      "<div class='grid g4' style='margin-bottom:18px'>" +
        "<div class='kpi'><div class='v'>" + active.length + "</div><div class='l'>Open requests</div></div>" +
        "<div class='kpi'><div class='v'>" + served.length + "</div><div class='l'>Trips served</div></div>" +
        "<div class='kpi'><div class='v'>" + upcoming.length + "</div><div class='l'>Stops with a live ETA</div></div>" +
        "<div class='kpi'><div class='v'>" + db.notifications.filter(function (n) { return n.to === u.id && !n.read; }).length + "</div><div class='l'>Unread alerts</div></div>" +
      "</div>" +
      "<div class='grid g2'>" +
        "<div class='card'><div class='card-head'><h3>Next arrivals</h3><span class='card-note'>from live vehicle positions</span></div>" +
          (upcoming.length
            ? "<ul class='stop-list'>" + upcoming.map(function (s) {
                return "<li><div class='stop-num'>" + s.position + "</div><div><strong>" + PARA.esc(s.name) + "</strong>" +
                  "<div class='stop-meta'>around " + PARA.esc(PARA.fmt.time(s.eta)) + " · " + PARA.esc(PARA.fmt.until(s.eta)) + "</div></div></li>";
              }).join("") + "</ul>"
            : "<div class='empty'>No vehicle is currently running. Check the service status and operating hours.</div>") +
          "<div class='pill-row' style='margin-top:14px'><a class='btn ghost sm' href='#/planner'>Plan a trip</a><a class='btn ghost sm' href='#/route'>See all stops</a></div>" +
        "</div>" +
        "<div class='card'><div class='card-head'><h3>My open requests</h3><a class='btn ghost sm' href='#/passenger/requests'>View all</a></div>" +
          (active.length
            ? "<ul class='stop-list'>" + active.map(function (q) {
                return "<li><div class='stop-num'>" + PARA.esc(q.code.slice(-3)) + "</div><div>" +
                  "<strong>" + PARA.esc(stopName(q.originId)) + " → " + PARA.esc(stopName(q.destId)) + "</strong>" +
                  "<div class='stop-meta'>" + PARA.esc(PARA.fmt.dateTime(q.desiredTime)) + " · " + PARA.esc(PARA.CONST.sensitivityLabel[q.sensitivity]) + " · " + PARA.tag(q.status, PARA.CONST.requestLabel[q.status]) + "</div></div></li>";
              }).join("") + "</ul>"
            : "<div class='empty'>You have no open requests.</div>") +
        "</div>" +
      "</div>" +
      alertsCard();

    var readAll = root.querySelector("#read-all");
    if (readAll) {
      readAll.addEventListener("click", function () {
        db.notifications.forEach(function (n) { if (n.to === u.id) { n.read = true; n.readAt = new Date().toISOString(); } });
        PARA.store.save();
        PARA.render();
      });
    }
  };

  V["passenger-request-new"] = function (root) {
    if (!PARA.auth.requireRole("passenger")) { location.hash = "#/"; return; }
    var db = PARA.store.db;
    root.innerHTML =
      "<h1 class='title'>Request transportation</h1>" +
      "<div class='sub'>Tell us when and where you need to travel. Your request becomes part of the demand record that helps the community plan service.</div>" +
      "<div class='grid g2'>" +
        "<div class='card'>" + requestForm(db) + "</div>" +
        "<div class='card'><div class='card-head'><h3>What happens next</h3></div>" +
          "<ul class='timeline'>" +
            "<li><div class='t'>Your request is recorded with its time sensitivity</div><div class='d'>Strict requests are considered before flexible ones when trips are assigned.</div></li>" +
            "<li><div class='t'>You get an estimated time to reach your stop</div><div class='d'>Based on normal travel time and current vehicle positions.</div></li>" +
            "<li><div class='t'>The outcome is recorded</div><div class='d'>Served, missed the vehicle, cancelled, vehicle full, or you found another way. All outcomes are useful.</div></li>" +
          "</ul>" +
          "<div class='alert info'>If no vehicle can take you, that is recorded as unmet demand for the administrator to review — it is not treated as a failure by itself, since you may have used another option.</div>" +
        "</div>" +
      "</div>";
    wireRequestForm(root, function () { location.hash = "#/passenger/requests"; PARA.render(); });
  };

  V["passenger-requests"] = function (root) {
    if (!PARA.auth.requireRole("passenger")) { location.hash = "#/"; return; }
    var db = PARA.store.db;
    var p = me();
    var stopName = function (id) { var s = db.stops.filter(function (x) { return x.id === id; })[0]; return s ? s.name : "—"; };
    var rows = db.requests.filter(function (q) { return q.passengerId === p.id; });

    root.innerHTML =
      "<div class='tabs-row'><div><h1 class='title'>My requests</h1>" +
        "<div class='sub'>Your transportation requests and how each one turned out.</div></div>" +
        "<a class='btn' href='#/passenger/request-new'>New request</a></div>" +
      "<div class='card pad-0'><div class='table-wrap'><table class='t'>" +
        "<thead><tr><th>Request</th><th>Travel</th><th>Route</th><th>Urgency</th><th>Suggested boarding</th><th>Status</th><th>Actions</th></tr></thead><tbody>" +
        (rows.length ? rows.map(function (q) {
          var open = q.status === "submitted" || q.status === "assigned";
          return "<tr><td><strong>" + PARA.esc(q.code) + "</strong><div class='stop-meta'>" + PARA.esc(PARA.fmt.ago(q.createdAt)) + "</div></td>" +
            "<td>" + PARA.esc(PARA.fmt.dateTime(q.desiredTime)) + "</td>" +
            "<td>" + PARA.esc(stopName(q.originId)) + " → " + PARA.esc(stopName(q.destId)) + "</td>" +
            "<td>" + PARA.tag(q.sensitivity, PARA.CONST.sensitivityLabel[q.sensitivity]) + "</td>" +
            "<td>" + (q.suggestedLeave ? PARA.esc(PARA.fmt.time(q.suggestedLeave)) : "—") + "</td>" +
            "<td>" + PARA.tag(q.status, PARA.CONST.requestLabel[q.status]) + "</td>" +
            "<td>" + (open
              ? "<button class='btn ghost sm' data-cancel='" + q.id + "'>Cancel</button>"
              : (q.status === "served"
                ? "<button class='btn ghost sm' data-outcome='" + q.id + "'>Not served after all</button>"
                : "<span class='card-note'>closed</span>")) + "</td></tr>";
        }).join("") : "<tr><td colspan='7'><div class='empty'>You have not made any requests yet.</div></td></tr>") +
      "</tbody></table></div></div>" +
      "<div class='card'><div class='card-head'><h3>About your records</h3></div>" +
        "<p style='font-size:13.5px;color:#5f6b62'>Requests are counted anonymously in the community demand analysis. The analysis uses stop names, times and urgency — not your name, and never a home address. You can review what is stored on the <a href='#/account'>account page</a>.</p>" +
      "</div>";

    root.querySelectorAll("[data-cancel]").forEach(function (b) {
      b.addEventListener("click", function () {
        var q = db.requests.filter(function (x) { return x.id === b.getAttribute("data-cancel"); })[0];
        q.status = "cancelled";
        q.resolvedAt = new Date().toISOString();
        PARa_record("cancel_passenger_request", "request", q.id, q.code + " cancelled by passenger");
        PARA.store.save();
        PARA.ui.toast("Request cancelled");
        PARA.render();
      });
    });

    root.querySelectorAll("[data-outcome]").forEach(function (b) {
      b.addEventListener("click", function () {
        var q = db.requests.filter(function (x) { return x.id === b.getAttribute("data-outcome"); })[0];
        PARA.ui.modal({
          title: "Correct the outcome of " + q.code,
          body: "<p style='font-size:14px;margin-bottom:12px'>This request was marked as served, but you were not actually transported. Recording the real outcome keeps the demand figures honest.</p>" +
            PARA.ui.field("What actually happened?", "<select class='in' id='out-sel'>" +
              ["missed_vehicle", "cancelled", "used_other", "service_unavailable", "capacity_unavailable", "unknown"]
                .map(function (s) { return "<option value='" + s + "'>" + PARA.esc(PARA.CONST.requestLabel[s]) + "</option>"; }).join("") + "</select>") +
            PARA.ui.field("Note (optional)", "<input class='in' id='out-note'>"),
          onOk: function (box) {
            q.status = box.querySelector("#out-sel").value;
            q.note = (q.note ? q.note + " | " : "") + (box.querySelector("#out-note").value || "Outcome corrected by passenger");
            q.resolvedAt = new Date().toISOString();
            PARa_record("correct_request_outcome", "request", q.id, q.code + " → " + q.status);
            PARA.store.save();
            PARA.ui.toast("Thank you — the record has been corrected", "good");
            PARA.render();
          }
        });
      });
    });
  };

  V["passenger-reports"] = function (root) {
    if (!PARA.auth.requireRole("passenger")) { location.hash = "#/"; return; }
    var db = PARA.store.db;
    var p = me();
    var u = PARA.auth.user();
    var mine = db.reports.filter(function (x) { return x.reporterId === u.id; });
    var stops = PARA.geo.stops(PARA.geo.activeRoute().id);

    root.innerHTML =
      "<h1 class='title'>Report a transportation problem</h1>" +
      "<div class='sub'>Your reports show the administrator which problems keep happening, and where.</div>" +
      "<div class='grid g2'>" +
        "<div class='card'><div class='card-head'><h3>New report</h3></div>" +
          "<form id='pr-form'>" +
            PARA.ui.field("What happened?", "<select class='in' name='type'>" +
              PARA.ui.options(PARA.CONST.passengerReportType, "vehicle_did_not_arrive") + "</select>") +
            PARA.ui.field("Where were you?", "<select class='in' name='location'><option value=''>Select a stop</option>" +
              stops.map(function (s) { return "<option value='" + s.id + "'>" + s.position + ". " + PARA.esc(s.name) + "</option>"; }).join("") + "</select>") +
            PARA.ui.field("Describe it", "<textarea class='in' name='description' placeholder='For example: waited 30 minutes and the bus was already full.'></textarea>") +
            "<div class='alert info'>Please give the approximate stop rather than your home. Reports are reviewed by the administrator and are not published with your name.</div>" +
            "<button class='btn' type='submit'>Submit report</button>" +
          "</form>" +
        "</div>" +
        "<div class='card'><div class='card-head'><h3>My reports</h3><span class='card-note'>" + mine.length + " submitted</span></div>" +
          (mine.length ? mine.map(function (x) {
            return "<div class='notif'><div class='ic'>" + (x.status === "resolved" || x.status === "closed" ? "✅" : "⏳") + "</div><div style='flex:1'>" +
              "<div class='t'>" + PARA.esc(PARA.titleize(x.type)) + " — " + PARA.esc(x.code) + "</div>" +
              "<div class='m'>" + PARA.esc(x.description || "") + "</div>" +
              "<div class='m' style='margin-top:4px'>" + PARA.esc(x.location || "") + " · " + PARA.esc(PARA.fmt.ago(x.at)) + "</div></div>" +
              PARA.tag(x.status, PARA.titleize(x.status)) + "</div>";
          }).join("") : "<div class='empty'>You have not submitted any reports.</div>") +
        "</div>" +
      "</div>";

    root.querySelector("#pr-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var f = new FormData(e.target);
      var sel = f.get("location");
      var s = db.stops.filter(function (x) { return x.id === sel; })[0];
      db.reports.unshift({
        id: PARA.store.uid("rpt"), code: "RPT-" + Math.random().toString(36).slice(2, 7).toUpperCase(),
        reporterType: "passenger", reporterId: u.id, type: f.get("type"),
        location: s ? s.name : "", at: new Date().toISOString(),
        description: f.get("description") || "", status: "open", passengerId: p.id
      });
      PARa_record("submit_passenger_report", "report", null, PARA.titleize(f.get("type")) + (s ? " at " + s.name : ""));
      PARA.store.save();
      PARA.ui.toast("Report submitted. Thank you for helping improve the service.", "good");
      PARA.render();
    });
  };

  V["passenger-alerts"] = function (root) {
    if (!PARA.auth.requireRole("passenger")) { location.hash = "#/"; return; }
    var u = PARA.auth.user();
    var list = PARA.store.db.notifications.filter(function (n) { return n.to === u.id; });
    root.innerHTML =
      "<h1 class='title'>My alerts</h1>" +
      "<div class='sub'>Service interruptions, delays and announcements sent to you.</div>" +
      "<div class='card'>" +
        (list.length ? list.map(function (n) {
          var ic = { delay: "⏱", service_interruption: "⚠️", service_resumed: "✅", suspension: "🛑", vehicle_approaching: "🚌", announcement: "📢", system: "🔔" }[n.type] || "🔔";
          return "<div class='notif" + (n.read ? "" : " unread") + "'><div class='ic'>" + ic + "</div><div style='flex:1'>" +
            "<div class='t'>" + PARA.esc(n.title) + " " + PARA.tag(n.priority, PARA.titleize(n.priority)) + "</div>" +
            "<div class='m'>" + PARA.esc(n.body) + "</div>" +
            "<div class='m' style='margin-top:4px'>" + PARA.esc(PARA.fmt.dateTime(n.at)) + "</div></div></div>";
        }).join("") : "<div class='empty'>No alerts yet. Turn on alerts for interruptions and delays on the <a href='#/account'>account page</a>.</div>") +
      "</div>" +
      "<div class='card'><div class='card-head'><h3>Manage what you receive</h3></div>" +
        "<p style='font-size:13.5px;color:#5f6b62'>PARA does not send every update. Choose the alert types that matter to you on the account page so you are not disturbed unnecessarily.</p>" +
        "<a class='btn ghost' href='#/account'>Open alert preferences</a>" +
      "</div>";
  };

})(PARA.views);
