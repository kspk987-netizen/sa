window.PARA = window.PARA || {};

PARA.analytics = {
  RANGES: [
    { id: "today", label: "Today", days: 1 },
    { id: "week", label: "Last 7 days", days: 7 },
    { id: "month", label: "Last 30 days", days: 30 },
    { id: "all", label: "All recorded data", days: 3650 }
  ],

  range: function (id) {
    var def = this.RANGES.filter(function (r) { return r.id === id; })[0] || this.RANGES[1];
    var to = new Date();
    var from = new Date(to.getTime() - def.days * 86400000);
    if (def.id === "today") { from.setHours(0, 0, 0, 0); }
    return { id: def.id, label: def.label, from: from, to: to };
  },

  within: function (iso, r) {
    if (!iso) return false;
    var t = new Date(iso).getTime();
    return t >= r.from.getTime() && t <= r.to.getTime();
  },

  avg: function (nums) {
    var f = nums.filter(function (n) { return typeof n === "number" && !isNaN(n); });
    if (!f.length) return null;
    return f.reduce(function (a, b) { return a + b; }, 0) / f.length;
  },

  median: function (nums) {
    var f = nums.filter(function (n) { return typeof n === "number" && !isNaN(n); }).sort(function (a, b) { return a - b; });
    if (!f.length) return null;
    var mid = Math.floor(f.length / 2);
    return f.length % 2 ? f[mid] : (f[mid - 1] + f[mid]) / 2;
  },

  max: function (nums) {
    var f = nums.filter(function (n) { return typeof n === "number" && !isNaN(n); });
    return f.length ? Math.max.apply(null, f) : null;
  },

  min: function (nums) {
    var f = nums.filter(function (n) { return typeof n === "number" && !isNaN(n); });
    return f.length ? Math.min.apply(null, f) : null;
  },

  tripsIn: function (r) {
    return PARA.store.db.trips.filter(function (t) { return this.within(t.startAt, r); }, this);
  },

  requestsIn: function (r) {
    return PARA.store.db.requests.filter(function (q) {
      return this.within(q.createdAt || q.date, r);
    }, this);
  },

  hourKey: function (iso) { return new Date(iso).getHours(); },

  demandByHour: function (r) {
    var buckets = [], i;
    for (i = 0; i < 24; i++) buckets.push({ hour: i, requests: 0, must: 0, served: 0, trips: 0, passengers: 0 });
    this.requestsIn(r).forEach(function (q) {
      var h = PARA.analytics.hourKey(q.desiredTime || q.date);
      if (!buckets[h]) return;
      buckets[h].requests++;
      if (q.sensitivity === "must_arrive_by") buckets[h].must++;
      if (q.status === "served") buckets[h].served++;
    });
    this.tripsIn(r).forEach(function (t) {
      var h = PARA.analytics.hourKey(t.startAt);
      if (!buckets[h]) return;
      buckets[h].trips++;
      buckets[h].passengers += t.passengers || 0;
    });
    return buckets;
  },

  demandByDow: function (r) {
    var names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    var buckets = names.map(function (n) { return { day: n, requests: 0, passengers: 0, trips: 0 }; });
    this.requestsIn(r).forEach(function (q) {
      var d = new Date(q.desiredTime || q.date).getDay();
      buckets[d].requests++;
    });
    this.tripsIn(r).forEach(function (t) {
      var d = new Date(t.startAt).getDay();
      buckets[d].trips++;
      buckets[d].passengers += t.passengers || 0;
    });
    return buckets;
  },

  demandByStop: function (r) {
    var db = PARA.store.db;
    return db.stops.slice().sort(function (a, b) { return a.position - b.position; }).map(function (s) {
      var asOrigin = 0, asDest = 0, waitSamples = [], servedAsDest = 0;
      db.requests.forEach(function (q) {
        if (PARA.analytics.within(q.createdAt || q.date, r)) {
          if (q.originId === s.id) asOrigin++;
          if (q.destId === s.id) { asDest++; if (q.status === "served") servedAsDest++; }
        }
      });
      db.waitingTimes.forEach(function (w) {
        if (w.stopId === s.id && PARA.analytics.within(w.arrivedAt, r)) waitSamples.push(w.waitMin);
      });
      return {
        stop: s, requests: asOrigin + asDest, asOrigin: asOrigin, asDest: asDest,
        avgWait: this.avg(waitSamples), maxWait: this.max(waitSamples),
        waitSamples: waitSamples.length, fulfilled: asDest ? Math.round((servedAsDest / asDest) * 100) : null
      };
    }, this);
  },

  demandBySensitivity: function (r) {
    var out = PARA.CONST.sensitivity.map(function (s) { return { key: s, label: PARA.CONST.sensitivityLabel[s], count: 0, served: 0 }; });
    this.requestsIn(r).forEach(function (q) {
      var row = out.filter(function (o) { return o.key === q.sensitivity; })[0];
      if (!row) return;
      row.count++;
      if (q.status === "served") row.served++;
    });
    return out;
  },

  peak: function (r) {
    var hourly = this.demandByHour(r);
    var top = hourly.slice().sort(function (a, b) { return b.requests - a.requests; }).slice(0, 3);
    var morning = hourly.slice(5, 10).reduce(function (a, b) { return a + b.requests; }, 0);
    var midday = hourly.slice(10, 15).reduce(function (a, b) { return a + b.requests; }, 0);
    var evening = hourly.slice(15, 21).reduce(function (a, b) { return a + b.requests; }, 0);
    var schoolPeak = hourly[7].requests + hourly[15].requests + hourly[16].requests;
    var workPeak = hourly[6].requests + hourly[7].requests + hourly[8].requests + hourly[17].requests + hourly[18].requests;
    var total = hourly.reduce(function (a, b) { return a + b.requests; }, 0);
    return {
      hours: top, total: total,
      morning: morning, midday: midday, evening: evening,
      schoolPeak: schoolPeak, workPeak: workPeak,
      quietest: hourly.slice().sort(function (a, b) { return a.requests - b.requests; })[0],
      busiest: top[0]
    };
  },

  tripStats: function (r) {
    var trips = this.tripsIn(r);
    var pax = trips.map(function (t) { return t.passengers || 0; });
    var dur = trips.map(function (t) { return t.durationMin; });
    var delay = trips.map(function (t) { return t.delayMin || 0; });
    var delayed = trips.filter(function (t) { return (t.delayMin || 0) > 0; });
    return {
      count: trips.length,
      passengers: pax.reduce(function (a, b) { return a + b; }, 0),
      avgPax: this.avg(pax),
      maxPax: this.max(pax),
      avgDuration: this.avg(dur),
      minDuration: this.min(dur),
      maxDuration: this.max(dur),
      avgDelay: this.avg(delay),
      delayedTrips: delayed.length,
      delayRate: trips.length ? Math.round((delayed.length / trips.length) * 100) : 0,
      completed: trips.filter(function (t) { return t.status === "completed"; }).length
    };
  },

  waitStats: function (r) {
    var db = PARA.store.db;
    var rows = db.waitingTimes.filter(function (w) { return this.within(w.arrivedAt, r); }, this);
    var mins = rows.map(function (w) { return w.waitMin; });
    var byHour = [];
    var i;
    for (i = 0; i < 24; i++) byHour.push({ hour: i, samples: [], sum: 0 });
    rows.forEach(function (w) {
      var h = new Date(w.arrivedAt).getHours();
      byHour[h].samples.push(w.waitMin);
    });
    byHour = byHour.map(function (b) {
      return { hour: b.hour, count: b.samples.length, avg: PARA.analytics.avg(b.samples) };
    });
    return {
      count: rows.length, avg: this.avg(mins), median: this.median(mins),
      max: this.max(mins), min: this.min(mins), byHour: byHour
    };
  },

  travelStats: function (r) {
    var db = PARA.store.db;
    var rows = db.travelTimes.filter(function (t) { return this.within(t.endedAt, r); }, this);
    var mins = rows.map(function (t) { return t.minutes; });
    var bySeg = {};
    rows.forEach(function (t) {
      var key = t.fromStopId + ">" + t.toStopId;
      if (!bySeg[key]) bySeg[key] = { fromStopId: t.fromStopId, toStopId: t.toStopId, samples: [] };
      bySeg[key].samples.push(t.minutes);
    });
    var segments = Object.keys(bySeg).map(function (k) {
      var s = bySeg[k];
      return {
        from: s.fromStopId, to: s.toStopId, count: s.samples.length,
        avg: PARA.analytics.avg(s.samples), max: PARA.analytics.max(s.samples), min: PARA.analytics.min(s.samples)
      };
    }).sort(function (a, b) { return (b.avg || 0) - (a.avg || 0); });
    var stopName = function (id) {
      var s = db.stops.filter(function (x) { return x.id === id; })[0];
      return s ? s.name : "Unknown stop";
    };
    return {
      count: rows.length, avg: this.avg(mins), min: this.min(mins), max: this.max(mins),
      segments: segments.map(function (s) {
        return { fromName: stopName(s.from), toName: stopName(s.to), count: s.count, avg: s.avg, max: s.max, min: s.min };
      })
    };
  },

  delayStats: function (r) {
    var db = PARA.store.db;
    var rows = db.delays.filter(function (d) { return this.within(d.detectedAt, r); }, this);
    var byReason = {};
    rows.forEach(function (d) {
      byReason[d.reason] = (byReason[d.reason] || 0) + 1;
    });
    var byStop = {};
    rows.forEach(function (d) {
      if (!d.stopId) return;
      byStop[d.stopId] = (byStop[d.stopId] || 0) + 1;
    });
    var stopName = function (id) {
      var s = db.stops.filter(function (x) { return x.id === id; })[0];
      return s ? s.name : "Unspecified";
    };
    return {
      count: rows.length,
      avgDelay: this.avg(rows.map(function (d) { return d.delayMin; })),
      maxDelay: this.max(rows.map(function (d) { return d.delayMin; })),
      reasons: Object.keys(byReason).map(function (k) { return { reason: k, count: byReason[k] }; }).sort(function (a, b) { return b.count - a.count; }),
      hotspots: Object.keys(byStop).map(function (k) { return { stopName: stopName(k), count: byStop[k] }; }).sort(function (a, b) { return b.count - a.count; })
    };
  },

  capacity: function (r) {
    var db = PARA.store.db;
    var hourlyCapacity = {};
    this.tripsIn(r).forEach(function (t) {
      var h = PARA.analytics.hourKey(t.startAt);
      hourlyCapacity[h] = (hourlyCapacity[h] || 0) + (t.capacityAtTime || 0);
    });
    var hourly = this.demandByHour(r);
    var rows = hourly.map(function (b) {
      var cap = hourlyCapacity[b.hour] || 0;
      var util = cap ? Math.round((b.requests / cap) * 100) : null;
      return {
        hour: b.hour, requests: b.requests, capacity: cap, passengers: b.passengers,
        utilization: util,
        pressure: util == null ? "unknown" : util >= 100 ? "over" : util >= 75 ? "high" : util >= 40 ? "moderate" : "low"
      };
    });
    var measured = rows.filter(function (x) { return x.capacity > 0; });
    return {
      rows: rows,
      totalCapacity: measured.reduce(function (a, b) { return a + b.capacity; }, 0),
      totalRequests: hourly.reduce(function (a, b) { return a + b.requests; }, 0),
      avgUtilization: this.avg(measured.map(function (x) { return x.utilization; })),
      pressureHours: rows.filter(function (x) { return x.pressure === "over" || x.pressure === "high"; }),
      fleetCapacity: db.vehicles.filter(function (v) { return v.status !== "out_of_service"; })
        .reduce(function (a, v) { return a + (v.capacity || 0); }, 0)
    };
  },

  unmet: function (r) {
    var rows = this.requestsIn(r);
    var served = rows.filter(function (q) { return q.status === "served"; });
    var notServed = rows.filter(function (q) { return q.status !== "served" && q.status !== "submitted" && q.status !== "assigned"; });
    var byStatus = {};
    notServed.forEach(function (q) { byStatus[q.status] = (byStatus[q.status] || 0) + 1; });
    var mustNotServed = notServed.filter(function (q) { return q.sensitivity === "must_arrive_by"; });
    return {
      total: rows.length,
      served: served.length,
      servedRate: rows.length ? Math.round((served.length / rows.length) * 100) : 0,
      unmet: notServed.length,
      mustNotServed: mustNotServed.length,
      byStatus: Object.keys(byStatus).map(function (k) { return { status: k, count: byStatus[k] }; }).sort(function (a, b) { return b.count - a.count; })
    };
  },

  fleet: function () {
    var db = PARA.store.db;
    return {
      total: db.vehicles.length,
      inService: db.vehicles.filter(function (v) { return v.status !== "out_of_service"; }).length,
      onTrip: db.vehicles.filter(function (v) { return v.status === "on_trip"; }).length,
      delayed: db.vehicles.filter(function (v) { return v.status === "delayed"; }).length,
      gpsIssues: db.vehicles.filter(function (v) { return PARA.geo.gpsFreshness(v) !== "active" && v.status !== "out_of_service"; }),
      seats: db.vehicles.filter(function (v) { return v.status !== "out_of_service"; }).reduce(function (a, v) { return a + (v.capacity || 0); }, 0)
    };
  },

  drivers: function () {
    var db = PARA.store.db;
    return {
      total: db.drivers.length,
      active: db.drivers.filter(function (d) { return d.status === "active"; }).length,
      suspended: db.drivers.filter(function (d) { return d.status === "suspended"; }).length,
      unassigned: db.drivers.filter(function (d) { return d.status === "active" && !d.vehicleId; }).length
    };
  },

  dataQuality: function (r) {
    var db = PARA.store.db;
    var flags = [];
    db.vehicles.forEach(function (v) {
      if (v.status === "out_of_service") return;
      var fresh = PARA.geo.gpsFreshness(v);
      if (fresh !== "active") {
        flags.push({ severity: fresh === "unavailable" ? "high" : "medium", kind: "GPS signal", subject: v.name, detail: PARA.geo.gpsNote(v) });
      }
    });
    this.tripsIn(r).forEach(function (t) {
      var mins = (Date.now() - new Date(t.startAt).getTime()) / 60000;
      if (t.status !== "completed" && mins > 240) flags.push({ severity: "high", kind: "Long-running trip", subject: t.code, detail: "Open for " + Math.round(mins) + " minutes" });
      if (t.status === "completed" && (t.passengers == null)) flags.push({ severity: "medium", kind: "Missing passenger count", subject: t.code, detail: "Completed trip has no passenger count recorded" });
      if (t.status === "completed" && t.durationMin > 150) flags.push({ severity: "medium", kind: "Unusually long trip", subject: t.code, detail: t.durationMin + " minutes recorded" });
      if (t.status === "completed" && t.durationMin && t.durationMin < 10) flags.push({ severity: "medium", kind: "Unusually short trip", subject: t.code, detail: t.durationMin + " minutes recorded" });
    });
    db.requests.forEach(function (q) {
      if (q.status === "unknown") flags.push({ severity: "low", kind: "Unresolved request", subject: q.code, detail: "Outcome never confirmed" });
    });
    return flags;
  },

  dailySummary: function (dateIso) {
    var day = dateIso ? new Date(dateIso) : new Date();
    day.setHours(0, 0, 0, 0);
    var r = { id: "custom", label: day.toDateString(), from: day, to: new Date(day.getTime() + 86400000 - 1) };
    var s = this.tripStats(r), w = this.waitStats(r), c = this.capacity(r);
    return {
      date: day, trips: s.count, passengers: s.passengers, requests: c.totalRequests,
      avgWait: w.avg, avgDuration: s.avgDuration, delays: s.delayedTrips,
      fleetActive: this.fleet().onTrip, serviceStatus: PARA.store.db.serviceStatus
    };
  },

  trend: function (weeks) {
    var out = [], now = new Date();
    var n = weeks || 8;
    for (var i = n - 1; i >= 0; i--) {
      var end = new Date(now.getTime() - i * 7 * 86400000);
      var start = new Date(end.getTime() - 6 * 86400000);
      var r = { id: "custom", label: "Week of " + start.toLocaleDateString([], { month: "short", day: "numeric" }), from: start, to: end };
      var s = this.tripStats(r), w = this.waitStats(r), c = this.capacity(r);
      out.push({ label: r.label, trips: s.count, passengers: s.passengers, requests: c.totalRequests, avgWait: w.avg, avgDuration: s.avgDuration, delays: s.delayedTrips });
    }
    return out;
  },

  patterns: function (r) {
    var hourly = this.demandByHour(r);
    var found = [];
    hourly.forEach(function (b) {
      if (b.requests >= 3) {
        var reasons = [];
        if (b.hour === 7 || b.hour === 15 || b.hour === 16) reasons.push("school hours pattern");
        if (b.hour >= 6 && b.hour <= 9) reasons.push("morning commuting pattern");
        if (b.hour >= 17 && b.hour <= 19) reasons.push("evening return pattern");
        if (b.hour >= 11 && b.hour <= 13) reasons.push("midday errand pattern");
        if (reasons.length) {
          found.push({
            label: (b.hour < 10 ? "0" : "") + b.hour + ":00–" + ((b.hour + 1) < 10 ? "0" : "") + (b.hour + 1) + ":00",
            requests: b.requests, passengers: b.passengers, trips: b.trips,
            note: "Consistent with a " + reasons.join(" and ") + " based on recorded requests"
          });
        }
      }
    });
    var dow = this.demandByDow(r);
    var busyDay = dow.slice().sort(function (a, b) { return b.requests - a.requests; })[0];
    var quietDay = dow.slice().sort(function (a, b) { return a.requests - b.requests; })[0];
    if (busyDay && busyDay.requests > 0) {
      found.push({ label: busyDay.day, requests: busyDay.requests, passengers: busyDay.passengers, trips: busyDay.trips, note: "Highest recorded demand day of the week" });
    }
    if (quietDay && quietDay.requests >= 0 && busyDay && quietDay.day !== busyDay.day) {
      found.push({ label: quietDay.day, requests: quietDay.requests, passengers: quietDay.passengers, trips: quietDay.trips, note: "Lowest recorded demand day of the week" });
    }
    return found;
  },

  correlations: function (r) {
    var out = [];
    var hourly = this.demandByHour(r);
    var trips = this.tripsIn(r);
    var wait = this.waitStats(r);
    var travel = this.travelStats(r);

    var byHourDur = {};
    trips.forEach(function (t) {
      var h = PARA.analytics.hourKey(t.startAt);
      (byHourDur[h] = byHourDur[h] || []).push(t.durationMin);
    });
    var durPairs = [];
    hourly.forEach(function (b) {
      if (byHourDur[b.hour] && b.requests > 0) durPairs.push({ x: b.requests, y: PARA.analytics.avg(byHourDur[b.hour]) });
    });
    if (durPairs.length >= 3) {
      var r1 = PARA.analytics.correlation(durPairs.map(function (p) { return p.x; }), durPairs.map(function (p) { return p.y; }));
      out.push({
        a: "Passenger requests vs trip duration by hour",
        r: r1,
        reading: r1 > 0.4 ? "Busier hours are associated with longer trips" : r1 < -0.4 ? "Busier hours are associated with shorter trips" : "No clear relationship between request volume and trip duration in the recorded window"
      });
    }
    if (wait.count >= 3) {
      var peakWaitHours = wait.byHour.filter(function (h) { return h.count >= 1; }).sort(function (a, b) { return (b.avg || 0) - (a.avg || 0); })[0];
      if (peakWaitHours) {
        out.push({
          a: "Waiting time by hour of day",
          r: null,
          reading: "Longest average wait recorded at " + (peakWaitHours.hour < 10 ? "0" : "") + peakWaitHours.hour + ":00 (" + PARA.fmt.mins(peakWaitHours.avg) + " across " + peakWaitHours.count + " samples)"
        });
      }
    }
    if (travel.segments.length) {
      var worst = travel.segments[0];
      out.push({
        a: "Travel time by stop segment",
        r: null,
        reading: "Slowest segment is " + worst.fromName + " → " + worst.toName + " at " + PARA.fmt.mins(worst.avg) + " average across " + worst.count + " recorded runs"
      });
    }
    return out;
  },

  correlation: function (xs, ys) {
    var n = Math.min(xs.length, ys.length);
    if (n < 3) return null;
    var mx = 0, my = 0, i;
    for (i = 0; i < n; i++) { mx += xs[i]; my += ys[i]; }
    mx /= n; my /= n;
    var num = 0, dx = 0, dy = 0;
    for (i = 0; i < n; i++) {
      var a = xs[i] - mx, b = ys[i] - my;
      num += a * b; dx += a * a; dy += b * b;
    }
    if (dx === 0 || dy === 0) return 0;
    return Math.round((num / Math.sqrt(dx * dy)) * 100) / 100;
  },

  planTrip: function (originId, destId, desiredIso, sensitivity) {
    var route = PARA.geo.activeRoute();
    if (!route) return { ok: false, error: "No active route is configured yet." };
    var list = PARA.geo.stops(route.id);
    var from = list.filter(function (s) { return s.id === originId; })[0];
    var to = list.filter(function (s) { return s.id === destId; })[0];
    if (!from) return { ok: false, error: "Choose a starting stop." };
    if (!to) return { ok: false, error: "Choose a destination stop." };
    if (from.id === to.id) return { ok: false, error: "Starting stop and destination are the same." };

    var forward = from.position < to.position;
    var ordered = list.filter(function (s) {
      return forward ? s.position > from.position && s.position <= to.position : s.position < from.position && s.position >= to.position;
    });
    if (!ordered.length) ordered = [to];

    var rideMin = 0;
    ordered.forEach(function (s) {
      var idx = list.indexOf(s);
      var prev = list[idx - 1];
      if (prev) rideMin += PARA.geo.segmentMinutes(prev, s);
    });
    if (!rideMin) rideMin = 8;

    var last7 = PARA.analytics.travelStats(PARA.analytics.range("week"));
    var segSamples = [];
    ordered.forEach(function (s) {
      var idx = list.indexOf(s), prev = list[idx - 1];
      if (!prev) return;
      last7.segments.forEach(function (seg) {
        if ((seg.fromName === prev.name && seg.toName === s.name)) segSamples.push(seg.avg);
      });
    });
    var observedRide = PARA.analytics.avg(segSamples);
    var typicalRide = observedRide != null ? Math.round(observedRide * ordered.length) : rideMin;

    var bufferMin = sensitivity === "must_arrive_by" ? 12 : sensitivity === "prefer_to_arrive_by" ? 8 : 5;
    var boardBufferMin = 6;

    var desired = new Date(desiredIso);
    if (isNaN(desired.getTime())) return { ok: false, error: "Enter a valid desired arrival time." };

    var liveTrips = PARA.geo.activeTrips().filter(function (t) { return t.routeId === route.id; });
    var bestLive = null;
    liveTrips.forEach(function (t) {
      var mins = PARA.geo.etaMinutes(t, to.id);
      if (mins <= 0) return;
      if (!bestLive || mins < bestLive.mins) bestLive = { mins: mins, trip: t };
    });

    var nextDeparture = new Date();
    if (bestLive) {
      nextDeparture = new Date(Date.now() + bestLive.mins * 60000);
    } else {
      var firstStop = list[0];
      var [hh, mm] = String(route.operatingHours.start || "06:00").split(":").map(Number);
      var candidate = new Date(desired);
      candidate.setHours(hh, mm, 0, 0);
      if (candidate < new Date()) candidate = new Date();
      nextDeparture = candidate;
    }

    var arriveBy = new Date(nextDeparture.getTime() + typicalRide * 60000);
    var recommendedLeave = new Date(nextDeparture.getTime() - boardBufferMin * 60000);
    if (recommendedLeave < new Date()) recommendedLeave = new Date();

    return {
      ok: true,
      route: route,
      from: from, to: to, ordered: ordered,
      typicalRideMin: typicalRide,
      plannedRideMin: rideMin,
      usingObserved: observedRide != null,
      observedRideMin: observedRide,
      bufferMin: bufferMin,
      boardBufferMin: boardBufferMin,
      nextDeparture: nextDeparture,
      arriveBy: arriveBy,
      recommendedLeave: recommendedLeave,
      live: bestLive,
      desired: desired,
      withinDesired: arriveBy <= desired,
      basis: observedRide != null
        ? "Historical average of " + segSamples.length + " recorded segment" + (segSamples.length === 1 ? "" : "s") + " between these stops"
        : "Planned scheduled travel time for these segments (no completed runs recorded yet)"
    };
  },

  exportCsv: function (filename, headers, rows) {
    var esc = function (v) {
      if (v == null) return "";
      var s = String(v);
      return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    };
    var lines = [headers.map(esc).join(",")];
    rows.forEach(function (r) { lines.push(r.map(esc).join(",")); });
    var blob = new Blob(["\uFEFF" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }
};
