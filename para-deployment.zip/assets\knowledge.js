window.PARA = window.PARA || {};

/*
 * PARA knowledge base for the AI assistant (RAG retrieval source).
 * Each note is a short, factual page about the project. The assistant
 * retrieves the most relevant notes for a question and sends them to the
 * model as grounding context, so answers stay about this website.
 */
PARA.KB = [
  {
    id: "overview",
    title: "What PARA is",
    tags: "para about overview website app project purpose what is features demo passenger alert routing assistant",
    text: "PARA stands for Passenger Alert and Routing Assistant. It is a community transportation support system: one fixed bus route with live vehicle positions, estimated arrival times at every stop, a trip planner that tells you when to reach your stop, service-status and delay alerts, and a records side that measures actual waiting and travel times so the community can see where service is under pressure. PARA has four ways to use it: a public visitor (no account), a passenger account, a driver/transportation operator account, and an administrator account. The project is a self-contained demo: the public website is plain HTML, CSS and JavaScript, and all demo records live in your own browser, not on a server."
  },
  {
    id: "roles",
    title: "Roles and demo accounts",
    tags: "roles accounts login demo admin passenger driver operator credentials sign in username password",
    text: "There are three signed-in roles plus public visitors. Administrator: full control of drivers, vehicles, the route and stops, announcements, incidents, analytics, service status and logs. Driver (transportation operator): sees their account, assigned vehicle, assigned route and its stops, current trip, vehicle status, trip history and can file reports. Passenger: sees a personal dashboard, can request a ride, track requests, receive alerts and file reports. Demo accounts for this installation: administrator is admin / admin123, driver is driver1 / driver123, passenger is passenger1 / passenger123. A second driver, driver2 / driver123, is also active; driver3 is deactivated, so signing in as driver3 is refused on purpose. Public visitors can browse the home page, the route and the trip planner without signing in."
  },
  {
    id: "accounts-login",
    title: "Sign in, sign up and account settings",
    tags: "login signup register account password change preferences sign in create account session",
    text: "Sign in from the Sign in button in the top bar (page #/login). The sign-in card shows the demo accounts. Passengers can create their own account from the sign-up link (#/signup): full name, username, password of at least 6 characters, optional mobile number and email, and a usual starting stop used only as a default for requests - exact home addresses are never stored. Administrators are the only ones who can register driver accounts, from the Drivers section. The Account page (#/account) shows your profile, lets you change your password, and for passengers also manages alert preferences and an SMS-alert demo toggle. Sessions last 12 hours and are stored per browser tab; signing out clears the session."
  },
  {
    id: "route-stops",
    title: "The route and its stops",
    tags: "route stops RTE-001 main route central station west end terminal stops sequence schedule operating hours distance",
    text: "The site operates one route: RTE-001, the Community Main Route, from Central Station to West End Terminal. It is 18.5 km long, takes about 55 minutes end to end, and runs from 05:30 to 21:00 every day. The eight stops in order are: 1 Central Station (primary boarding point with a ticketing counter), 2 Market Square, 3 School Junction (busy at 06:00-08:00 and 15:00-17:00), 4 Hospital Corner, 5 Shopping Center, 6 Park Avenue, 7 Library Stop, and 8 West End Terminal (with a waiting shed). Most stops have a shelter, seating and accessible boarding; Park Avenue has no shelter. The Route & stops page (#/route) lists each stop with its planned travel time from the previous stop, the next estimated arrival time, recorded demand over the last 30 days, average recorded wait, and facilities."
  },
  {
    id: "live-tracking",
    title: "Service status and live vehicle positions",
    tags: "service status live map tracking vehicle position eta announcement delayed suspended operating normally",
    text: "The home page (#/) opens with a service-status banner and a live map. Service status is one of: Operating Normally, Delayed, Limited Service, Temporarily Suspended, Service Resumed, or Emergency, and it is maintained by the administrator; the banner also shows how many vehicles are running and how many seats are in service. The live map draws the route with stop markers and every vehicle currently running (green when on time, red when delayed). Positions are approximate and refresh every few seconds. Below the map, 'Today's picture' summarises the route, the service hours, the next vehicle due at a stop, and the busiest hour this week, and the Announcements card lists active public notices such as schedule changes or a relocated stop."
  },
  {
    id: "trip-planner",
    title: "How the trip planner works",
    tags: "plan trip planner recommended departure arrival time must arrive by prefer flexible buffer estimate",
    text: "Plan your trip (#/planner) works backwards from normal travel time to suggest when to reach your stop. Choose a starting stop, a destination stop, the date, the latest arrival time, and how strict the arrival is: Must Arrive By adds a larger safety buffer, Prefer To Arrive By a moderate one, Flexible allows more variation. PARA combines the recorded average travel time for your segment (falling back to the schedule when there is no history yet), the live position and current delay of a vehicle if one is running, a boarding buffer, and the safety buffer, then shows the recommended time to be at your stop, the expected ride time, the estimated arrival and whether it is within what you asked for. The result is an estimate, not a guarantee, and a signed-in passenger can turn the plan into a ride request with one button."
  },
  {
    id: "passenger-features",
    title: "What passengers can do",
    tags: "passenger dashboard request ride requests alerts report problem statuses missed vehicle capacity unavailable",
    text: "A signed-in passenger gets a personal dashboard (#/passenger) with the service status, upcoming departures, live vehicles and their own recent activity. 'Request a ride' (#/passenger/request-new) submits a transportation request: origin, destination, desired time, how strict the arrival is, and an optional note. My requests (#/passenger/requests) lists every request with its status: Submitted, Assigned, Served, Cancelled, Missed Vehicle, Used Another Method, Service Unavailable, Capacity Unavailable or Unknown. Alerts (#/passenger/alerts) collects notifications such as delays, service interruptions, suspensions, resumptions, vehicle-approaching notices and announcements, with an unread badge in the top bar. Report a problem (#/passenger/reports) files a passenger report: vehicle did not arrive, excessive waiting, vehicle was full, unexpected delay, road problem, service interruption, or other."
  },
  {
    id: "driver-features",
    title: "What drivers can do",
    tags: "driver operator my day assigned vehicle route current trip start trip status history report heavy traffic accident flooding road closure",
    text: "The driver or transportation operator view (#/driver) shows everything about the working day: account information, the assigned vehicle, the assigned route with its stops, the current trip, and the current vehicle status. From 'My day' the driver can start a trip and update its status - active, temporarily stopped, delayed, vehicle problem, road problem, emergency, completed - with a reason such as traffic, road obstruction, accident, road construction, weather, vehicle problem or passenger loading when relevant. Trip history (#/driver/trips) lists completed trips with duration, passengers carried and any delay. Report a problem (#/driver/reports) files a driver report: heavy traffic, road obstruction, accident, flooding, road closure, vehicle problem, passenger problem, service interruption, emergency, or other. Driver accounts are created by the administrator, never by self-registration."
  },
  {
    id: "admin-features",
    title: "What administrators can do",
    tags: "admin administrator overview drivers vehicles route plan announcements incidents analytics service status logs data reset",
    text: "The administrator role manages the whole service. Overview (#/admin) shows KPIs such as fleet status, trips today, waiting and delay figures. Drivers (#/admin/drivers) registers driver accounts, assigns vehicles, and activates, deactivates or suspends drivers. Vehicles (#/admin/vehicles) manages the fleet - type, capacity, plate, status (available, active, on trip, delayed, temporarily stopped, out of service, emergency, offline) and service dates. Route plan (#/admin/route) maintains the route and its stops, including shelter, seating and accessibility. Announcements publishes public notices with priority and an optional end date. Incidents reviews confirmed problems with a resolution. Analytics reports demand by hour and by stop, waiting times, travel times per segment, delays, capacity utilisation, data quality and recommendations, and can export the numbers. Service status sets the banner state shown to everyone. Logs shows the activity trail, and Data (#/admin/data) handles demo-data maintenance and storage."
  },
  {
    id: "alerts-notifications",
    title: "Alerts and notification preferences",
    tags: "alerts notifications delay service interruption resumed suspension vehicle approaching announcement preferences sms unread",
    text: "PARA generates notifications of type delay, service interruption, service resumed, suspension, vehicle approaching, announcement and system. Passenger alerts appear on the Alerts page (#/passenger/alerts) and raise the unread badge in the top bar; when an administrator changes the service status or confirms a delay, affected passengers are notified automatically. On the Account page, passengers control which alerts they receive: service interruption alerts, major delay alerts, general announcements, and a vehicle-approaching-my-stop alert, plus an SMS-alert toggle in this demo. The SMS option is simulated - nothing is actually sent - and the vehicle-arrival alert is off by default for new accounts."
  },
  {
    id: "analytics",
    title: "Analytics and community intelligence",
    tags: "analytics data demand waiting time travel time delays capacity utilisation peak data quality export csv recommendations",
    text: "The Analytics section (#/admin/analytics) is where recorded history becomes useful. It reports demand by hour of the day and by stop, average and longest waiting times, travel time per route segment, whole-trip durations, delay events with reasons, capacity utilisation per trip, and fleet status. A range selector switches between recent periods (for example this week or this month) and the insights section turns the numbers into plain-language readings, like the busiest hour or the slowest segment, with suggestions such as re-timing arrivals in peak hours. Data quality flags unusual records, for example a trip that has been running for more than four hours, and exports produce CSV files for further study. This is the evidence base for the community: it shows when service is under pressure and where to improve it."
  },
  {
    id: "privacy-data",
    title: "Where the data lives and how to reset it",
    tags: "privacy storage local browser reset data clear localStorage demo wipe GDPR",
    text: "This installation stores everything locally in your browser: the demo database lives in localStorage and the login session in sessionStorage. No page data is sent to a server; the only outbound request is the one you trigger by using the AI assistant, which sends the question and the matching site notes to the AI service to write an answer. Because data is per browser, another device sees a different copy, and clearing the browser's site data wipes the records. To restore the seeded demo data without touching browser settings, an administrator can use the Data section (#/admin/data). The public pages always state that recorded data is local and that arrival times are estimates, not guarantees."
  },
  {
    id: "tech-stack",
    title: "How the site is built and deployed",
    tags: "tech stack html css javascript static vercel deployment server backend frontend api nvidia nim model assistant",
    text: "The deployed site is a static application: index.html, styles.css, and a set of plain JavaScript modules in the assets folder that render every page client-side with hash routing. There is no build step. The backend and frontend folders in the project are an earlier full-stack prototype (Node/Express API and a React client) and are not part of the published site. Deployment is to Vercel from the project root; the assistant's serverless function lives in the api folder and keeps the AI provider key on the server side. The AI assistant uses an NVIDIA NIM chat model with retrieval-augmented generation: it retrieves the most relevant notes from this knowledge base and lets the model write the final answer from them, in the style of the page."
  },
  {
    id: "assistant-help",
    title: "About the AI assistant",
    tags: "assistant chatbot ai help rag sources nvidia nim what can you do limits mistakes llm",
    text: "The PARA assistant is the chat button in the bottom-right corner of every page. It answers questions about this website: what PARA is, how the route, stops, trip planner, accounts, alerts, driver tools, admin tools and analytics work. It works with retrieval-augmented generation (RAG): the widget first finds the most relevant notes in the site's knowledge base, then sends your question and those notes to an NVIDIA NIM language model, which writes the answer. Every reply lists the notes it used. It cannot see or change live records, sign in for anyone, or access anything outside this site's documentation, and like all language models it can occasionally be wrong - for anything critical, check the page itself. If the reply fails, make sure the site is running through the local PARA server (start-para) or deployed on Vercel, because the assistant needs its /api/assistant endpoint."
  },
  {
    id: "faq",
    title: "Common questions and troubleshooting",
    tags: "faq help problem troubleshoot run local start server port vercel deploy no vehicle forgot password simulator reset signed out",
    text: "Run the site locally with start-para.bat (or start-para.ps1, default port 5173); double-clicking index.html works for browsing but the AI assistant needs the server. Deploy by running the Vercel CLI in the project root. If the map says no vehicles are currently running, no trip is active at that moment - trips are seeded as completed history and the simulator starts new activity when a page is open. If a driver sign-in fails for driver3, the account is deactivated on purpose; use driver1 or driver2. Forgot a password: this demo stores passwords in the browser, so an administrator can reset demo data from the Data section, which restores the seeded accounts. Arrival times are always estimates. If pages ever look empty after an update, reset the demo data from Admin, Data. The assistant failing with a network or 502 message usually means the local server is not running or the deployment's function is unreachable."
  }
];

/*
 * Small keyword retriever. Scores every note against the question and
 * returns the best matches, so only relevant notes are sent to the model.
 */
PARA.kbRetrieve = function (query, k, pageId) {
  var STOP = {};
  ("a an and are as at be but by can could did do does for from had has have how i if in into is it its me my no not of on or our " +
   "should so tell than that the their them then there these they this to up us was we were what when where which who why will with " +
   "would you your please").split(" ").forEach(function (w) { STOP[w] = 1; });

  function tokens(s) {
    return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").split(" ").filter(function (t) {
      return t && t.length > 1 && !STOP[t];
    });
  }

  function matches(qt, dt) {
    if (qt === dt) return 2;
    if (qt.length >= 4 && dt.length >= 4 && (qt.indexOf(dt) === 0 || dt.indexOf(qt) === 0)) return 1;
    return 0;
  }

  var q = tokens(query);
  var qPhrase = " " + tokens(query).join(" ") + " ";
  var scored = PARA.KB.map(function (doc) {
    var title = tokens(doc.title), tags = tokens(doc.tags), text = tokens(doc.text);
    var score = 0;

    q.forEach(function (qt) {
      var i;
      for (i = 0; i < title.length; i++) score += 4 * matches(qt, title[i]);
      for (i = 0; i < tags.length; i++) score += 4 * matches(qt, tags[i]);
      var inText = 0;
      for (i = 0; i < text.length && inText < 4; i++) if (matches(qt, text[i]) > 0) inText++;
      score += inText;
    });

    if (qPhrase.length > 4) {
      var t = " " + title.join(" ") + " " + tags.join(" ") + " ";
      if (t.indexOf(qPhrase) !== -1) score += 6;
      if ((" " + text.join(" ") + " ").indexOf(qPhrase) !== -1) score += 3;
    }
    if (pageId && doc.id === pageId) score += 4;
    return { doc: doc, score: score };
  });

  var hits = scored.filter(function (s) { return s.score > 0; })
    .sort(function (a, b) { return b.score - a.score; })
    .slice(0, k || 4)
    .map(function (s) { return s.doc; });

  if (!hits.length) {
    hits = PARA.KB.filter(function (d) { return d.id === "overview" || d.id === "assistant-help"; });
  } else if (!hits.some(function (d) { return d.id === "overview"; })) {
    hits.push(PARA.KB.filter(function (d) { return d.id === "overview"; })[0]);
  }
  return hits;
};

/* Which knowledge note fits the page the visitor is on right now. */
PARA.kbPageDoc = function (hash) {
  var h = String(hash || "");
  if (/^#\/admin/.test(h)) return "admin-features";
  if (/^#\/driver/.test(h)) return "driver-features";
  if (/^#\/passenger/.test(h)) return "passenger-features";
  if (h === "#/route") return "route-stops";
  if (h === "#/planner") return "trip-planner";
  if (h === "#/login" || h === "#/signup" || h === "#/account") return "accounts-login";
  return "overview";
};
