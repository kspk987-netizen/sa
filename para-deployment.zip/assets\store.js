window.PARA = window.PARA || {};

PARA.KEY_DB = "para_db_v2";
PARA.KEY_SESSION = "para_session_v2";
PARA.SESSION_HOURS = 12;

PARA.CONST = {
  serviceStatus: ["operating_normally", "delayed", "limited_service", "suspended", "resumed", "emergency"],
  serviceLabel: {
    operating_normally: "Operating Normally",
    delayed: "Delayed",
    limited_service: "Limited Service",
    suspended: "Temporarily Suspended",
    resumed: "Service Resumed",
    emergency: "Emergency"
  },
  vehicleStatus: ["available", "active", "on_trip", "delayed", "temporarily_stopped", "out_of_service", "emergency", "offline"],
  vehicleLabel: {
    available: "Available", active: "Active", on_trip: "On Trip", delayed: "Delayed",
    temporarily_stopped: "Temporarily Stopped", out_of_service: "Out of Service",
    emergency: "Emergency", offline: "Offline"
  },
  tripStatus: ["active", "temporarily_stopped", "delayed", "vehicle_problem", "road_problem", "emergency", "completed"],
  tripLabel: {
    active: "Active", temporarily_stopped: "Temporarily Stopped", delayed: "Delayed",
    vehicle_problem: "Vehicle Problem", road_problem: "Road Problem",
    emergency: "Emergency", completed: "Completed"
  },
  sensitivity: ["must_arrive_by", "prefer_to_arrive_by", "flexible"],
  sensitivityLabel: {
    must_arrive_by: "Must Arrive By",
    prefer_to_arrive_by: "Prefer To Arrive By",
    flexible: "Flexible"
  },
  requestStatus: ["submitted", "assigned", "served", "cancelled", "missed_vehicle", "used_other", "service_unavailable", "capacity_unavailable", "unknown"],
  requestLabel: {
    submitted: "Submitted", assigned: "Assigned", served: "Served", cancelled: "Cancelled",
    missed_vehicle: "Missed Vehicle", used_other: "Used Another Method",
    service_unavailable: "Service Unavailable", capacity_unavailable: "Capacity Unavailable", unknown: "Unknown"
  },
  delayReason: ["traffic", "road_obstruction", "accident", "road_construction", "weather", "vehicle_problem", "passenger_loading", "unknown"],
  delayLabel: {
    traffic: "Traffic", road_obstruction: "Road Obstruction", accident: "Accident",
    road_construction: "Road Construction", weather: "Weather",
    vehicle_problem: "Vehicle Problem", passenger_loading: "Passenger Loading", unknown: "Unknown"
  },
  incidentStatus: ["new", "under_review", "confirmed", "resolved", "dismissed"],
  reportStatus: ["open", "investigating", "resolved", "closed"],
  driverReportType: ["heavy_traffic", "road_obstruction", "accident", "flooding", "road_closure", "vehicle_problem", "passenger_problem", "service_interruption", "emergency", "other"],
  passengerReportType: ["vehicle_did_not_arrive", "excessive_waiting", "vehicle_was_full", "unexpected_delay", "road_problem", "service_interruption", "other"],
  driverStatus: ["active", "inactive", "suspended"],
  activation: ["activated", "pending", "deactivated"],
  notifType: ["delay", "service_interruption", "service_resumed", "suspension", "vehicle_approaching", "announcement", "system"],
  notifyPrefKey: {
    service_interruption: "serviceInterruption",
    delay: "majorDelay",
    announcement: "announcements",
    vehicle_approaching: "vehicleArrival"
  }
};

PARA.enumLabel = function (group, value) {
  var map = {
    serviceStatus: PARA.CONST.serviceLabel, vehicleStatus: PARA.CONST.vehicleLabel,
    tripStatus: PARA.CONST.tripLabel, sensitivity: PARA.CONST.sensitivityLabel,
    requestStatus: PARA.CONST.requestLabel, delayReason: PARA.CONST.delayLabel
  }[group] || {};
  if (map[value]) return map[value];
  return String(value || "").replace(/_/g, " ").replace(/^\w/, function (c) { return c.toUpperCase(); });
};

PARA.titleize = function (v) {
  return String(v == null ? "" : v).replace(/_/g, " ").replace(/\b\w/g, function (c) { return c.toUpperCase(); });
};

PARA.store = {
  db: null,

  uid: function (prefix) {
    return (prefix || "id") + "-" + Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4);
  },

  blank: function () {
    return {
      meta: { name: "PARA", full: "Passenger Alert and Routing Assistant", version: 2, seededAt: new Date().toISOString() },
      serviceStatus: "operating_normally",
      serviceUpdatedAt: new Date().toISOString(),
      serviceNote: "",
      users: [], drivers: [], vehicles: [], routes: [], stops: [], trips: [],
      requests: [], announcements: [], incidents: [], reports: [],
      activity: [], notifications: [], gps: [], travelTimes: [], waitingTimes: [], delays: []
    };
  },

  load: function () {
    var raw = null;
    try { raw = localStorage.getItem(PARA.KEY_DB); } catch (e) { raw = null; }
    if (raw) {
      try {
        var parsed = JSON.parse(raw);
        if (parsed && parsed.meta && parsed.stops && parsed.stops.length) { this.db = parsed; return this.db; }
      } catch (e) { }
    }
    this.db = this.seed();
    this.save();
    return this.db;
  },

  save: function () {
    try { localStorage.setItem(PARA.KEY_DB, JSON.stringify(this.db)); } catch (e) {
      if (PARA.ui && PARA.ui.toast) PARA.ui.toast("Storage full — trim GPS history in Analytics → Data quality.", "bad");
    }
  },

  reset: function () { this.db = this.seed(); this.save(); },

  nextId: function (collection, prefix, pad) {
    var max = 0;
    this.db[collection].forEach(function (r) {
      var m = String(r[prefix] || "").match(/(\d+)\s*$/);
      if (m) max = Math.max(max, parseInt(m[1], 10));
    });
    var width = pad || 3;
    return prefix + "-" + String(max + 1).padStart(width, "0");
  },

  seed: function () {
    var db = this.blank();
    var now = Date.now();
    var hoursAgo = function (h) { return new Date(now - h * 3600000).toISOString(); };

    var adminUser = { id: this.uid("usr"), username: "admin", password: "admin123", role: "admin", fullName: "System Administrator", email: "admin@para.local", phone: "+63 900 000 0001", active: true, activated: true, mustChangePassword: false, createdAt: new Date().toISOString(), lastLoginAt: null };
    db.users.push(adminUser);
    db.adminProfile = { userId: adminUser.id, level: "super" };

    var route = {
      id: this.uid("rte"), code: "RTE-001", name: "Community Main Route",
      startPoint: "Central Station", endPoint: "West End Terminal",
      description: "Main community route linking the central market, schools, hospital and the western residential terminals.",
      operatingHours: { start: "05:30", end: "21:00", days: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"] },
      status: "active", distanceKm: 18.5, estDurationMin: 55, createdAt: new Date().toISOString()
    };
    db.routes.push(route);

    var stopSeed = [
      ["STP-001", "Central Station", "Main terminal building", 14.6042, 120.9827, null, 8, 128, true, true, "Primary boarding point with ticketing counter."],
      ["STP-002", "Market Square", "Beside the public market", 14.6025, 120.9800, 5, 6, 96, true, true, "High morning market traffic."],
      ["STP-003", "School Junction", "Community school gate", 14.6000, 120.9770, 6, 7, 164, true, true, "School hours 06:00-08:00 and 15:00-17:00."],
      ["STP-004", "Hospital Corner", "District hospital entrance", 14.5980, 120.9740, 7, 5, 88, true, true, "Also serves the health centre."],
      ["STP-005", "Shopping Center", "In front of the mall", 14.5965, 120.9710, 5, 6, 121, true, true, "Peak on weekends and paydays."],
      ["STP-006", "Park Avenue", "City park gate 2", 14.5950, 120.9680, 6, 5, 64, false, true, "Nearest stop to the park."],
      ["STP-007", "Library Stop", "Public library", 14.5935, 120.9650, 5, 7, 57, true, true, "Near the civic offices."],
      ["STP-008", "West End Terminal", "West end bus terminal", 14.5910, 120.9610, 7, null, 102, true, true, "Terminal with waiting shed."]
    ];
    var stops = stopSeed.map(function (s, i) {
      return {
        id: this.uid("stp"), code: s[0], name: s[1], location: s[2], lat: s[3], lng: s[4],
        routeId: route.id, position: i + 1, travelFromPrev: s[5], travelToNext: s[6],
        demand: s[7], avgWaitMin: null, shelter: s[8], seating: s[9], accessible: true,
        notes: s[10], eta: null, updatedAt: new Date().toISOString()
      };
    }, this);
    db.stops = stops;

    var dUser = { id: this.uid("usr"), username: "driver1", password: "driver123", role: "driver", fullName: "Ramon Dela Cruz", email: "ramon@para.local", phone: "+63 917 555 0101", active: true, activated: true, mustChangePassword: false, createdAt: new Date().toISOString(), lastLoginAt: hoursAgo(20) };
    var dUser2 = { id: this.uid("usr"), username: "driver2", password: "driver123", role: "driver", fullName: "Liza Mendoza", email: "liza@para.local", phone: "+63 917 555 0102", active: true, activated: true, mustChangePassword: false, createdAt: new Date().toISOString(), lastLoginAt: hoursAgo(30) };
    var dUser3 = { id: this.uid("usr"), username: "driver3", password: "driver123", role: "driver", fullName: "Paolo Santos", email: "paolo@para.local", phone: "+63 917 555 0103", active: false, activated: false, mustChangePassword: false, createdAt: new Date().toISOString(), lastLoginAt: null };
    db.users.push(dUser, dUser2, dUser3);

    var v1 = { id: this.uid("veh"), code: "VH-001", name: "Bus 1", type: "Mini Bus", capacity: 42, plate: "ABC-1234", make: "Toyota", model: "Coaster", year: 2022, status: "available", gpsStatus: "active", driverId: null, lastService: "2026-08-14", notes: "Assigned to morning shift.", createdAt: new Date().toISOString() };
    var v2 = { id: this.uid("veh"), code: "VH-002", name: "Bus 2", type: "Mini Bus", capacity: 42, plate: "DEF-5678", make: "Toyota", model: "Coaster", year: 2021, status: "available", gpsStatus: "active", driverId: null, lastService: "2026-09-02", notes: "", createdAt: new Date().toISOString() };
    var v3 = { id: this.uid("veh"), code: "VH-003", name: "Van 1", type: "Van", capacity: 15, plate: "GHI-9012", make: "Ford", model: "Transit", year: 2020, status: "out_of_service", gpsStatus: "unavailable", driverId: null, lastService: "2026-06-11", notes: "Brake repair ongoing.", createdAt: new Date().toISOString() };
    db.vehicles = [v1, v2, v3];

    db.drivers = [
      { id: this.uid("drv"), userId: dUser.id, code: "DRV-001", fullName: "Ramon Dela Cruz", contact: "+63 917 555 0101", license: "LTO-88213", status: "active", activation: "activated", vehicleId: v1.id, registeredAt: new Date().toISOString() },
      { id: this.uid("drv"), userId: dUser2.id, code: "DRV-002", fullName: "Liza Mendoza", contact: "+63 917 555 0102", license: "LTO-90147", status: "active", activation: "activated", vehicleId: v2.id, registeredAt: new Date().toISOString() },
      { id: this.uid("drv"), userId: dUser3.id, code: "DRV-003", fullName: "Paolo Santos", contact: "+63 917 555 0103", license: "LTO-91522", status: "suspended", activation: "deactivated", vehicleId: null, registeredAt: new Date().toISOString() }
    ];
    v1.driverId = db.drivers[0].id;
    v2.driverId = db.drivers[1].id;

    var pUser = { id: this.uid("usr"), username: "passenger1", password: "passenger123", role: "passenger", fullName: "Ana Reyes", email: "ana@example.com", phone: "+63 915 444 2200", active: true, activated: true, mustChangePassword: false, createdAt: new Date().toISOString(), lastLoginAt: hoursAgo(5) };
    var pUser2 = { id: this.uid("usr"), username: "passenger2", password: "passenger123", role: "passenger", fullName: "Miguel Tan", email: "miguel@example.com", phone: "+63 915 444 3300", active: true, activated: true, mustChangePassword: false, createdAt: new Date().toISOString(), lastLoginAt: hoursAgo(50) };
    db.users.push(pUser, pUser2);

    db.passengers = [
      { id: this.uid("pas"), userId: pUser.id, fullName: "Ana Reyes", contact: "+63 915 444 2200", sms: true, prefs: { serviceInterruption: true, majorDelay: true, announcements: true, vehicleArrival: false }, createdAt: new Date().toISOString() },
      { id: this.uid("pas"), userId: pUser2.id, fullName: "Miguel Tan", contact: "+63 915 444 3300", sms: false, prefs: { serviceInterruption: true, majorDelay: false, announcements: true, vehicleArrival: true }, createdAt: new Date().toISOString() }
    ];

    var anns = [
      { id: this.uid("ann"), title: "New schedule from Monday", description: "First trip leaves Central Station at 05:30 and the last return trip departs West End at 20:30.", priority: "normal", startAt: hoursAgo(72), endAt: null, status: "published", createdBy: "System", createdAt: hoursAgo(72) },
      { id: this.uid("ann"), title: "School Junction stop relocated", description: "For two weeks the School Junction stop moves 80 metres to the gate while the shelter is repaired.", priority: "high", startAt: hoursAgo(26), endAt: hoursAgo(-240), status: "published", createdBy: "System", createdAt: hoursAgo(26) }
    ];
    db.announcements = anns;

    var tripSpecs = [
      { d: 0, h: 6, driver: db.drivers[0], veh: v1, pax: 38, dur: 58, delay: 0 },
      { d: 0, h: 8, driver: db.drivers[1], veh: v2, pax: 31, dur: 61, delay: 0 },
      { d: 0, h: 10, driver: db.drivers[0], veh: v1, pax: 22, dur: 55, delay: 0 },
      { d: 0, h: 15, driver: db.drivers[0], veh: v1, pax: 40, dur: 72, delay: 14 },
      { d: 0, h: 18, driver: db.drivers[1], veh: v2, pax: 27, dur: 57, delay: 0 },
      { d: 1, h: 6, driver: db.drivers[0], veh: v1, pax: 36, dur: 59, delay: 0 },
      { d: 1, h: 7, driver: db.drivers[1], veh: v2, pax: 33, dur: 64, delay: 9 },
      { d: 1, h: 16, driver: db.drivers[0], veh: v1, pax: 42, dur: 75, delay: 18 },
      { d: 2, h: 6, driver: db.drivers[0], veh: v1, pax: 34, dur: 56, delay: 0 },
      { d: 2, h: 13, driver: db.drivers[1], veh: v2, pax: 19, dur: 54, delay: 0 },
      { d: 3, h: 6, driver: db.drivers[0], veh: v1, pax: 39, dur: 60, delay: 0 },
      { d: 3, h: 17, driver: db.drivers[0], veh: v1, pax: 41, dur: 78, delay: 21 }
    ];
    db.trips = tripSpecs.map(function (t) {
      var start = new Date(); start.setDate(start.getDate() - t.d); start.setHours(t.h, 5, 0, 0);
      var end = new Date(start.getTime() + t.dur * 60000);
      return {
        id: this.uid("trp"), code: "TRP-" + Math.random().toString(36).slice(2, 7).toUpperCase(),
        driverId: t.driver.id, vehicleId: t.veh.id, routeId: route.id,
        startAt: start.toISOString(), endAt: end.toISOString(), durationMin: t.dur,
        startLoc: stops[0].name, endLoc: stops[stops.length - 1].name,
        passengers: t.pax, capacityAtTime: t.veh.capacity,
        status: "completed", gpsStatus: "stopped", delayMin: t.delay,
        delayReason: t.delay ? "traffic" : "", notes: "", dataQuality: "ok"
      };
    }, this);

    var reqSpecs = [
      { u: 0, d: 0, h: 6, o: 0, de: 2, s: "must_arrive_by", st: "served" },
      { u: 1, d: 0, h: 7, o: 1, de: 4, s: "prefer_to_arrive_by", st: "served" },
      { u: 0, d: 0, h: 8, o: 3, de: 7, s: "must_arrive_by", st: "served" },
      { u: 1, d: 0, h: 12, o: 2, de: 5, s: "flexible", st: "cancelled" },
      { u: 0, d: 0, h: 15, o: 0, de: 3, s: "must_arrive_by", st: "served" },
      { u: 1, d: 1, h: 6, o: 4, de: 7, s: "must_arrive_by", st: "served" },
      { u: 0, d: 1, h: 7, o: 0, de: 5, s: "prefer_to_arrive_by", st: "missed_vehicle" },
      { u: 1, d: 1, h: 16, o: 2, de: 6, s: "must_arrive_by", st: "capacity_unavailable" },
      { u: 0, d: 2, h: 6, o: 1, de: 3, s: "must_arrive_by", st: "served" },
      { u: 1, d: 2, h: 9, o: 5, de: 7, s: "flexible", st: "used_other" },
      { u: 0, d: 3, h: 6, o: 0, de: 4, s: "must_arrive_by", st: "served" },
      { u: 1, d: 3, h: 17, o: 3, de: 7, s: "must_arrive_by", st: "service_unavailable" }
    ];
    db.requests = reqSpecs.map(function (r) {
      var when = new Date(); when.setDate(when.getDate() - r.d); when.setHours(r.h, 0, 0, 0);
      return {
        id: this.uid("req"), code: "REQ-" + Math.random().toString(36).slice(2, 7).toUpperCase(),
        passengerId: db.passengers[r.u].id, date: new Date(when).toISOString().slice(0, 10),
        desiredTime: when.toISOString(), sensitivity: r.s, originId: stops[r.o].id, destId: stops[r.de].id,
        tripId: null, status: r.st, note: "", createdAt: new Date(when.getTime() - 3600000).toISOString(),
        resolvedAt: r.st === "served" ? new Date(when.getTime() + 2400000).toISOString() : null
      };
    }, this);

    var waitSeed = [
      { o: 0, w: 9 }, { o: 0, w: 14 }, { o: 0, w: 7 }, { o: 1, w: 11 },
      { o: 1, w: 18 }, { o: 1, w: 8 }, { o: 2, w: 21 }, { o: 2, w: 16 },
      { o: 3, w: 6 }, { o: 4, w: 25 }, { o: 4, w: 12 }, { o: 5, w: 5 },
      { o: 6, w: 9 }, { o: 7, w: 13 }
    ];
    db.waitingTimes = waitSeed.map(function (w, i) {
      var at = new Date(); at.setDate(at.getDate() - (i % 4)); at.setHours(6 + (i % 12), 20, 0, 0);
      return { id: this.uid("wut"), stopId: stops[w.o].id, requestedAt: new Date(at.getTime() - w.w * 60000).toISOString(), expectedAt: at.toISOString(), arrivedAt: new Date(at.getTime() + 2 * 60000).toISOString(), waitMin: w.w };
    }, this);

    var travelSeed = [
      { f: 0, t: 1, m: 6 }, { f: 1, t: 2, m: 7 }, { f: 2, t: 3, m: 8 },
      { f: 3, t: 4, m: 6 }, { f: 4, t: 5, m: 7 }, { f: 5, t: 6, m: 6 },
      { f: 6, t: 7, m: 8 }, { f: 0, t: 1, m: 9 }, { f: 1, t: 2, m: 11 },
      { f: 2, t: 3, m: 8 }, { f: 3, t: 4, m: 6 }, { f: 4, t: 5, m: 7 }
    ];
    db.travelTimes = travelSeed.map(function (t, i) {
      var at = new Date(); at.setDate(at.getDate() - (i % 4)); at.setHours(6 + i, 10, 0, 0);
      return { id: this.uid("tvt"), fromStopId: stops[t.f].id, toStopId: stops[t.t].id, startedAt: at.toISOString(), endedAt: new Date(at.getTime() + t.m * 60000).toISOString(), minutes: t.m, tripId: null };
    }, this);

    db.delays = tripSpecs.filter(function (t) { return t.delay; }).map(function (t, i) {
      return { id: this.uid("dly"), tripId: null, vehicleId: t.veh.id, driverId: t.driver.id, normalMin: t.dur - t.delay, actualMin: t.dur, delayMin: t.delay, reason: "traffic", detectedAt: hoursAgo(24 - i * 4), resolvedAt: hoursAgo(23 - i * 4), status: "resolved", stopId: stops[Math.min(3, i + 1)].id };
    }, this);

    db.reports = [
      { id: this.uid("rpt"), code: "RPT-4821", reporterType: "passenger", reporterId: db.passengers[0].id, type: "excessive_waiting", location: "School Junction", at: hoursAgo(30), description: "Waited more than 25 minutes at the school stop in the afternoon.", status: "investigating" },
      { id: this.uid("rpt"), code: "RPT-4822", reporterType: "driver", reporterId: db.drivers[0].id, type: "heavy_traffic", location: "Hospital Corner", at: hoursAgo(28), description: "Queue at the hospital gate blocked the lane for several minutes.", status: "open" },
      { id: this.uid("rpt"), code: "RPT-4823", reporterType: "passenger", reporterId: db.passengers[1].id, type: "vehicle_was_full", location: "Central Station", at: hoursAgo(50), description: "Bus left without taking everyone waiting at the terminal.", status: "resolved" },
      { id: this.uid("rpt"), code: "RPT-4824", reporterType: "driver", reporterId: db.drivers[1].id, type: "road_obstruction", location: "Park Avenue", at: hoursAgo(52), description: "Roadworks narrowing the lane near the park.", status: "closed" }
    ];

    db.incidents = [
      { id: this.uid("inc"), code: "INC-2201", reporterId: db.drivers[0].id, reporterType: "driver", at: hoursAgo(28), location: "Hospital Corner", category: "road_obstruction", description: "Hospital gate queue blocking the route.", status: "confirmed", resolution: "Coordinate with hospital security; cones placed.", vehicleId: v1.id, tripId: null },
      { id: this.uid("inc"), code: "INC-2202", reporterId: db.passengers[0].id, reporterType: "passenger", at: hoursAgo(30), location: "School Junction", category: "excessive_wait", description: "Repeated long waits at the school stop.", status: "under_review", resolution: "", vehicleId: null, tripId: null }
    ];

    db.notifications = [
      { id: this.uid("ntf"), to: pUser.id, toType: "user", type: "delay", title: "Afternoon trip running about 20 minutes late", body: "Traffic near Hospital Corner. Leaving Central Station about 15:40 instead of 15:20.", priority: "high", read: false, at: hoursAgo(4) },
      { id: this.uid("ntf"), to: pUser.id, toType: "user", type: "announcement", title: "School Junction stop relocated", body: "For two weeks the stop moves 80 metres to the school gate.", priority: "normal", read: true, at: hoursAgo(26) }
    ];

    db.activity = [
      { id: this.uid("act"), action: "register_driver", entity: "driver", entityId: db.drivers[0].id, by: adminUser.id, byName: adminUser.fullName, role: "admin", at: new Date(Date.now() - 86400000 * 30).toISOString(), detail: "Registered DRV-001 Ramon Dela Cruz" },
      { id: this.uid("act"), action: "add_vehicle", entity: "vehicle", entityId: v1.id, by: adminUser.id, byName: adminUser.fullName, role: "admin", at: new Date(Date.now() - 86400000 * 30).toISOString(), detail: "Added VH-001 Bus 1" },
      { id: this.uid("act"), action: "update_service_status", entity: "service", entityId: null, by: adminUser.id, byName: adminUser.fullName, role: "admin", at: hoursAgo(6), detail: "Service status set to Operating Normally" }
    ];

    return db;
  }
};

PARA.auth = {
  session: null,

  load: function () {
    var raw = null;
    try { raw = sessionStorage.getItem(PARA.KEY_SESSION); } catch (e) { }
    if (!raw) return null;
    try {
      var s = JSON.parse(raw);
      if (!s || !s.userId || !s.expiresAt || s.expiresAt < Date.now()) { this.clear(); return null; }
      return s;
    } catch (e) { this.clear(); return null; }
  },

  save: function (user) {
    this.session = { userId: user.id, role: user.role, at: new Date().toISOString(), expiresAt: Date.now() + PARA.SESSION_HOURS * 3600000 };
    try { sessionStorage.setItem(PARA.KEY_SESSION, JSON.stringify(this.session)); } catch (e) { }
  },

  clear: function () {
    this.session = null;
    try { sessionStorage.removeItem(PARA.KEY_SESSION); } catch (e) { }
  },

  login: function (username, password) {
    var u = PARa_findUser(username);
    if (!u) return { ok: false, error: "No account found with that username." };
    if (u.password !== password) return { ok: false, error: "Incorrect password." };
    if (!u.active) return { ok: false, error: "This account is deactivated. Contact the administrator." };
    if (!u.activated) return { ok: false, error: "This account has not been activated yet." };
    u.lastLoginAt = new Date().toISOString();
    PARa_record("login", "user", u.id, "Signed in");
    PARA.store.save();
    this.save(u);
    return { ok: true, user: u };
  },

  current: function () {
    if (this.session) return this.session;
    this.session = this.load();
    return this.session;
  },

  user: function () {
    var s = this.current();
    if (!s) return null;
    return PARA.store.db.users.filter(function (u) { return u.id === s.userId; })[0] || null;
  },

  logout: function () {
    var u = this.user();
    if (u) { PARa_record("logout", "user", u.id, "Signed out"); PARA.store.save(); }
    this.clear();
  },

  requireRole: function (role) {
    var u = this.user();
    return !!u && u.role === role;
  }
};

function PARa_findUser(username) {
  var needle = String(username || "").trim().toLowerCase();
  return PARA.store.db.users.filter(function (u) { return u.username.toLowerCase() === needle; })[0] || null;
}

PARA.log = {
  record: function (action, entity, entityId, detail) {
    var u = PARA.auth.user();
    PARA.store.db.activity.unshift({
      id: PARA.store.uid("act"), action: action, entity: entity, entityId: entityId || null,
      by: u ? u.id : null, byName: u ? u.fullName : "Public visitor", role: u ? u.role : "public",
      at: new Date().toISOString(), detail: detail || ""
    });
    if (PARA.store.db.activity.length > 400) PARA.store.db.activity.length = 400;
  },
  notify: function (opts) {
    var db = PARA.store.db;
    db.notifications.unshift({
      id: PARA.store.uid("ntf"), to: opts.to, toType: opts.toType || "user",
      type: opts.type || "system", title: opts.title, body: opts.body || "",
      priority: opts.priority || "normal", read: false, at: new Date().toISOString()
    });
    if (db.notifications.length > 250) db.notifications.length = 250;
  },
  broadcast: function (opts) {
    var db = PARA.store.db;
    db.users.forEach(function (u) {
      if (u.role !== "passenger" || !u.active) return;
      var p = db.passengers.filter(function (x) { return x.userId === u.id; })[0];
      if (!p) return;
      var prefKey = PARA.CONST.notifyPrefKey[opts.type];
      if (prefKey && p.prefs && p.prefs[prefKey] === false) return;
      this.notify({ to: u.id, toType: "user", type: opts.type, title: opts.title, body: opts.body, priority: opts.priority });
    }, this);
  }
};

function PARa_record(action, entity, entityId, detail) {
  try { PARA.log.record(action, entity, entityId, detail); } catch (e) { }
}

PARA.ui = {
  toast: function (msg, kind) {
    var root = document.getElementById("toast-root");
    if (!root) return;
    var el = document.createElement("div");
    el.className = "toast" + (kind ? " " + kind : "");
    el.textContent = msg;
    root.appendChild(el);
    setTimeout(function () {
      el.style.transition = "opacity .3s";
      el.style.opacity = "0";
      setTimeout(function () { el.remove(); }, 320);
    }, 3200);
  },

  modal: function (opts) {
    var root = document.getElementById("modal-root");
    root.innerHTML = "";
    var bg = document.createElement("div");
    bg.className = "modal-bg";
    var close = function () { root.innerHTML = ""; };
    bg.innerHTML =
      "<div class='modal" + (opts.wide ? " wide" : "") + "'>" +
        "<div class='modal-head'><h3>" + PARA.esc(opts.title) + "</h3><button class='x' data-close>&times;</button></div>" +
        "<div class='modal-body'>" + opts.body + "</div>" +
        (opts.footer === false ? "" : "<div class='modal-foot'>" +
          "<button class='btn ghost' data-close>Cancel</button>" +
          "<button class='btn' data-ok>" + PARA.esc(opts.okText || "Save") + "</button></div>") +
      "</div>";
    root.appendChild(bg);
    bg.addEventListener("click", function (e) {
      if (e.target === bg || e.target.hasAttribute("data-close")) close();
    });
    var okBtn = bg.querySelector("[data-ok]");
    if (okBtn) {
      okBtn.addEventListener("click", function () {
        if (opts.onOk) {
          var res = opts.onOk(bg);
          if (res === false) return;
        }
        close();
      });
    }
    if (opts.onMount) opts.onMount(bg, close);
    var first = bg.querySelector("input,select,textarea");
    if (first) setTimeout(function () { first.focus(); }, 40);
    return close;
  },

  confirm: function (title, message, onYes, okText) {
    return this.modal({
      title: title,
      body: "<p style='font-size:14px'>" + PARA.esc(message) + "</p>",
      okText: okText || "Confirm",
      onOk: function () { onYes(); }
    });
  },

  field: function (label, inputHtml, hint) {
    return "<div class='field'><label class='lbl'>" + PARA.esc(label) + "</label>" + inputHtml +
      (hint ? "<div class='hint'>" + PARA.esc(hint) + "</div>" : "") + "</div>";
  },

  options: function (list, selected, labeller) {
    return list.map(function (v) {
      var label = labeller ? labeller(v) : PARA.titleize(v);
      return "<option value='" + PARA.esc(v) + "'" + (v === selected ? " selected" : "") + ">" + PARA.esc(label) + "</option>";
    }).join("");
  }
};

PARA.esc = function (s) {
  if (s == null) return "";
  return String(s).replace(/[&<>"']/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
  });
};

PARA.fmt = {
  time: function (iso) {
    if (!iso) return "—";
    var d = new Date(iso);
    return isNaN(d) ? "—" : d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  },
  date: function (iso) {
    if (!iso) return "—";
    var d = new Date(iso);
    return isNaN(d) ? "—" : d.toLocaleDateString([], { year: "numeric", month: "short", day: "numeric" });
  },
  dateTime: function (iso) {
    if (!iso) return "—";
    var d = new Date(iso);
    return isNaN(d) ? "—" : d.toLocaleDateString([], { month: "short", day: "numeric" }) + " · " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  },
  mins: function (m) {
    if (m == null) return "—";
    if (m < 60) return Math.round(m) + " min";
    var h = Math.floor(m / 60), r = Math.round(m % 60);
    return r ? h + "h " + r + "m" : h + "h";
  },
  ago: function (iso) {
    if (!iso) return "—";
    var diff = (Date.now() - new Date(iso).getTime()) / 1000;
    if (isNaN(diff)) return "—";
    if (diff < 60) return "just now";
    if (diff < 3600) return Math.floor(diff / 60) + " min ago";
    if (diff < 86400) return Math.floor(diff / 3600) + "h ago";
    return Math.floor(diff / 86400) + "d ago";
  },
  until: function (iso) {
    if (!iso) return "—";
    var diff = (new Date(iso).getTime() - Date.now()) / 1000;
    if (isNaN(diff)) return "—";
    if (diff <= 0) return "now";
    if (diff < 3600) return "in " + Math.floor(diff / 60) + " min";
    return "in " + Math.floor(diff / 3600) + "h";
  },
  dayLabel: function (iso) {
    if (!iso) return "—";
    return new Date(iso).toLocaleDateString([], { weekday: "short" });
  }
};

PARA.tagClass = function (value) {
  var g = String(value || "").toLowerCase();
  if (/(active|available|operating_normally|served|activated|resolved|completed|confirmed|ok|normal)/.test(g)) return "t-green";
  if (/(delayed|pending|under_review|investigating|open|assigned|temporarily|limited|delay|high)/.test(g)) return "t-amber";
  if (/(suspended|emergency|out_of_service|deactivated|missed|unavailable|cancelled|dismissed|critical|over)/.test(g)) return "t-red";
  if (/(blue|info|system|used_other|unknown)/.test(g)) return "t-blue";
  return "t-grey";
};

PARA.tag = function (value, label) {
  return "<span class='tag " + PARA.tagClass(value) + "'>" + PARA.esc(label || PARA.enumLabel(value, value)) + "</span>";
};
