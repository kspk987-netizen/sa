window.PARA = window.PARA || {};
PARA.views = PARA.views || {};

(function (V) {
  "use strict";

  function myDriver() {
    var u = PARA.auth.user();
    if (!u) return null;
    return PARA.store.db.drivers.filter(function (d) { return d.userId === u.id; })[0] || null;
  }

  function tripPanel(db, d) {
    var trip = PARA.geo.activeTrips().filter(function (t) { return t.driverId === d.id; })[0];
    var v = db.vehicles.filter(function (x) { return x.id === d.vehicleId; })[0];
    var route = PARA.geo.activeRoute();
    var stops = PARA.geo.stops(route && route.id);

    if (!trip) {
      return "<div class='card'><div class='card-head'><h3>Start a trip</h3>" +
        (v ? PARA.tag(v.status, PARA.CONST.vehicleLabel[v.status]) : "<span class='tag t-amber'>no vehicle</span>") + "</div>" +
        (v
          ? "<p style='font-size:14px;margin-bottom:14px'>You are assigned <strong>" + PARA.esc(v.name) + "</strong> (" + PARA.esc(v.code) + ", " + v.capacity + " seats). Starting a trip begins GPS tracking and publishes your position to passengers.</p>" +
            "<button class='btn' id='start-trip'>Start trip on " + PARA.esc(route ? route.name : "active route") + "</button>"
          : "<div class='alert warn'>No vehicle is assigned to you. Ask an administrator to assign one before starting a trip.</div>") +
        "</div>";
    }

    var coord = PARA.geo.tripCoord(trip);
    var near = coord ? PARA.geo.nearestStop(trip.routeId, coord) : null;
    var mins = (Date.now() - new Date(trip.startAt).getTime()) / 60000;
    var nextStop = stops.filter(function (s) { return s.position >= (near ? near.stop.position : 1); })[0];

    return "<div class='card'><div class='card-head'><h3>Current trip " + PARA.esc(trip.code) + "</h3>" + PARA.tag(trip.status, PARA.CONST.tripLabel[trip.status]) + "</div>" +
      "<div class='grid g4' style='margin-bottom:14px'>" +
        "<div class='kpi'><div class='v' style='font-size:22px'>" + PARA.esc(PARA.fmt.mins(mins)) + "</div><div class='l'>Elapsed</div></div>" +
        "<div class='kpi'><div class='v' style='font-size:22px'>" + (trip.passengers || 0) + "</div><div class='l'>Passengers</div></div>" +
        "<div class='kpi " + (trip.delayMin ? "warn" : "") + "'><div class='v' style='font-size:22px'>" + (trip.delayMin ? "+" + trip.delayMin : "0") + "</div><div class='l'>Delay (min)</div></div>" +
        "<div class='kpi'><div class='v' style='font-size:22px'>" + Math.round((trip.progress || 0) * 100) + "%</div><div class='l'>Route completed</div></div>" +
      "</div>" +
      "<div class='map-wrap' style='margin-bottom:14px'>" + PARA.geo.mapSvg({ routeId: trip.routeId }) + "</div>" +
      "<ul class='stop-list'>" +
        "<li><div class='stop-num'>" + (near ? near.stop.position : "—") + "</div><div><strong>" + (near ? "Passing " + PARA.esc(near.stop.name) : "Position unknown") + "</strong>" +
          "<div class='stop-meta'>" + (coord ? coord.lat.toFixed(4) + ", " + coord.lng.toFixed(4) : "") + (near ? " · about " + near.km.toFixed(2) + " km from the stop centre" : "") + "</div></div></li>" +
        (nextStop ? "<li><div class='stop-num'>" + nextStop.position + "</div><div><strong>Next stop: " + PARA.esc(nextStop.name) + "</strong>" +
          "<div class='stop-meta'>estimated " + PARA.esc(PARA.fmt.mins(PARA.geo.etaMinutes(trip, nextStop.id))) + " from now (" + PARA.esc(PARA.fmt.time(PARA.geo.etaClock(trip, nextStop.id))) + ")</div></div></li>" : "") +
        "<li><div class='stop-num'>G</div><div><strong>GPS: " + PARA.esc(v ? PARA.geo.gpsFreshness(v) : "unknown") + "</strong>" +
          "<div class='stop-meta'>" + PARA.esc(v ? PARA.geo.gpsNote(v) : "") + "</div></div></li>" +
      "</ul>" +
      "<div class='card-head' style='margin-top:18px'><h3>Update trip status</h3></div>" +
      "<div class='pill-row'>" + PARA.CONST.tripStatus.filter(function (s) { return s !== "completed"; }).map(function (s) {
        return "<button class='btn " + (trip.status === s ? "" : "ghost") + " sm' data-status='" + s + "'>" + PARA.esc(PARA.CONST.tripLabel[s]) + "</button>";
      }).join("") + "</div>" +
      "<div class='card-head' style='margin-top:18px'><h3>Record progress</h3></div>" +
      "<div class='row2' style='align-items:end'>" +
        PARA.ui.field("Mark arrival at a stop (records real travel time)", "<select class='in' id='arrive-stop'>" +
          stops.map(function (s) { return "<option value='" + s.id + "'>" + s.position + ". " + PARA.esc(s.name) + "</option>"; }).join("") + "</select>") +
        "<button class='btn ghost' id='mark-arrive'>Record arrival</button>" +
      "</div>" +
      "<div class='card-head' style='margin-top:18px'><h3>Finish trip</h3></div>" +
      "<div id='end-err'></div>" +
      "<div class='row3'>" +
        PARA.ui.field("Passengers carried", "<input class='in' type='number' min='0' id='end-pax' value='" + (trip.passengers || 0) + "'>") +
        PARA.ui.field("Ending location", "<input class='in' id='end-loc' value='" + PARA.esc(trip.endLoc || "") + "' placeholder='stop name or area'>") +
        PARA.ui.field("Delay reason (if delayed)", "<select class='in' id='end-reason'>" + PARA.ui.options(PARA.CONST.delayReason, trip.delayReason || "", function (r) { return PARA.CONST.delayLabel[r]; }) + "</select>") +
      "</div>" +
      PARA.ui.field("Notes for the record", "<input class='in' id='end-notes' placeholder='optional'>") +
      "<button class='btn danger' id='end-trip'>End trip</button>" +
    "</div>";
  }

  V.driver = function (root) {
    if (!PARA.auth.requireRole("driver")) { location.hash = "#/"; return; }
    var db = PARA.store.db;
    var u = PARA.auth.user();
    var d = myDriver();
    if (!d) {
      root.innerHTML = "<h1 class='title'>Driver</h1><div class='card'><div class='alert warn'>No driver profile is linked to this account. Ask an administrator to register it.</div></div>";
      return;
    }
    var v = db.vehicles.filter(function (x) { return x.id === d.vehicleId; })[0];
    var route = PARA.geo.activeRoute();
    var stops = PARA.geo.stops(route && route.id);
    var history = db.trips.filter(function (t) { return t.driverId === d.id; }).sort(function (a, b) { return new Date(b.startAt) - new Date(a.startAt); });
    var mine = history.filter(function (t) { return t.status === "completed"; });
    var notices = db.announcements.filter(function (a) { return a.status === "published"; }).slice(0, 3);

    root.innerHTML =
      "<h1 class='title'>Driver dashboard</h1>" +
      "<div class='sub'>" + PARA.esc(d.fullName) + " · " + PARA.esc(d.code) + " · " + PARA.esc(PARA.titleize(d.status)) + "</div>" +
      (u.mustChangePassword ? "<div class='alert warn'>You are using a temporary password. <a href='#/account'>Change it now</a> so your account stays secure.</div>" : "") +
      "<div class='grid g4' style='margin-bottom:18px'>" +
        "<div class='kpi'><div class='v' style='font-size:22px'>" + PARA.esc(v ? v.name : "—") + "</div><div class='l'>" + (v ? PARA.esc(v.code) + " · " + v.capacity + " seats" : "no vehicle assigned") + "</div></div>" +
        "<div class='kpi'><div class='v' style='font-size:22px'>" + PARA.esc(route ? route.name : "—") + "</div><div class='l'>assigned route</div></div>" +
        "<div class='kpi'><div class='v' style='font-size:22px'>" + mine.length + "</div><div class='l'>completed trips</div></div>" +
        "<div class='kpi'><div class='v' style='font-size:22px'>" + mine.reduce(function (a, t) { return a + (t.passengers || 0); }, 0) + "</div><div class='l'>passengers carried</div></div>" +
      "</div>" +
      tripPanel(db, d) +
      "<div class='grid g2'>" +
        "<div class='card'><div class='card-head'><h3>Route stops</h3><span class='card-note'>" + stops.length + " stops</span></div>" +
          "<ul class='stop-list'>" + stops.map(function (s) {
            return "<li><div class='stop-num'>" + s.position + "</div><div><strong>" + PARA.esc(s.name) + "</strong>" +
              "<div class='stop-meta'>" + PARA.esc(s.location || "") + " · " + (s.eta ? "vehicle due " + PARA.esc(PARA.fmt.time(s.eta)) : "no ETA right now") + "</div></div></li>";
          }).join("") + "</ul></div>" +
        "<div class='card'><div class='card-head'><h3>Notices for drivers</h3></div>" +
          (notices.length ? notices.map(function (a) {
            return "<div class='notif'><div class='ic'>📢</div><div><div class='t'>" + PARA.esc(a.title) + "</div>" +
              "<div class='m'>" + PARA.esc(a.description) + "</div></div></div>";
          }).join("") : "<div class='empty'>No current notices.</div>") +
          "<div class='pill-row' style='margin-top:14px'>" +
            "<a class='btn ghost sm' href='#/driver/trips'>Trip history</a>" +
            "<a class='btn ghost sm' href='#/driver/reports'>Report a problem</a>" +
          "</div>" +
        "</div>" +
      "</div>";

    var startBtn = root.querySelector("#start-trip");
    if (startBtn) {
      startBtn.addEventListener("click", function () {
        var veh = db.vehicles.filter(function (x) { return x.id === d.vehicleId; })[0];
        if (!veh) return;
        var r = PARA.geo.activeRoute();
        var first = PARA.geo.stops(r.id)[0];
        veh.status = "on_trip";
        var trip = {
          id: PARA.store.uid("trp"), code: "TRP-" + Math.random().toString(36).slice(2, 7).toUpperCase(),
          driverId: d.id, vehicleId: veh.id, routeId: r.id, startAt: new Date().toISOString(),
          endAt: null, durationMin: null, startLoc: first ? first.name : r.startPoint, endLoc: "",
          passengers: 0, capacityAtTime: veh.capacity, status: "active", gpsStatus: "active",
          delayMin: 0, delayReason: "", notes: "", dataQuality: "ok",
          progress: 0, simFactor: 1, lastStopId: null, lastStopAt: null
        };
        db.trips.push(trip);
        veh.lastGpsAt = new Date().toISOString();
        PARa_record("start_trip", "trip", trip.id, "Started " + trip.code + " on " + veh.name);
        PARA.store.save();
        PARA.ui.toast("Trip started — GPS sharing is live", "good");
        PARA.render();
      });
    }

    root.querySelectorAll("[data-status]").forEach(function (b) {
      b.addEventListener("click", function () {
        var s = b.getAttribute("data-status");
        var trip = PARA.geo.activeTrips().filter(function (t) { return t.driverId === d.id; })[0];
        if (!trip) return;

        var apply = function (extra) {
          trip.status = s;
          if (extra) trip.statusDetail = extra;
          if (s === "delayed" && !trip.delayReason) trip.delayReason = "unknown";
          if (s === "active") { trip.delayMin = 0; trip.delayReason = ""; }
          var veh = db.vehicles.filter(function (x) { return x.id === trip.vehicleId; })[0];
          if (veh) {
            veh.status = s === "delayed" ? "delayed" : s === "emergency" ? "emergency"
              : s === "temporarily_stopped" ? "temporarily_stopped" : s === "road_problem" || s === "vehicle_problem" ? "temporarily_stopped" : "on_trip";
          }
          PARa_record("update_trip_status", "trip", trip.id, trip.code + " → " + PARA.CONST.tripLabel[s]);
          if (s === "delayed" || s === "emergency" || s === "road_problem") {
            PARA.log.broadcast({
              type: s === "emergency" ? "service_interruption" : "delay",
              title: s === "delayed" ? "Some trips are running late" : s === "emergency" ? "Emergency on the route" : "Route obstruction reported",
              body: "A driver reported: " + PARA.CONST.tripLabel[s] + (extra ? " — " + extra : "") + ". Check the live map for the closest vehicle.",
              priority: s === "emergency" ? "critical" : "high"
            });
          }
          PARA.store.save();
          PARA.ui.toast("Status updated to " + PARA.CONST.tripLabel[s], "good");
          PARA.render();
        };

        if (s === "vehicle_problem" || s === "road_problem" || s === "temporarily_stopped") {
          PARA.ui.modal({
            title: PARA.CONST.tripLabel[s],
            body:
              PARA.ui.field("What is happening?", "<select class='in' id='d-cat'>" +
                (s === "vehicle_problem"
                  ? ["Engine or transmission", "Brakes or tyres", "Door or interior", "Fuel or other", "Other"]
                  : ["Heavy traffic", "Road works", "Accident", "Flooding", "Road closure", "Passenger dispute", "Other"]
                ).map(function (o) { return "<option>" + PARA.esc(o) + "</option>"; }).join("") + "</select>") +
              PARA.ui.field("Description", "<textarea class='in' id='d-desc' placeholder='Briefly describe what is happening'></textarea>") +
              "<div class='row2'>" +
                PARA.ui.field("Delay added (minutes)", "<input class='in' type='number' id='d-delay' value='0' min='0'>") +
                PARA.ui.field("Time now", "<input class='in' type='datetime-local' id='d-time' value='" + new Date().toISOString().slice(0, 16) + "'>") +
              "</div>" +
              "<div class='alert info'>This is recorded as a user report from the driver. It alerts passengers and appears in the incident review list.</div>",
            okText: "Save status",
            onOk: function (box) {
              var cat = box.querySelector("#d-cat").value;
              var extra = cat + (box.querySelector("#d-desc").value ? " — " + box.querySelector("#d-desc").value : "");
              var added = Number(box.querySelector("#d-delay").value) || 0;
              trip.delayMin = (trip.delayMin || 0) + added;
              trip.delayReason = s === "vehicle_problem" ? "vehicle_problem" : s === "road_problem" ? "road_obstruction" : (trip.delayReason || "passenger_loading");
              trip.statusDetail = extra;
              db.reports.unshift({
                id: PARA.store.uid("rpt"), code: "RPT-" + Math.random().toString(36).slice(2, 7).toUpperCase(),
                reporterType: "driver", reporterId: u.id, type: s === "vehicle_problem" ? "vehicle_problem" : s === "road_problem" ? "road_obstruction" : "other",
                location: (PARA.geo.nearestStop(trip.routeId, PARA.geo.tripCoord(trip)) || {}).stop?.name || "",
                at: new Date().toISOString(), description: extra, status: "open", tripId: trip.id
              });
              apply(extra);
            }
          });
        } else {
          apply(null);
        }
      });
    });

    var markBtn = root.querySelector("#mark-arrive");
    if (markBtn) {
      markBtn.addEventListener("click", function () {
        var trip = PARA.geo.activeTrips().filter(function (t) { return t.driverId === d.id; })[0];
        if (!trip) return;
        var stopId = root.querySelector("#arrive-stop").value;
        var stop = db.stops.filter(function (s) { return s.id === stopId; })[0];
        var now = new Date().toISOString();
        var fromId = trip.lastStopId || PARA.geo.stops(trip.routeId)[0].id;
        var fromStop = db.stops.filter(function (s) { return s.id === fromId; })[0];
        if (fromId === stopId) { PARA.ui.toast("That is already the last recorded stop"); return; }
        var startedAt = trip.lastStopAt || trip.startAt;
        var minutes = Math.max(1, Math.round((new Date(now) - new Date(startedAt)) / 60000));
        db.travelTimes.push({
          id: PARA.store.uid("tvt"), fromStopId: fromId, toStopId: stopId,
          startedAt: startedAt, endedAt: now, minutes: minutes, tripId: trip.id
        });
        trip.lastStopId = stopId;
        trip.lastStopAt = now;
        trip.progress = Math.max(trip.progress || 0, PARA.geo.stopFraction(stopId));
        PARa_record("record_stop_arrival", "trip", trip.id, stop.name + " after " + minutes + " min");
        PARA.store.save();
        PARA.ui.toast("Recorded " + minutes + " min to " + stop.name + " — this feeds the travel-time analysis", "good");
        PARA.render();
      });
    }

    var endBtn = root.querySelector("#end-trip");
    if (endBtn) {
      endBtn.addEventListener("click", function () {
        var trip = PARA.geo.activeTrips().filter(function (t) { return t.driverId === d.id; })[0];
        if (!trip) return;
        var paxRaw = root.querySelector("#end-pax").value;
        if (paxRaw === "" || Number(paxRaw) < 0) {
          root.querySelector("#end-err").innerHTML = "<div class='alert err'>Enter the number of passengers carried (use 0 if none).</div>";
          return;
        }
        var pax = Number(paxRaw);
        var veh = db.vehicles.filter(function (x) { return x.id === trip.vehicleId; })[0];
        if (veh && pax > veh.capacity) {
          root.querySelector("#end-err").innerHTML = "<div class='alert err'>" + pax + " passengers exceeds the " + veh.capacity + "-seat capacity recorded for this vehicle. Correct the number before ending the trip.</div>";
          return;
        }
        var end = new Date().toISOString();
        trip.endAt = end;
        trip.durationMin = Math.max(1, Math.round((new Date(end) - new Date(trip.startAt)) / 60000));
        trip.passengers = pax;
        trip.endLoc = root.querySelector("#end-loc").value || trip.startLoc;
        trip.delayReason = root.querySelector("#end-reason").value || trip.delayReason;
        trip.notes = root.querySelector("#end-notes").value || "";
        trip.status = "completed";
        trip.gpsStatus = "stopped";
        trip.progress = 1;
        if (veh) veh.status = "available";

        var fromId = trip.lastStopId || PARA.geo.stops(trip.routeId)[0].id;
        var lastStop = db.stops.slice().sort(function (a, b) { return a.position - b.position; }).pop();
        if (lastStop && fromId !== lastStop.id) {
          db.travelTimes.push({
            id: PARA.store.uid("tvt"), fromStopId: fromId, toStopId: lastStop.id,
            startedAt: trip.lastStopAt || trip.startAt, endedAt: end, minutes: Math.max(1, Math.round((new Date(end) - new Date(trip.lastStopAt || trip.startAt)) / 60000)), tripId: trip.id
          });
        }
        if (trip.delayMin > 0) {
          db.delays.unshift({
            id: PARA.store.uid("dly"), tripId: trip.id, vehicleId: trip.vehicleId, driverId: trip.driverId,
            normalMin: Math.max(1, trip.durationMin - trip.delayMin), actualMin: trip.durationMin, delayMin: trip.delayMin,
            reason: trip.delayReason || "unknown", detectedAt: trip.startAt, resolvedAt: end, status: "resolved", stopId: fromId
          });
        }
        PARa_record("end_trip", "trip", trip.id, "Ended " + trip.code + " · " + pax + " passengers · " + trip.durationMin + " min");
        PARA.store.save();
        PARA.ui.toast("Trip recorded. Thank you — the data is now part of the transport history.", "good");
        PARA.render();
      });
    }
  };

  V["driver-trips"] = function (root) {
    if (!PARA.auth.requireRole("driver")) { location.hash = "#/"; return; }
    var db = PARA.store.db;
    var d = myDriver();
    if (!d) { root.innerHTML = "<div class='card'><div class='empty'>No driver profile linked.</div></div>"; return; }
    var trips = db.trips.filter(function (t) { return t.driverId === d.id; }).sort(function (a, b) { return new Date(b.startAt) - new Date(a.startAt); });
    var done = trips.filter(function (t) { return t.status === "completed"; });

    root.innerHTML =
      "<h1 class='title'>Trip history</h1>" +
      "<div class='sub'>Your completed trips are kept as the transport record for this route.</div>" +
      "<div class='grid g4' style='margin-bottom:18px'>" +
        "<div class='kpi'><div class='v'>" + done.length + "</div><div class='l'>Trips completed</div></div>" +
        "<div class='kpi'><div class='v'>" + done.reduce(function (a, t) { return a + (t.passengers || 0); }, 0) + "</div><div class='l'>Passengers carried</div></div>" +
        "<div class='kpi'><div class='v'>" + PARA.esc(PARA.fmt.mins(PARA.analytics.avg(done.map(function (t) { return t.durationMin; })))) + "</div><div class='l'>Average trip</div></div>" +
        "<div class='kpi'><div class='v'>" + done.filter(function (t) { return (t.delayMin || 0) > 0; }).length + "</div><div class='l'>Trips with delay</div></div>" +
      "</div>" +
      "<div class='card pad-0'><div class='table-wrap'><table class='t'>" +
        "<thead><tr><th>Trip</th><th>Started</th><th>Ended</th><th class='num'>Duration</th><th class='num'>Passengers</th>" +
        "<th class='num'>Load</th><th class='num'>Delay</th><th>Status</th></tr></thead><tbody>" +
        (trips.length ? trips.map(function (t) {
          var load = t.capacityAtTime ? Math.round(((t.passengers || 0) / t.capacityAtTime) * 100) : null;
          return "<tr><td><strong>" + PARA.esc(t.code) + "</strong></td>" +
            "<td>" + PARA.esc(PARA.fmt.dateTime(t.startAt)) + "</td>" +
            "<td>" + (t.endAt ? PARA.esc(PARA.fmt.dateTime(t.endAt)) : "<span class='tag t-amber'>running</span>") + "</td>" +
            "<td class='num'>" + PARA.esc(PARA.fmt.mins(t.durationMin)) + "</td>" +
            "<td class='num'>" + (t.passengers || 0) + "</td>" +
            "<td class='num'>" + (load != null ? load + "%" : "—") + "</td>" +
            "<td class='num'>" + (t.delayMin ? "+" + t.delayMin + "m" : "—") + "</td>" +
            "<td>" + PARA.tag(t.status, PARA.CONST.tripLabel[t.status]) + "</td></tr>";
        }).join("") : "<tr><td colspan='8'><div class='empty'>No trips yet. Start one from your dashboard.</div></td></tr>") +
      "</tbody></table></div></div>";
  };

  V["driver-reports"] = function (root) {
    if (!PARA.auth.requireRole("driver")) { location.hash = "#/"; return; }
    var db = PARA.store.db;
    var u = PARA.auth.user();
    var mine = db.reports.filter(function (x) { return x.reporterId === u.id; }).sort(function (a, b) { return new Date(b.at) - new Date(a.at); });
    var trip = PARA.geo.activeTrips()[0];

    root.innerHTML =
      "<h1 class='title'>Report a problem</h1>" +
      "<div class='sub'>Reports give the administrator context that explains delays and incidents in the data.</div>" +
      "<div class='grid g2'>" +
        "<div class='card'><div class='card-head'><h3>New operational report</h3></div>" +
          "<form id='rep-form'>" +
            PARA.ui.field("What are you reporting?", "<select class='in' name='type'>" +
              PARA.ui.options(PARA.CONST.driverReportType, "heavy_traffic") + "</select>") +
            PARA.ui.field("Where is it?", "<input class='in' name='location' placeholder='e.g. Hospital Corner' required>") +
            PARA.ui.field("Describe what is happening", "<textarea class='in' name='description' placeholder='This becomes part of the official record, so please be specific.'></textarea>") +
            "<div class='alert info'>Submitting a report alerts the administrator. Passengers are notified for emergencies and service interruptions.</div>" +
            "<button class='btn' type='submit'>Submit report</button>" +
          "</form>" +
        "</div>" +
        "<div class='card'><div class='card-head'><h3>My reports</h3><span class='card-note'>" + mine.length + " submitted</span></div>" +
          (mine.length ? mine.map(function (x) {
            return "<div class='notif'><div class='ic'>" + (x.status === "resolved" || x.status === "closed" ? "✅" : "⏳") + "</div><div style='flex:1'>" +
              "<div class='t'>" + PARA.esc(PARA.titleize(x.type)) + " — " + PARA.esc(x.code) + "</div>" +
              "<div class='m'>" + PARA.esc(x.description || "") + "</div>" +
              "<div class='m' style='margin-top:4px'>" + PARA.esc(x.location || "location not given") + " · " + PARA.esc(PARA.fmt.ago(x.at)) + "</div></div>" +
              PARA.tag(x.status, PARA.titleize(x.status)) + "</div>";
          }).join("") : "<div class='empty'>You have not submitted any reports.</div>") +
        "</div>" +
      "</div>";

    root.querySelector("#rep-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var f = new FormData(e.target);
      var type = f.get("type");
      db.reports.unshift({
        id: PARA.store.uid("rpt"), code: "RPT-" + Math.random().toString(36).slice(2, 7).toUpperCase(),
        reporterType: "driver", reporterId: u.id, type: type, location: f.get("location"),
        at: new Date().toISOString(), description: f.get("description") || "", status: "open",
        tripId: trip ? trip.id : null
      });
      if (type === "emergency" || type === "service_interruption") {
        PARA.log.broadcast({ type: "service_interruption", title: "Service issue reported by a driver", body: f.get("description") || PARA.titleize(type), priority: "critical" });
      } else if (type === "road_closure" || type === "flooding" || type === "accident") {
        PARA.log.broadcast({ type: "delay", title: "Possible delay ahead: " + PARA.titleize(type), body: f.get("description") || "A driver reported a condition affecting the route.", priority: "high" });
      }
      PARa_record("submit_driver_report", "report", null, PARA.titleize(type) + " at " + f.get("location"));
      PARA.store.save();
      PARA.ui.toast("Report submitted", "good");
      PARA.render();
    });
  };

})(PARA.views);
