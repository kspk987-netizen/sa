window.PARA = window.PARA || {};
PARA.views = PARA.views || {};

(function (V) {
  "use strict";

  function serviceHero() {
    var db = PARA.store.db;
    var st = db.serviceStatus;
    var dot = st === "operating_normally" || st === "resumed" ? "dot-green"
      : st === "delayed" || st === "limited_service" ? "dot-amber" : "dot-red";
    var fleet = PARA.analytics.fleet();
    var active = PARA.geo.activeTrips();
    return "<div class='status-hero'>" +
      "<span class='status-dot " + dot + "'></span>" +
      "<div style='flex:1;min-width:220px'>" +
        "<div class='lbl'>Service: " + PARA.esc(PARA.CONST.serviceLabel[st]) + "</div>" +
        "<div class='meta'>Updated " + PARA.esc(PARA.fmt.ago(db.serviceUpdatedAt)) +
          " · " + fleet.onTrip + " vehicle" + (fleet.onTrip === 1 ? "" : "s") + " running now" +
          " · " + fleet.seats + " seats in service" +
          (db.serviceNote ? " · " + PARA.esc(db.serviceNote) : "") +
        "</div>" +
      "</div>" +
      "<a class='btn ghost' href='#/route'>Route &amp; stops</a>" +
      "<a class='btn' href='#/planner'>Plan my trip</a>" +
    "</div>";
  }

  function liveMapCard() {
    var trips = PARA.geo.activeTrips();
    var route = PARA.geo.activeRoute();
    var head = "<div class='card-head'><h3>Live vehicle positions</h3>" +
      "<span class='card-note'>" + (route ? PARA.esc(route.name) + " · " : "") +
      (trips.length ? trips.length + " vehicle" + (trips.length === 1 ? "" : "s") + " reporting" : "no vehicles currently running") + "</span></div>";
    return "<div class='card'>" + head +
      "<div class='map-wrap'>" + PARA.geo.mapSvg({}) +
        "<div class='map-legend'>" +
          "<span class='lg'><i class='stop'></i>Stop</span>" +
          "<span class='lg'><i class='bus'></i>Vehicle on time</span>" +
          "<span class='lg'><i class='late'></i>Delayed</span>" +
          "<span style='margin-left:auto'>Positions are approximate and update every few seconds.</span>" +
        "</div>" +
      "</div></div>";
  }

  function announcementsCard(limit) {
    var list = PARA.store.db.announcements.filter(function (a) {
      return a.status === "published" && (!a.endAt || new Date(a.endAt) > new Date());
    }).slice(0, limit || 5);
    if (!list.length) return "";
    return "<div class='card'><div class='card-head'><h3>Announcements</h3>" +
      "<span class='card-note'>" + list.length + " active</span></div>" +
      list.map(function (a) {
        var ic = a.priority === "critical" ? "🚨" : a.priority === "high" ? "⚠️" : "📢";
        return "<div class='notif" + (a.priority === "high" || a.priority === "critical" ? " unread" : "") + "'>" +
          "<div class='ic'>" + ic + "</div><div style='flex:1'>" +
          "<div class='t'>" + PARA.esc(a.title) + "</div>" +
          "<div class='m'>" + PARA.esc(a.description) + "</div>" +
          "<div class='m' style='margin-top:4px'>" + PARA.esc(a.priority) + " · posted " + PARA.esc(PARA.fmt.ago(a.createdAt)) +
            (a.endAt ? " · until " + PARA.esc(PARA.fmt.dateTime(a.endAt)) : "") + "</div>" +
          "</div></div>";
      }).join("") + "</div>";
  }

  V.home = function (root) {
    var db = PARA.store.db;
    var route = PARA.geo.activeRoute();
    var stops = PARA.geo.stops(route && route.id);
    var peak = PARA.analytics.peak(PARA.analytics.range("week"));
    var nextStop = stops.filter(function (s) { return s.eta; })[0];

    root.innerHTML =
      "<div class='hero'>" +
        PARA.logo(96) +
        "<div style='flex:1;min-width:260px'>" +
          "<h1>PARA — " + PARA.esc(db.meta.full) + "</h1>" +
          "<p>Know whether the service is running, where the vehicle is, when it will reach your stop, and how early you should leave. " +
          "At the same time PARA records what actually happened, so the community can see when demand peaks, where waiting is longest, and which stops run into delays.</p>" +
          "<div class='hero-actions'>" +
            "<a class='btn white' href='#/planner'>Plan my trip</a>" +
            "<a class='btn outline' href='#/route'>Route &amp; stops</a>" +
            (PARA.auth.user() ? "" : "<a class='btn outline' href='#/login'>Sign in</a>") +
          "</div>" +
        "</div>" +
      "</div>" +
      serviceHero() +
      liveMapCard() +
      "<div class='grid g2'>" +
        "<div class='card'><div class='card-head'><h3>Today's picture</h3></div>" +
          "<ul class='stop-list'>" +
            "<li><div class='stop-num'>1</div><div><strong>" + (route ? PARA.esc(route.name) : "No route configured") + "</strong>" +
              "<div class='stop-meta'>" + (route ? PARA.esc(route.startPoint) + " → " + PARA.esc(route.endPoint) + " · " + stops.length + " stops" : "Ask the administrator to add a route") + "</div></div></li>" +
            "<li><div class='stop-num'>2</div><div><strong>Service hours</strong>" +
              "<div class='stop-meta'>" + (route ? PARA.esc(route.operatingHours.start) + " – " + PARA.esc(route.operatingHours.end) + " · " + PARA.esc(route.operatingHours.days.join(", ")) : "—") + "</div></div></li>" +
            "<li><div class='stop-num'>3</div><div><strong>Next vehicle at a stop</strong>" +
              "<div class='stop-meta'>" + (nextStop ? PARA.esc(nextStop.name) + " around " + PARA.esc(PARA.fmt.time(nextStop.eta)) + " (" + PARA.esc(PARA.fmt.until(nextStop.eta)) + ")" : "No vehicle currently en route") + "</div></div></li>" +
            "<li><div class='stop-num'>4</div><div><strong>Busiest hour this week</strong>" +
              "<div class='stop-meta'>" + (peak.busiest && peak.busiest.requests ? (peak.busiest.hour < 10 ? "0" : "") + peak.busiest.hour + ":00 with " + peak.busiest.requests + " recorded requests" : "Not enough recorded requests yet") + "</div></div></li>" +
          "</ul>" +
        "</div>" +
        announcementsCard(4) +
      "</div>" +
      "<div class='grid g3'>" +
        "<div class='card'><h3 style='margin-bottom:8px'>Before you travel</h3><p style='font-size:13.5px;color:#5f6b62'>Check the service status, see which vehicle is closest, and get a recommended time to reach your stop.</p></div>" +
        "<div class='card'><h3 style='margin-bottom:8px'>Ask for a ride</h3><p style='font-size:13.5px;color:#5f6b62'>Signed-in passengers can submit a request, say how strict the arrival time is, and follow the outcome.</p></div>" +
        "<div class='card'><h3 style='margin-bottom:8px'>Community intelligence</h3><p style='font-size:13.5px;color:#5f6b62'>Administrators see demand by hour and stop, waiting times, delays, and where capacity is under pressure.</p></div>" +
      "</div>";
  };

  V.route = function (root) {
    var route = PARA.geo.activeRoute();
    if (!route) {
      root.innerHTML = "<h1 class='title'>Route information</h1><div class='card'><div class='empty'>No route has been configured yet.</div></div>";
      return;
    }
    var stops = PARA.geo.stops(route.id);
    var stopRows = PARA.analytics.demandByStop(PARA.analytics.range("month"));
    var demandById = {};
    stopRows.forEach(function (r) { demandById[r.stop.id] = r; });

    root.innerHTML =
      "<h1 class='title'>" + PARA.esc(route.name) + "</h1>" +
      "<div class='sub'>" + PARA.esc(route.code) + " · " + PARA.esc(route.startPoint) + " → " + PARA.esc(route.endPoint) + " · " + PARA.esc(route.distanceKm) + " km</div>" +
      serviceHero() +
      "<div class='card'><div class='card-head'><h3>Route in sequence</h3>" +
        "<span class='card-note'>" + PARA.esc(route.operatingHours.start) + "–" + PARA.esc(route.operatingHours.end) + " · " + PARA.esc(route.operatingHours.days.join(", ")) + "</span></div>" +
        "<div class='route-line'>" + stops.map(function (s, i) {
          return (i ? "<span class='seg'><span class='ln'></span></span>" : "") +
            "<span class='seg'><span class='dotp'></span><span class='nm'>" + PARA.esc(s.name) + "</span></span>";
        }).join("") + "</div>" +
        (route.description ? "<p class='hint' style='margin-top:12px'>" + PARA.esc(route.description) + "</p>" : "") +
      "</div>" +
      "<div class='card pad-0'><div class='table-wrap'><table class='t'>" +
        "<thead><tr><th>#</th><th>Stop</th><th>Location</th><th class='num'>Planned from previous</th>" +
        "<th class='num'>Next ETA</th><th class='num'>Recorded demand (30d)</th><th class='num'>Average wait</th><th>Facilities</th></tr></thead><tbody>" +
        stops.map(function (s) {
          var d = demandById[s.id] || {};
          var fac = [];
          if (s.shelter) fac.push("Shelter");
          if (s.seating) fac.push("Seating");
          if (s.accessible) fac.push("Accessible");
          return "<tr>" +
            "<td>" + s.position + "</td>" +
            "<td><strong>" + PARA.esc(s.name) + "</strong><div class='stop-meta'>" + PARA.esc(s.code) + "</div></td>" +
            "<td>" + PARA.esc(s.location || "—") + "</td>" +
            "<td class='num'>" + (s.travelFromPrev == null ? "—" : PARA.esc(s.travelFromPrev) + " min") + "</td>" +
            "<td class='num'>" + (s.eta ? "<strong>" + PARA.esc(PARA.fmt.time(s.eta)) + "</strong><div class='stop-meta'>" + PARA.esc(PARA.fmt.until(s.eta)) + "</div>" : "—") + "</td>" +
            "<td class='num'>" + (d.requests != null ? d.requests : "—") + "</td>" +
            "<td class='num'>" + (d.avgWait != null ? PARA.esc(PARA.fmt.mins(d.avgWait)) : "no data") + "</td>" +
            "<td><span class='card-note'>" + (fac.length ? PARA.esc(fac.join(" · ")) : "—") + "</span></td>" +
          "</tr>";
        }).join("") +
      "</tbody></table></div></div>" +
      "<div class='alert info'>Arrival times are estimates based on where each vehicle currently is and the normal travel time between stops. They are not a guarantee.</div>";
  };

  V.planner = function (root) {
    var route = PARA.geo.activeRoute();
    var stops = PARA.geo.stops(route && route.id);
    var today = new Date();
    var optStops = stops.map(function (s) {
      return "<option value='" + s.id + "'>" + s.position + ". " + PARA.esc(s.name) + "</option>";
    }).join("");

    root.innerHTML =
      "<h1 class='title'>Plan your trip</h1>" +
      "<div class='sub'>Tell us where you are going and when you need to arrive. PARA works backwards from the normal travel time to suggest when to reach your stop.</div>" +
      "<div class='grid g2'>" +
        "<div class='card'>" +
          "<div class='card-head'><h3>Trip details</h3></div>" +
          "<form id='plan-form'>" +
            PARA.ui.field("Starting stop", "<select class='in' name='origin' required><option value=''>Select a stop</option>" + optStops + "</select>") +
            PARA.ui.field("Destination stop", "<select class='in' name='dest' required><option value=''>Select a stop</option>" + optStops + "</select>") +
            "<div class='row2'>" +
              PARA.ui.field("Date", "<input class='in' type='date' name='date' value='" + today.toISOString().slice(0, 10) + "' required>") +
              PARA.ui.field("Latest arrival time", "<input class='in' type='time' name='time' value='07:30' required>") +
            "</div>" +
            PARA.ui.field("How strict is your arrival time?", "<select class='in' name='sensitivity'>" +
              PARA.ui.options(PARA.CONST.sensitivity, "must_arrive_by", function (v) { return PARA.CONST.sensitivityLabel[v]; }) + "</select>",
              "Must Arrive By adds a larger safety buffer. Flexible allows more variation.") +
            "<button class='btn block' type='submit' style='margin-top:6px'>Calculate recommended time</button>" +
          "</form>" +
        "</div>" +
        "<div id='plan-out'><div class='card'><div class='empty'>Your recommendation will appear here.</div></div></div>" +
      "</div>" +
      "<div class='card'><div class='card-head'><h3>How this is calculated</h3></div>" +
        "<ul class='timeline'>" +
          "<li><div class='t'>Normal travel time between your stops</div><div class='d'>From completed trips recorded on this route, falling back to the scheduled time when a segment has no history yet.</div></li>" +
          "<li><div class='t'>Where the vehicle is right now</div><div class='d'>If a vehicle is running, its live position and current delay are used to project the arrival time.</div></li>" +
          "<li><div class='t'>Boarding buffer</div><div class='d'>Time allowed to reach the stop and be ready to board.</div></li>" +
          "<li><div class='t'>Safety buffer</div><div class='d'>Extra minutes added for strict arrival requirements.</div></li>" +
        "</ul>" +
        "<div class='alert warn' style='margin-top:14px'>This is an estimate, not a guarantee. Weather, road works, and sudden crowding can still change the timing.</div>" +
      "</div>";

    var form = root.querySelector("#plan-form");
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var data = new FormData(form);
      var desired = data.get("date") + "T" + data.get("time") + ":00";
      var res = PARA.analytics.planTrip(data.get("origin"), data.get("dest"), desired, data.get("sensitivity"));
      var out = root.querySelector("#plan-out");
      if (!res.ok) {
        out.innerHTML = "<div class='card'><div class='alert err'>" + PARA.esc(res.error) + "</div></div>";
        return;
      }
      var u = PARA.auth.user();
      var canRequest = u && u.role === "passenger";
      out.innerHTML =
        "<div class='card'>" +
          "<div class='card-head'><h3>Your recommendation</h3><span class='card-note'>" + PARA.esc(res.route.name) + "</span></div>" +
          "<div class='plan-result'>" +
            "<div class='card-note'>Reach your stop by</div>" +
            "<div class='plan-big'>" + PARA.esc(PARA.fmt.time(res.recommendedLeave)) + "</div>" +
            "<div class='hint'>on " + PARA.esc(PARA.fmt.date(res.recommendedLeave)) + "</div>" +
          "</div>" +
          "<ul class='timeline' style='margin-top:18px'>" +
            "<li><div class='t'>" + PARA.esc(res.from.name) + " → " + PARA.esc(res.ordered.length) + " stop" + (res.ordered.length === 1 ? "" : "s") + " → " + PARA.esc(res.to.name) + "</div>" +
              "<div class='d'>" + PARA.esc(res.ordered.map(function (s) { return s.name; }).join(" → ")) + "</div></li>" +
            "<li><div class='t'>Expected ride time: " + PARA.esc(PARA.fmt.mins(res.typicalRideMin)) + "</div>" +
              "<div class='d'>" + (res.usingObserved ? "Based on recorded average travel time. " : "Based on the scheduled time. ") + "Includes " + res.bufferMin + " min safety buffer for a " + PARA.CONST.sensitivityLabel[res.sensitivity || "flexible"].toLowerCase() + " requirement.</div></li>" +
            "<li><div class='t'>" + (res.live ? "Vehicle currently running" : "Next scheduled departure") + "</div>" +
              "<div class='d'>" + (res.live
                ? "A vehicle is about " + res.live.mins + " minutes from " + PARA.esc(res.to.name) + "."
                : "No vehicle is running right now, so the first departure of " + PARA.esc(res.nextDeparture.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })) + " is used as the reference.") + "</div></li>" +
            "<li><div class='t'>Estimated arrival: " + PARA.esc(PARA.fmt.time(res.arriveBy)) + "</div>" +
              "<div class='d'>" + (res.withinDesired
                ? "This is before the " + PARA.esc(PARA.fmt.time(res.desired)) + " you asked for."
                : "This is after the " + PARA.esc(PARA.fmt.time(res.desired)) + " you asked for. Consider an earlier trip or allow more flexibility.") + "</div></li>" +
          "</ul>" +
          "<div class='alert info' style='margin-top:6px'><strong>Basis:</strong> " + PARA.esc(res.basis) + ".</div>" +
          (canRequest
            ? "<button class='btn block' style='margin-top:14px' data-request='" + res.from.id + "|" + res.to.id + "'>Submit this as a transportation request</button>"
            : "<a class='btn block ghost' style='margin-top:14px' href='#/login'>Sign in as a passenger to request this trip</a>") +
        "</div>";

      var btn = out.querySelector("[data-request]");
      if (btn) {
        btn.addEventListener("click", function () {
          var ids = btn.getAttribute("data-request").split("|");
          sessionStorage.setItem("para_prefill", JSON.stringify({ originId: ids[0], destId: ids[1], time: res.desired ? res.desired.toTimeString().slice(0, 5) : "" }));
          location.hash = "#/passenger/request-new";
        });
      }
    });
  };

  V.login = function (root) {
    if (PARA.auth.user()) { location.hash = "#/"; return; }
    root.innerHTML =
      "<div style='max-width:460px;margin:0 auto'>" +
        "<div class='login-card'>" +
          "<div style='text-align:center'>" +
            PARA.logo(78) +
            "<h1 class='title' style='font-size:24px;margin-top:6px'>Sign in to PARA</h1>" +
            "<p class='sub' style='margin-bottom:18px'>Passenger Alert and Routing Assistant</p>" +
          "</div>" +
          "<div id='login-err'></div>" +
          "<form id='login-form'>" +
            PARA.ui.field("Username", "<input class='in' name='username' autocomplete='username' required autofocus>") +
            PARA.ui.field("Password", "<input class='in' name='password' type='password' autocomplete='current-password' required>") +
            "<button class='btn block' type='submit' style='margin-top:6px'>Sign in</button>" +
          "</form>" +
          "<div class='demo-box' style='margin-top:18px'>" +
            "<strong style='display:block;margin-bottom:6px'>Demo accounts</strong>" +
            "<div class='demo-row'><span>Administrator</span><code>admin / admin123</code></div>" +
            "<div class='demo-row'><span>Driver</span><code>driver1 / driver123</code></div>" +
            "<div class='demo-row'><span>Passenger</span><code>passenger1 / passenger123</code></div>" +
            "<div class='hint' style='margin-top:8px'>Only an administrator can register driver accounts. Passengers may create their own account from the sign-up link.</div>" +
          "</div>" +
          "<div style='text-align:center;margin-top:16px'><a class='btn ghost' href='#/signup'>Create a passenger account</a></div>" +
        "</div>" +
      "</div>";

    root.querySelector("#login-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var f = new FormData(e.target);
      var res = PARA.auth.login(f.get("username"), f.get("password"));
      var errBox = root.querySelector("#login-err");
      if (!res.ok) {
        errBox.innerHTML = "<div class='alert err'>" + PARA.esc(res.error) + "</div>";
        return;
      }
      PARA.ui.toast("Welcome, " + res.user.fullName, "good");
      var home = res.user.role === "admin" ? "#/admin" : res.user.role === "driver" ? "#/driver" : "#/passenger";
      location.hash = home;
      PARA.render();
    });
  };

  V.signup = function (root) {
    if (PARA.auth.user()) { location.hash = "#/"; return; }
    var route = PARA.geo.activeRoute();
    var stops = PARA.geo.stops(route && route.id);
    root.innerHTML =
      "<div style='max-width:520px;margin:0 auto'>" +
        "<div class='card'>" +
          "<h1 class='title' style='font-size:22px'>Passenger account</h1>" +
          "<div class='sub'>Passenger accounts are optional. You can browse the route and plan trips without one, but an account lets you submit requests, get alerts and keep trip history.</div>" +
          "<div id='su-err'></div>" +
          "<form id='su-form'>" +
            PARA.ui.field("Full name", "<input class='in' name='fullName' required>") +
            "<div class='row2'>" +
              PARA.ui.field("Username", "<input class='in' name='username' required>") +
              PARA.ui.field("Password", "<input class='in' name='password' type='password' required minlength='6'>") +
            "</div>" +
            "<div class='row2'>" +
              PARA.ui.field("Mobile number", "<input class='in' name='contact' placeholder='+63 9XX XXX XXXX'>") +
              PARA.ui.field("Email (optional)", "<input class='in' name='email' type='email'>") +
            "</div>" +
            PARA.ui.field("Usual starting stop", "<select class='in' name='homeStop'><option value=''>Not set</option>" +
              stops.map(function (s) { return "<option value='" + s.id + "'>" + PARA.esc(s.name) + "</option>"; }).join("") + "</select>",
              "Used only as a default for your requests. Exact home addresses are never stored.") +
            "<button class='btn block' type='submit'>Create account</button>" +
          "</form>" +
          "<div style='text-align:center;margin-top:14px'><a class='btn ghost' href='#/login'>Back to sign in</a></div>" +
        "</div>" +
      "</div>";

    root.querySelector("#su-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var f = new FormData(e.target);
      var uname = String(f.get("username") || "").trim();
      if (PARA.store.db.users.some(function (u) { return u.username.toLowerCase() === uname.toLowerCase(); })) {
        root.querySelector("#su-err").innerHTML = "<div class='alert err'>That username is already taken.</div>";
        return;
      }
      if (String(f.get("password")).length < 6) {
        root.querySelector("#su-err").innerHTML = "<div class='alert err'>Password must be at least 6 characters.</div>";
        return;
      }
      var u = {
        id: PARA.store.uid("usr"), username: uname, password: String(f.get("password")), role: "passenger",
        fullName: f.get("fullName"), email: f.get("email") || null, phone: f.get("contact") || null,
        active: true, activated: true, mustChangePassword: false, createdAt: new Date().toISOString(), lastLoginAt: null
      };
      PARA.store.db.users.push(u);
      PARA.store.db.passengers.push({
        id: PARA.store.uid("pas"), userId: u.id, fullName: u.fullName, contact: u.phone,
        sms: !!u.phone, homeStopId: f.get("homeStop") || null,
        prefs: { serviceInterruption: true, majorDelay: true, announcements: true, vehicleArrival: false },
        createdAt: new Date().toISOString()
      });
      PARa_record("register_passenger", "user", u.id, "Passenger self-registered");
      PARA.store.save();
      PARA.auth.save(u);
      PARA.ui.toast("Account created. Welcome aboard.", "good");
      location.hash = "#/passenger";
      PARA.render();
    });
  };

  V.account = function (root) {
    var u = PARA.auth.user();
    if (!u) { location.hash = "#/login"; return; }
    var p = PARA.store.db.passengers.filter(function (x) { return x.userId === u.id; })[0];

    root.innerHTML =
      "<h1 class='title'>My account</h1>" +
      "<div class='sub'>Signed in as " + PARA.esc(u.fullName) + " · <span style='text-transform:capitalize'>" + PARA.esc(u.role) + "</span></div>" +
      "<div class='grid g2'>" +
        "<div class='card'><div class='card-head'><h3>Profile</h3></div>" +
          "<ul class='stop-list'>" +
            "<li><div class='stop-num'>N</div><div><strong>" + PARA.esc(u.fullName) + "</strong><div class='stop-meta'>" + PARA.esc(u.username) + "</div></div></li>" +
            "<li><div class='stop-num'>C</div><div><strong>Contact</strong><div class='stop-meta'>" + PARA.esc(u.phone || "Not provided") + (u.email ? " · " + PARA.esc(u.email) : "") + "</div></div></li>" +
            "<li><div class='stop-num'>R</div><div><strong>Access level</strong><div class='stop-meta' style='text-transform:capitalize'>" + PARA.esc(u.role) + "</div></div></li>" +
            "<li><div class='stop-num'>L</div><div><strong>Last sign-in</strong><div class='stop-meta'>" + PARA.esc(PARA.fmt.dateTime(u.lastLoginAt)) + "</div></div></li>" +
          "</ul>" +
        "</div>" +
        "<div class='card'><div class='card-head'><h3>Change password</h3></div>" +
          "<div id='pw-err'></div>" +
          "<form id='pw-form'>" +
            PARA.ui.field("Current password", "<input class='in' name='current' type='password' required>") +
            PARA.ui.field("New password", "<input class='in' name='next' type='password' required minlength='6'>") +
            PARA.ui.field("Confirm new password", "<input class='in' name='confirm' type='password' required minlength='6'>") +
            "<button class='btn' type='submit'>Update password</button>" +
          "</form>" +
          (p ? "<div class='card-head' style='margin-top:22px'><h3>Alert preferences</h3></div>" +
            "<form id='pref-form'>" +
              ["serviceInterruption:Service interruption alerts", "majorDelay:Major delay alerts", "announcements:General announcements", "vehicleArrival:Vehicle approaching my stop"].map(function (pair) {
                var k = pair.split(":")[0], lbl = pair.split(":").slice(1).join(":");
                return "<label class='chk'><input type='checkbox' name='" + k + "'" + (p.prefs[k] ? " checked" : "") + "><span>" + PARA.esc(lbl) + "</span></label>";
              }).join("") +
              "<label class='chk' style='margin-top:8px'><input type='checkbox' name='sms'" + (p.sms ? " checked" : "") + "><span>Send me SMS alerts (mobile " + PARA.esc(p.contact || "not set") + ")</span></label>" +
              "<button class='btn ghost' type='submit' style='margin-top:10px'>Save preferences</button>" +
            "</form>" : "") +
        "</div>" +
      "</div>";

    root.querySelector("#pw-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var f = new FormData(e.target);
      if (f.get("current") !== u.password) {
        root.querySelector("#pw-err").innerHTML = "<div class='alert err'>Current password is not correct.</div>";
        return;
      }
      if (f.get("next") !== f.get("confirm")) {
        root.querySelector("#pw-err").innerHTML = "<div class='alert err'>The new passwords do not match.</div>";
        return;
      }
      if (String(f.get("next")).length < 6) {
        root.querySelector("#pw-err").innerHTML = "<div class='alert err'>New password must be at least 6 characters.</div>";
        return;
      }
      u.password = String(f.get("next"));
      PARa_record("change_password", "user", u.id, "Password updated");
      PARA.store.save();
      root.querySelector("#pw-err").innerHTML = "<div class='alert ok'>Password updated.</div>";
      e.target.reset();
    });

    var prefForm = root.querySelector("#pref-form");
    if (prefForm) {
      prefForm.addEventListener("submit", function (e) {
        e.preventDefault();
        var f = new FormData(prefForm);
        ["serviceInterruption", "majorDelay", "announcements", "vehicleArrival"].forEach(function (k) {
          p.prefs[k] = f.get(k) === "on";
        });
        p.sms = f.get("sms") === "on";
        PARA.store.save();
        PARA.ui.toast("Alert preferences saved", "good");
      });
    }
  };

})(PARA.views);
